package com.sync.xxx

import android.util.Log
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription

class SimpleSdpObserver private constructor(
    private val tag: String,
    private val onSetSuccessCb: (() -> Unit)?,
    private val onCreateSuccessCb: ((SessionDescription?) -> Unit)?
) : SdpObserver {

    
    constructor(tag: String, onSetSuccess: () -> Unit)
        : this(tag, onSetSuccess, null)

  
    constructor(tag: String, onCreateSuccess: (SessionDescription?) -> Unit)
        : this(tag, null, onCreateSuccess)

    override fun onCreateSuccess(sdp: SessionDescription?) {
        onCreateSuccessCb?.invoke(sdp)
    }

    override fun onSetSuccess() {
        onSetSuccessCb?.invoke()
    }

    override fun onCreateFailure(error: String?) {
        Log.e("SimpleSdpObserver", "$tag → createFailure: $error")
    }

    override fun onSetFailure(error: String?) {
        Log.e("SimpleSdpObserver", "$tag → setFailure: $error")
    }
}