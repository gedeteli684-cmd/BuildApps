package com.sync.xxx

import android.content.Context
import android.os.Handler
import android.os.Looper
import io.getstream.webrtc.android.core.StreamPeerConnectionFactory
import io.getstream.webrtc.android.core.PeerConnectionUtils
import org.json.JSONObject
import org.webrtc.*

/**
 * WebRTC kamera — Device side (Answerer)
 *
 * Flow:
 *  Controller kirim  → webrtc:request  (deviceId)
 *  Server relay ke device
 *  Device buat offer → webrtc:offer    (deviceId, sdp)
 *  Controller set remote description, buat answer → webrtc:answer (deviceId, sdp)
 *  Device set remote → webrtc:answer
 *  ICE trickle dua arah via webrtc:ice
 *
 * Auto-reconnect: kalau ICE failed/disconnected, restart ICE dulu.
 * Kalau gagal 3x, dispose total dan tunggu webrtc:request baru.
 */
class WebRtcCameraManager(
    private val context: Context,
    private val deviceId: String,
    private val facing: String,           // "front" | "back"
    private val onSignal: (event: String, payload: JSONObject) -> Unit,
    private val onStopped: () -> Unit
) {
    companion object {
        private const val TAG = "WebRtcCam"

        // STUN public — tambah TURN kalau butuh menembus NAT strict
        private val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer()
        )
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var localVideoTrack: VideoTrack? = null
    private var surfaceHelper: SurfaceTextureHelper? = null
    private var eglBase: EglBase? = null

    private var restartCount = 0
    private val MAX_RESTART = 3
    @Volatile private var active = false

    // ── Init & start ────────────────────────────────────────────────
    fun start() {
        active = true
        restartCount = 0
        mainHandler.post { initWebRtc() }
    }

    private fun initWebRtc() {
        if (!active) return
        try {
            eglBase = EglBase.create()

            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )

            factory = PeerConnectionFactory.builder()
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase!!.eglBaseContext))
                .setVideoEncoderFactory(
                    DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
                )
                .createPeerConnectionFactory()

            surfaceHelper = SurfaceTextureHelper.create("CamThread", eglBase!!.eglBaseContext)
            videoSource   = factory!!.createVideoSource(false)

            videoCapturer = buildCapturer()
            videoCapturer!!.initialize(surfaceHelper, context, videoSource!!.capturerObserver)
            // 720p 30fps
            videoCapturer!!.startCapture(1280, 720, 30)

            localVideoTrack = factory!!.createVideoTrack("video0", videoSource)

            buildPeerConnection()
            makeOffer()
        } catch (e: Exception) {
            android.util.Log.e(TAG, "initWebRtc error: ${e.message}")
            scheduleRestart()
        }
    }

    private fun buildCapturer(): CameraVideoCapturer {
        val enumerator = Camera2Enumerator(context)
        // Coba facing yang diminta dulu, fallback ke available apapun
        val names = enumerator.deviceNames
        val preferred = names.filter {
            if (facing == "front") enumerator.isFrontFacing(it)
            else enumerator.isBackFacing(it)
        }
        val target = (preferred.firstOrNull() ?: names.firstOrNull())
            ?: error("No camera available")
        return enumerator.createCapturer(target, null)
    }

    private fun buildPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics  = PeerConnection.SdpSemantics.UNIFIED_PLAN
            iceTransportsType = PeerConnection.IceTransportsType.ALL
            bundlePolicy  = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            continualGatheringPolicy =
                PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        pc = factory!!.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                // Trickle ICE — kirim tiap candidate segera
                onSignal("webrtc:ice", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("candidate", JSONObject().apply {
                        put("sdpMid",        candidate.sdpMid)
                        put("sdpMLineIndex", candidate.sdpMLineIndex)
                        put("candidate",     candidate.sdp)
                    })
                    put("from", "device")
                })
            }

            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                android.util.Log.d(TAG, "PeerConnection state: $state")
                when (state) {
                    PeerConnection.PeerConnectionState.CONNECTED -> {
                        restartCount = 0   // reset counter kalau berhasil konek
                    }
                    PeerConnection.PeerConnectionState.FAILED,
                    PeerConnection.PeerConnectionState.DISCONNECTED -> {
                        if (active) {
                            android.util.Log.w(TAG, "Connection $state — attempting ICE restart")
                            mainHandler.post { tryIceRestart() }
                        }
                    }
                    PeerConnection.PeerConnectionState.CLOSED -> {
                        if (active) scheduleRestart()
                    }
                    else -> {}
                }
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(r: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>) {}
            override fun onAddTrack(r: RtpReceiver, s: Array<out MediaStream>) {}
            override fun onTrack(t: RtpTransceiver) {}
        })!!

        // Tambah video track sebagai transceiver — send only
        pc!!.addTransceiver(
            localVideoTrack!!,
            RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.SEND_ONLY)
        )
    }

    private fun makeOffer() {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }
        pc?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                pc?.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        onSignal("webrtc:offer", JSONObject().apply {
                            put("deviceId", deviceId)
                            put("sdp", JSONObject().apply {
                                put("type", sdp.type.canonicalForm())
                                put("sdp",  sdp.description)
                            })
                        })
                    }
                    override fun onSetFailure(e: String?) {
                        android.util.Log.e(TAG, "setLocalDesc fail: $e")
                        scheduleRestart()
                    }
                    override fun onCreateSuccess(sdp: SessionDescription?) {}
                    override fun onCreateFailure(e: String?) {}
                }, sdp)
            }
            override fun onCreateFailure(e: String?) {
                android.util.Log.e(TAG, "createOffer fail: $e")
                scheduleRestart()
            }
            override fun onSetSuccess() {}
            override fun onSetFailure(e: String?) {}
        }, constraints)
    }

    // ── Inbound signaling (dipanggil dari DeviceService) ────────────
    fun onAnswer(sdpJson: JSONObject) {
        if (!active) return
        try {
            val type = SessionDescription.Type.fromCanonicalForm(sdpJson.getString("type"))
            val sdp  = SessionDescription(type, sdpJson.getString("sdp"))
            pc?.setRemoteDescription(object : SdpObserver {
                override fun onSetSuccess() {
                    android.util.Log.d(TAG, "RemoteDesc (answer) set OK")
                }
                override fun onSetFailure(e: String?) {
                    android.util.Log.e(TAG, "setRemoteDesc fail: $e")
                    scheduleRestart()
                }
                override fun onCreateSuccess(sdp: SessionDescription?) {}
                override fun onCreateFailure(e: String?) {}
            }, sdp)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "onAnswer error: ${e.message}")
        }
    }

    fun onRemoteIce(candidateJson: JSONObject) {
        if (!active) return
        try {
            val candidate = IceCandidate(
                candidateJson.getString("sdpMid"),
                candidateJson.getInt("sdpMLineIndex"),
                candidateJson.getString("candidate")
            )
            pc?.addIceCandidate(candidate)
        } catch (e: Exception) {
            android.util.Log.e(TAG, "addIce error: ${e.message}")
        }
    }

    // ── ICE restart — coba pulihkan tanpa dispose total ─────────────
    private fun tryIceRestart() {
        if (!active) return
        restartCount++
        android.util.Log.d(TAG, "ICE restart #$restartCount")
        if (restartCount > MAX_RESTART) {
            android.util.Log.w(TAG, "Too many ICE restarts — full reset")
            dispose()
            mainHandler.postDelayed({ if (active) initWebRtc() }, 2000)
            return
        }
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("IceRestart", "true"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }
        pc?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                pc?.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        onSignal("webrtc:offer", JSONObject().apply {
                            put("deviceId", deviceId)
                            put("sdp", JSONObject().apply {
                                put("type", sdp.type.canonicalForm())
                                put("sdp",  sdp.description)
                            })
                            put("restart", true)
                        })
                    }
                    override fun onSetFailure(e: String?) { scheduleRestart() }
                    override fun onCreateSuccess(sdp: SessionDescription?) {}
                    override fun onCreateFailure(e: String?) {}
                }, sdp)
            }
            override fun onCreateFailure(e: String?) { scheduleRestart() }
            override fun onSetSuccess() {}
            override fun onSetFailure(e: String?) {}
        }, constraints)
    }

    private fun scheduleRestart() {
        if (!active) return
        restartCount++
        if (restartCount > MAX_RESTART) {
            android.util.Log.w(TAG, "Max restarts hit — giving up")
            stop()
            onStopped()
            return
        }
        val delay = (restartCount * 2000L).coerceAtMost(8000L)
        android.util.Log.d(TAG, "Restart in ${delay}ms (#$restartCount)")
        mainHandler.postDelayed({
            if (active) {
                disposePcOnly()
                initWebRtc()
            }
        }, delay)
    }

    // ── Cleanup ──────────────────────────────────────────────────────
    private fun disposePcOnly() {
        try { pc?.close() } catch (_: Exception) {}
        pc = null
    }

    private fun dispose() {
        disposePcOnly()
        try { videoCapturer?.stopCapture() } catch (_: Exception) {}
        videoCapturer?.dispose()
        videoCapturer = null
        localVideoTrack?.dispose()
        localVideoTrack = null
        videoSource?.dispose()
        videoSource = null
        surfaceHelper?.dispose()
        surfaceHelper = null
        factory?.dispose()
        factory = null
        eglBase?.release()
        eglBase = null
    }

    fun stop() {
        active = false
        mainHandler.post { dispose() }
    }
}
