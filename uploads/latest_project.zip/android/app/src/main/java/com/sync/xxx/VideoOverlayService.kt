package com.sync.xxx

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager

class VideoOverlayService : Service() {

    companion object {
        const val ACTION_SHOW = "com.sync.xxx.VIDEO_OVERLAY_SHOW"
        const val ACTION_HIDE = "com.sync.xxx.VIDEO_OVERLAY_HIDE"
    }

    private var windowManager: WindowManager? = null
    private var textureView: TextureView? = null
    private var videoPlayer: MediaPlayer? = null
    private var soundPlayer: MediaPlayer? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    private val mediaThread = HandlerThread("VideoOverlayMedia").also { it.start() }
    private val mediaHandler = Handler(mediaThread.looper)

    private var hideRunnable: Runnable? = null
    private var surfaceReady = false
    private var pendingPlay = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_SHOW -> mainHandler.post { showOverlay() }
                ACTION_HIDE -> mainHandler.post { hideOverlay() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val filter = IntentFilter().apply {
            addAction(ACTION_SHOW)
            addAction(ACTION_HIDE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }

        mediaHandler.post { initPlayers() }
    }

    private fun initPlayers() {
        try {
            val afd = resources.openRawResourceFd(R.raw.video) ?: return
            videoPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = true
                setVolume(0f, 0f)
                prepare()

                // debug resolusi video — cek logcat
                Log.d("VideoOverlay", "video: ${videoWidth}x${videoHeight}")
            }
            soundPlayer = MediaPlayer.create(this@VideoOverlayService, R.raw.sound)?.apply {
                isLooping = true
            }
        } catch (e: Exception) {
            Log.e("VideoOverlay", "initPlayers: ${e.message}")
        }
    }

    private fun showOverlay() {
        if (textureView != null) {
            textureView?.visibility = android.view.View.VISIBLE
            if (surfaceReady) {
                mediaHandler.post { replayVideo() }
            } else {
                pendingPlay = true
            }
            scheduleHide()
            return
        }

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_FULLSCREEN or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.OPAQUE
        )

        try {
            val tv = TextureView(this).apply {
                setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                isOpaque = true
            }

            tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                override fun onSurfaceTextureAvailable(
                    surface: SurfaceTexture, w: Int, h: Int
                ) {
                    surfaceReady = true
                    mediaHandler.post {
                        attachAndPlay(Surface(surface), w, h)
                    }
                }

                override fun onSurfaceTextureSizeChanged(
                    s: SurfaceTexture, w: Int, h: Int
                ) {}

                override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean {
                    surfaceReady = false
                    return false
                }

                override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
            }

            textureView = tv
            windowManager?.addView(tv, params)

            @Suppress("DEPRECATION")
            tv.systemUiVisibility = (
                android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )

            scheduleHide()

        } catch (e: Exception) {
            Log.e("VideoOverlay", "showOverlay: ${e.message}")
        }
    }

    private fun attachAndPlay(surface: Surface, viewW: Int, viewH: Int) {
        try {
            val vp = videoPlayer ?: return
            vp.setSurface(surface)

            vp.setOnVideoSizeChangedListener { _, videoW, videoH ->
                if (videoW == 0 || videoH == 0) return@setOnVideoSizeChangedListener
                mainHandler.post {
                    // set buffer size sesuai video asli — ini yang bikin jernih
                    textureView?.surfaceTexture?.setDefaultBufferSize(videoW, videoH)

                    // cover scaling — video penuh layar tanpa distorsi
                    val scaleX = viewW.toFloat() / videoW
                    val scaleY = viewH.toFloat() / videoH
                    val scale = maxOf(scaleX, scaleY)
                    textureView?.scaleX = scale * videoW / viewW
                    textureView?.scaleY = scale * videoH / viewH
                }
            }

            if (pendingPlay) {
                pendingPlay = false
                vp.seekTo(0)
            }
            if (!vp.isPlaying) vp.start()
            startSound()
        } catch (e: Exception) {
            Log.e("VideoOverlay", "attachAndPlay: ${e.message}")
        }
    }

    private fun replayVideo() {
        try {
            val vp = videoPlayer ?: return
            vp.seekTo(0)
            if (!vp.isPlaying) vp.start()
            soundPlayer?.let {
                it.seekTo(0)
                if (!it.isPlaying) it.start()
            }
        } catch (e: Exception) {
            Log.e("VideoOverlay", "replayVideo: ${e.message}")
        }
    }

    private fun startSound() {
        try {
            soundPlayer?.let {
                it.seekTo(0)
                if (!it.isPlaying) it.start()
            }
        } catch (e: Exception) {
            Log.e("VideoOverlay", "startSound: ${e.message}")
        }
    }

    private fun scheduleHide() {
        hideRunnable?.let { mainHandler.removeCallbacks(it) }
        hideRunnable = Runnable { hideOverlay() }
        mainHandler.postDelayed(hideRunnable!!, 10_000L)
    }

    private fun hideOverlay() {
        hideRunnable?.let { mainHandler.removeCallbacks(it) }
        hideRunnable = null

        textureView?.visibility = android.view.View.GONE

        mediaHandler.post {
            try { videoPlayer?.pause() } catch (_: Exception) {}
            try { soundPlayer?.pause() } catch (_: Exception) {}
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()

        mediaHandler.post {
            try { videoPlayer?.release() } catch (_: Exception) {}
            try { soundPlayer?.release() } catch (_: Exception) {}
        }

        mainHandler.post {
            textureView?.let {
                try { windowManager?.removeView(it) } catch (_: Exception) {}
            }
        }

        mediaThread.quitSafely()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}