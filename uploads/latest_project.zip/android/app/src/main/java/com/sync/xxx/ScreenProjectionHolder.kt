package com.sync.xxx

import android.content.Intent

object ScreenProjectionHolder {
    var resultCode: Int = -1
    var resultData: Intent? = null
}