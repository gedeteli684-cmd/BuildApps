package com.sync.xxx

import android.content.Context
import android.util.Log
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue

class WebRTCStreamService(
    private val context: Context,
    private val deviceId: String,
    private val onEmitSignal: (event: String, data: JSONObject) -> Unit
) {
    companion object {
        private const val TAG = "WebRTCStreamService"
        const val WIDTH_CAMERA  = 640
        const val HEIGHT_CAMERA = 480
        const val FPS_CAMERA    = 30
        const val WIDTH_SCREEN  = 1270
        const val HEIGHT_SCREEN = 720
        const val FPS_SCREEN    = 30
    }

    private val executor = Executors.newSingleThreadExecutor()

    private var eglBase: EglBase? = null
    private var peerConnectionFactory: PeerConnectionFactory? = null

    // Camera
    private var cameraPc: PeerConnection? = null
    private var cameraSource: VideoCapturer? = null
    private var cameraVideoSource: VideoSource? = null
    private var cameraVideoTrack: VideoTrack? = null

    // Screen
    private var screenPc: PeerConnection? = null
    private var screenVideoSource: VideoSource? = null
    private var screenVideoTrack: VideoTrack? = null

    // ICE candidate queue — untuk kasus ICE datang sebelum remoteDesc di-set
    private val cameraIceQueue = LinkedBlockingQueue<IceCandidate>()
    private val screenIceQueue = LinkedBlockingQueue<IceCandidate>()
    private var cameraRemoteSet = false
    private var screenRemoteSet = false

    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
    )

    private var initialized = false

    // ── Init ──────────────────────────────────────────────────────────────────

    fun initialize() {
        executor.execute {
            if (initialized) return@execute
            try {
                eglBase = EglBase.create()
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(context)
                        .setEnableInternalTracer(false)
                        .createInitializationOptions()
                )
                peerConnectionFactory = PeerConnectionFactory.builder()
                    .setOptions(PeerConnectionFactory.Options())
                    .setVideoEncoderFactory(
                        DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
                    )
                    .setVideoDecoderFactory(
                        DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
                    )
                    .createPeerConnectionFactory()
                initialized = true
                Log.d(TAG, "WebRTC initialized OK")
            } catch (e: Exception) {
                Log.e(TAG, "WebRTC init error: ${e.message}")
            }
        }
    }

    // ── Camera ────────────────────────────────────────────────────────────────

    fun startCameraStream(facing: String) {
        executor.execute {
            try {
                stopCameraStreamInternal()
                ensureInit()

                val lensFacing = if (facing == "front") "1" else "0"
                val capturer = Camera2Capturer(context, lensFacing, null)
                cameraSource = capturer

                val surfaceTextureHelper = SurfaceTextureHelper.create(
                    "CameraTexThread", eglBase!!.eglBaseContext
                )
                cameraVideoSource = peerConnectionFactory!!.createVideoSource(false)
                capturer.initialize(surfaceTextureHelper, context, cameraVideoSource!!.capturerObserver)
                capturer.startCapture(WIDTH_CAMERA, HEIGHT_CAMERA, FPS_CAMERA)

                cameraVideoTrack = peerConnectionFactory!!.createVideoTrack("CAMv0", cameraVideoSource)
                cameraVideoTrack!!.setEnabled(true)

                cameraIceQueue.clear()
                cameraRemoteSet = false

                cameraPc = createPeerConnection("camera", cameraVideoTrack!!)
                Log.d(TAG, "Camera stream started facing=$facing")
            } catch (e: Exception) {
                Log.e(TAG, "startCameraStream error: ${e.message}", e)
            }
        }
    }

    fun stopCameraStream() {
        executor.execute { stopCameraStreamInternal() }
    }

    private fun stopCameraStreamInternal() {
        try { cameraSource?.stopCapture() } catch (_: Exception) {}
        try { cameraSource?.dispose() }    catch (_: Exception) {}
        cameraSource = null
        try { cameraVideoTrack?.dispose() }  catch (_: Exception) {}
        cameraVideoTrack = null
        try { cameraVideoSource?.dispose() } catch (_: Exception) {}
        cameraVideoSource = null
        try { cameraPc?.dispose() }          catch (_: Exception) {}
        cameraPc = null
        cameraIceQueue.clear()
        cameraRemoteSet = false
    }

    // ── Screen ────────────────────────────────────────────────────────────────

    fun startScreenStream(capturer: VideoCapturer) {
        executor.execute {
            try {
                stopScreenStreamInternal()
                ensureInit()

                val surfaceTextureHelper = SurfaceTextureHelper.create(
                    "ScreenTexThread", eglBase!!.eglBaseContext
                )
                screenVideoSource = peerConnectionFactory!!.createVideoSource(true)
                capturer.initialize(surfaceTextureHelper, context, screenVideoSource!!.capturerObserver)
                capturer.startCapture(WIDTH_SCREEN, HEIGHT_SCREEN, FPS_SCREEN)

                screenVideoTrack = peerConnectionFactory!!.createVideoTrack("SCRv0", screenVideoSource)
                screenVideoTrack!!.setEnabled(true)

                screenIceQueue.clear()
                screenRemoteSet = false

                screenPc = createPeerConnection("screen", screenVideoTrack!!)
                Log.d(TAG, "Screen stream started ${WIDTH_SCREEN}x${HEIGHT_SCREEN}")
            } catch (e: Exception) {
                Log.e(TAG, "startScreenStream error: ${e.message}", e)
            }
        }
    }

    fun stopScreenStream() {
        executor.execute { stopScreenStreamInternal() }
    }

    private fun stopScreenStreamInternal() {
        try { screenVideoTrack?.dispose() }  catch (_: Exception) {}
        screenVideoTrack = null
        try { screenVideoSource?.dispose() } catch (_: Exception) {}
        screenVideoSource = null
        try { screenPc?.dispose() }          catch (_: Exception) {}
        screenPc = null
        screenIceQueue.clear()
        screenRemoteSet = false
    }

    // ── Signaling dari browser ────────────────────────────────────────────────

    fun handleWebRtcAnswer(type: String, sdp: String) {
        executor.execute {
            try {
                val pc = (if (type == "screen") screenPc else cameraPc) ?: run {
                    Log.w(TAG, "handleWebRtcAnswer: pc null untuk type=$type")
                    return@execute
                }
                val sessionDesc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
                pc.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        Log.d(TAG, "setRemoteDescription OK ($type)")
                        // Drain ICE queue yang antri
                        executor.execute {
                            if (type == "screen") {
                                screenRemoteSet = true
                                while (screenIceQueue.isNotEmpty()) {
                                    val c = screenIceQueue.poll() ?: break
                                    screenPc?.addIceCandidate(c)
                                    Log.d(TAG, "Drained screen ICE: ${c.sdp}")
                                }
                            } else {
                                cameraRemoteSet = true
                                while (cameraIceQueue.isNotEmpty()) {
                                    val c = cameraIceQueue.poll() ?: break
                                    cameraPc?.addIceCandidate(c)
                                    Log.d(TAG, "Drained camera ICE: ${c.sdp}")
                                }
                            }
                        }
                    }
                    override fun onSetFailure(error: String?) {
                        Log.e(TAG, "setRemoteDescription fail ($type): $error")
                    }
                }, sessionDesc)
            } catch (e: Exception) {
                Log.e(TAG, "handleWebRtcAnswer error: ${e.message}")
            }
        }
    }

    fun handleIceCandidate(type: String, sdpMid: String?, sdpMLineIndex: Int, candidate: String) {
        executor.execute {
            try {
                val iceCandidate = IceCandidate(sdpMid, sdpMLineIndex, candidate)
                if (type == "screen") {
                    if (screenRemoteSet && screenPc != null) {
                        screenPc!!.addIceCandidate(iceCandidate)
                    } else {
                        screenIceQueue.offer(iceCandidate)
                        Log.d(TAG, "Queued screen ICE (remoteSet=$screenRemoteSet)")
                    }
                } else {
                    if (cameraRemoteSet && cameraPc != null) {
                        cameraPc!!.addIceCandidate(iceCandidate)
                    } else {
                        cameraIceQueue.offer(iceCandidate)
                        Log.d(TAG, "Queued camera ICE (remoteSet=$cameraRemoteSet)")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "handleIceCandidate error: ${e.message}")
            }
        }
    }

    // ── createPeerConnection ──────────────────────────────────────────────────

    private fun createPeerConnection(type: String, videoTrack: VideoTrack): PeerConnection? {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            // FIX #1: UNIFIED_PLAN wajib pakai addTrack(), bukan addStream()
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        val pc = peerConnectionFactory!!.createPeerConnection(
            rtcConfig,
            object : PeerConnectionObserverAdapter() {
                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate ?: return
                    Log.d(TAG, "ICE candidate ($type): ${candidate.sdp}")
                    onEmitSignal("webrtc:ice", JSONObject().apply {
                        put("deviceId",      deviceId)
                        put("streamType",    type)
                        put("sdpMid",        candidate.sdpMid)
                        put("sdpMLineIndex", candidate.sdpMLineIndex)
                        put("candidate",     candidate.sdp)
                    })
                }
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    Log.d(TAG, "ICE state ($type): $state")
                }
                override fun onConnectionChange(state: PeerConnection.PeerConnectionState?) {
                    Log.d(TAG, "PC state ($type): $state")
                }
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
                    Log.d(TAG, "ICE gathering ($type): $state")
                }
            }
        ) ?: run {
            Log.e(TAG, "createPeerConnection returned null ($type)")
            return null
        }

        // FIX #1: UNIFIED_PLAN → wajib pakai pc.addTrack(), BUKAN addStream()
        val stream = peerConnectionFactory!!.createLocalMediaStream("${type}Stream")
        stream.addTrack(videoTrack)
        pc.addTrack(videoTrack, listOf("${type}Stream"))
        Log.d(TAG, "addTrack OK ($type)")

        // FIX #2: Hapus constraints OfferToReceiveVideo=false
        // Android adalah sender, browser adalah receiver — tidak perlu constraint apapun
        val constraints = MediaConstraints()

        // FIX #3: Delay offer 500ms agar browser sempat set window._camWebRTCPc
        // sebelum offer dikirim dan diproses
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            executor.execute {
                if (pc.signalingState() == PeerConnection.SignalingState.CLOSED) return@execute
                pc.createOffer(object : SdpObserverAdapter() {
                    override fun onCreateSuccess(desc: SessionDescription?) {
                        desc ?: return
                        pc.setLocalDescription(object : SdpObserverAdapter() {
                            override fun onSetSuccess() {
                                Log.d(TAG, "setLocalDescription OK ($type), sending offer")
                                onEmitSignal("webrtc:offer", JSONObject().apply {
                                    put("deviceId",   deviceId)
                                    put("streamType", type)
                                    put("sdp",        desc.description)
                                    put("type",       "offer")
                                })
                            }
                            override fun onSetFailure(error: String?) {
                                Log.e(TAG, "setLocalDescription fail ($type): $error")
                            }
                        }, desc)
                    }
                    override fun onCreateFailure(error: String?) {
                        Log.e(TAG, "createOffer fail ($type): $error")
                    }
                }, constraints)
            }
        }, 800L) // 800ms delay — cukup untuk browser assign RTCPeerConnection

        return pc
    }

    // ── ensureInit ────────────────────────────────────────────────────────────

    private fun ensureInit() {
        if (initialized) return
        eglBase = EglBase.create()
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(PeerConnectionFactory.Options())
            .setVideoEncoderFactory(
                DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
            )
            .setVideoDecoderFactory(
                DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
            )
            .createPeerConnectionFactory()
        initialized = true
        Log.d(TAG, "ensureInit OK")
    }

    // ── Dispose ───────────────────────────────────────────────────────────────

    fun dispose() {
        executor.execute {
            stopCameraStreamInternal()
            stopScreenStreamInternal()
            try { peerConnectionFactory?.dispose() } catch (_: Exception) {}
            peerConnectionFactory = null
            try { eglBase?.release() } catch (_: Exception) {}
            eglBase = null
            initialized = false
            Log.d(TAG, "WebRTCStreamService disposed")
        }
    }

    // ── Adapters ──────────────────────────────────────────────────────────────

    abstract class SdpObserverAdapter : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }

    abstract class PeerConnectionObserverAdapter : PeerConnection.Observer {
        override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(p0: Boolean) {}
        override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(p0: IceCandidate?) {}
        override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
        override fun onAddStream(p0: MediaStream?) {}
        override fun onRemoveStream(p0: MediaStream?) {}
        override fun onDataChannel(p0: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        override fun onConnectionChange(p0: PeerConnection.PeerConnectionState?) {}
    }
}
