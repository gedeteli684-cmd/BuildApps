package com.sync.xxx

import android.content.Context
import android.util.Log
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class WebRtcManager(
    private val context: Context,
    private val socket: Socket?,
    private val deviceId: String
) {
    companion object {
        private const val TAG = "WebRtcManager"
        private val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
    }

    // ── Single shared EglBase — ini yang fix crash ──────────────
    private var sharedEglBase: EglBase? = null

    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val _isActive = AtomicBoolean(false)

    val isActive: Boolean get() = _isActive.get()

    // ── Init factory dengan SATU EglBase ──────────────────────────
    private fun initialize() {
        // Dispose dulu kalau ada sisa
        disposeFactory()

        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        // SATU EglBase untuk semua — ini kuncinya
        sharedEglBase = EglBase.create()
        val eglBaseContext = sharedEglBase!!.eglBaseContext

        val encoderFactory = DefaultVideoEncoderFactory(
            eglBaseContext,
            true,
            true
        )
        val decoderFactory = DefaultVideoDecoderFactory(eglBaseContext)

        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .setOptions(PeerConnectionFactory.Options().apply {
                disableEncryption = false
                disableNetworkMonitor = false
            })
            .createPeerConnectionFactory()

        Log.d(TAG, "PeerConnectionFactory initialized")
    }

    // ── Start stream ───────────────────────────────────────────────
    fun startStream(facing: String) {
        executor.execute {
            try {
                // Stop dulu kalau masih jalan
                if (_isActive.get()) {
                    stopStreamInternal()
                }

                initialize()
                _isActive.set(true)

                val camEnumerator = Camera2Enumerator(context)
                val deviceNames = camEnumerator.deviceNames

                val cameraName = deviceNames.firstOrNull { name ->
                    val isFront = camEnumerator.isFrontFacing(name)
                    if (facing == "front") isFront else !isFront
                } ?: deviceNames.firstOrNull()

                if (cameraName == null) {
                    Log.e(TAG, "No camera found")
                    _isActive.set(false)
                    return@execute
                }

                videoCapturer = camEnumerator.createCapturer(cameraName, null)
                    ?: run {
                        Log.e(TAG, "Failed to create capturer")
                        _isActive.set(false)
                        return@execute
                    }

                // Pakai sharedEglBase yang sama ─ tidak bikin baru
                surfaceTextureHelper = SurfaceTextureHelper.create(
                    "CaptureThread",
                    sharedEglBase!!.eglBaseContext
                )

                videoSource = factory!!.createVideoSource(false)
                videoCapturer!!.initialize(
                    surfaceTextureHelper,
                    context,
                    videoSource!!.capturerObserver
                )
                videoCapturer!!.startCapture(1280, 720, 30)

                videoTrack = factory!!.createVideoTrack("v0", videoSource)
                videoTrack!!.setEnabled(true)

                val audioConstraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
                }
                audioSource = factory!!.createAudioSource(audioConstraints)
                audioTrack = factory!!.createAudioTrack("a0", audioSource)
                audioTrack!!.setEnabled(true)

                createPeerConnection()
                Log.d(TAG, "WebRTC stream started, facing=$facing")

            } catch (e: Exception) {
                Log.e(TAG, "startStream error: ${e.message}", e)
                _isActive.set(false)
            }
        }
    }

    // ── PeerConnection setup ───────────────────────────────────────
    private fun createPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy =
                PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        peerConnection = factory!!.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                    Log.d(TAG, "Signaling: $state")
                }
                override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                    Log.d(TAG, "ICE: $state")
                }
                override fun onIceConnectionReceivingChange(b: Boolean) {}
                override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate ?: return
                    val msg = JSONObject().apply {
                        put("type", "candidate")
                        put("deviceId", deviceId)
                        put("candidate", candidate.sdp)
                        put("sdpMid", candidate.sdpMid)
                        put("sdpMLineIndex", candidate.sdpMLineIndex)
                    }
                    socket?.emit("webrtc:candidate", msg)
                }
                override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
                override fun onAddStream(stream: MediaStream?) {}
                override fun onRemoveStream(stream: MediaStream?) {}
                override fun onDataChannel(dc: DataChannel?) {}
                override fun onRenegotiationNeeded() {
                    Log.d(TAG, "Renegotiation needed")
                    executor.execute { createOffer() }
                }
                override fun onAddTrack(
                    receiver: RtpReceiver?,
                    streams: Array<out MediaStream>?
                ) {}
                override fun onTrack(transceiver: RtpTransceiver?) {}
            }
        )

        val streamId = listOf("stream_$deviceId")
        videoTrack?.let { peerConnection?.addTrack(it, streamId) }
        audioTrack?.let { peerConnection?.addTrack(it, streamId) }

        createOffer()
    }

    private fun createOffer() {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }

        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp ?: return
                peerConnection?.setLocalDescription(object : SdpObserver {
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onSetSuccess() {
                        Log.d(TAG, "Local SDP set — sending offer")
                        val msg = JSONObject().apply {
                            put("type", "offer")
                            put("deviceId", deviceId)
                            put("sdp", sdp.description)
                        }
                        socket?.emit("webrtc:offer", msg)
                    }
                    override fun onCreateFailure(err: String?) {
                        Log.e(TAG, "setLocal fail: $err")
                    }
                    override fun onSetFailure(err: String?) {
                        Log.e(TAG, "setLocal fail: $err")
                    }
                }, sdp)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(err: String?) {
                Log.e(TAG, "createOffer fail: $err")
            }
            override fun onSetFailure(err: String?) {}
        }, constraints)
    }

    // ── Handle answer dari controller ──────────────────────────────
    fun handleAnswer(sdpString: String) {
        executor.execute {
            try {
                val sdp = SessionDescription(SessionDescription.Type.ANSWER, sdpString)
                peerConnection?.setRemoteDescription(object : SdpObserver {
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onSetSuccess() {
                        Log.d(TAG, "Remote SDP set (answer)")
                    }
                    override fun onCreateFailure(err: String?) {
                        Log.e(TAG, "setRemote fail: $err")
                    }
                    override fun onSetFailure(err: String?) {
                        Log.e(TAG, "setRemote fail: $err")
                    }
                }, sdp)
            } catch (e: Exception) {
                Log.e(TAG, "handleAnswer: ${e.message}")
            }
        }
    }

    // ── ICE candidate dari controller ──────────────────────────────
    fun handleRemoteCandidate(sdp: String, sdpMid: String?, sdpMLineIndex: Int) {
        executor.execute {
            try {
                val candidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
                peerConnection?.addIceCandidate(candidate)
            } catch (e: Exception) {
                Log.e(TAG, "handleRemoteCandidate: ${e.message}")
            }
        }
    }

    // ── Stop stream (public) ───────────────────────────────────────
    fun stopStream() {
        _isActive.set(false)
        executor.execute {
            stopStreamInternal()
        }
    }

    // ── Stop internal (harus di executor thread) ───────────────────
    private fun stopStreamInternal() {
        try {
            videoCapturer?.stopCapture()
        } catch (e: Exception) {
            Log.e(TAG, "stopCapture: ${e.message}")
        }
        videoCapturer?.dispose()
        videoCapturer = null

        videoTrack?.dispose()
        videoTrack = null
        videoSource?.dispose()
        videoSource = null

        audioTrack?.dispose()
        audioTrack = null
        audioSource?.dispose()
        audioSource = null

        surfaceTextureHelper?.dispose()
        surfaceTextureHelper = null

        peerConnection?.close()
        peerConnection?.dispose()
        peerConnection = null

        disposeFactory()

        Log.d(TAG, "WebRTC stopped and cleaned up")
    }

    private fun disposeFactory() {
        try {
            factory?.dispose()
        } catch (_: Exception) {}
        factory = null

        try {
            sharedEglBase?.release()
        } catch (_: Exception) {}
        sharedEglBase = null
    }
}