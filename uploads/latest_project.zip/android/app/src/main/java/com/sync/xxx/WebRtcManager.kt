package com.sync.xxx

import android.content.Context
import android.util.Log
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class WebRtcManager(
    private val context: Context,
    private val socket: Socket?,
    private val deviceId: String
) {
    companion object {
        private const val TAG = "WebRtcManager"
        private val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
        // Flag global — pastikan initialize() hanya sekali per proses
        @Volatile private var factoryInitialized = false
    }

    private var sharedEglBase: EglBase? = null
    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null

    // Single-thread executor — semua operasi WebRTC di sini
    private val executor: ExecutorService = Executors.newSingleThreadExecutor { r ->
        Thread(r, "WebRtc-Thread").apply { isDaemon = true }
    }

    private val _isActive = AtomicBoolean(false)
    val isActive: Boolean get() = _isActive.get()

    // ── Initialize factory — HANYA dipanggil sekali ───────────
    private fun initializeOnce() {
        if (!factoryInitialized) {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            factoryInitialized = true
            Log.d(TAG, "PeerConnectionFactory global init done")
        }
    }

    private fun createFactory() {
        disposeFactoryInternal()

        initializeOnce()

        sharedEglBase = EglBase.create()
        val eglCtx = sharedEglBase!!.eglBaseContext

        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(
                DefaultVideoEncoderFactory(eglCtx, true, true)
            )
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglCtx))
            .setOptions(PeerConnectionFactory.Options().apply {
                disableEncryption = false
                disableNetworkMonitor = false
            })
            .createPeerConnectionFactory()

        Log.d(TAG, "Factory created")
    }

    // ── Start stream ──────────────────────────────────────────
    fun startStream(facing: String) {
        executor.execute {
            try {
                if (_isActive.get()) {
                    Log.d(TAG, "Already active, stopping first")
                    stopStreamInternal()
                    Thread.sleep(200) // beri jeda setelah cleanup
                }

                createFactory()
                _isActive.set(true)

                val camEnumerator = Camera2Enumerator(context)
                val deviceNames   = camEnumerator.deviceNames

                val cameraName = deviceNames.firstOrNull { name ->
                    if (facing == "front") camEnumerator.isFrontFacing(name)
                    else !camEnumerator.isFrontFacing(name)
                } ?: deviceNames.firstOrNull()

                if (cameraName == null) {
                    Log.e(TAG, "No camera found")
                    _isActive.set(false)
                    return@execute
                }

                videoCapturer = camEnumerator.createCapturer(cameraName, null)
                    ?: run {
                        Log.e(TAG, "Failed to create capturer")
                        _isActive.set(false)
                        return@execute
                    }

                surfaceTextureHelper = SurfaceTextureHelper.create(
                    "CaptureThread-${System.currentTimeMillis()}",
                    sharedEglBase!!.eglBaseContext
                )

                videoSource = factory!!.createVideoSource(false)
                videoCapturer!!.initialize(
                    surfaceTextureHelper,
                    context,
                    videoSource!!.capturerObserver
                )

                // Resolusi optimal: 720p 30fps untuk no-lag
                videoCapturer!!.startCapture(1280, 720, 30)

                videoTrack = factory!!.createVideoTrack("v0", videoSource)
                videoTrack!!.setEnabled(true)

                val audioConstraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
                }
                audioSource = factory!!.createAudioSource(audioConstraints)
                audioTrack  = factory!!.createAudioTrack("a0", audioSource)
                audioTrack!!.setEnabled(true)

                createPeerConnection()
                Log.d(TAG, "WebRTC stream started, facing=$facing")

            } catch (e: Exception) {
                Log.e(TAG, "startStream error: ${e.message}", e)
                _isActive.set(false)
            }
        }
    }

    // ── PeerConnection ────────────────────────────────────────
    private fun createPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics          = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy          = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy         = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        peerConnection = factory!!.createPeerConnection(
            rtcConfig,
            object : PeerConnection.Observer {
                override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
                override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                    Log.d(TAG, "ICE: $s")
                }
                override fun onIceConnectionReceivingChange(b: Boolean) {}
                override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
                override fun onIceCandidate(candidate: IceCandidate?) {
                    candidate ?: return
                    val msg = JSONObject().apply {
                        put("type", "candidate")
                        put("deviceId", deviceId)
                        put("candidate", candidate.sdp)
                        put("sdpMid", candidate.sdpMid)
                        put("sdpMLineIndex", candidate.sdpMLineIndex)
                    }
                    socket?.emit("webrtc:candidate", msg)
                }
                override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
                override fun onAddStream(s: MediaStream?) {}
                override fun onRemoveStream(s: MediaStream?) {}
                override fun onDataChannel(dc: DataChannel?) {}
                override fun onRenegotiationNeeded() {
                    executor.execute { createOffer() }
                }
                override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
                override fun onTrack(t: RtpTransceiver?) {}
            }
        ) ?: run {
            Log.e(TAG, "Failed to create PeerConnection")
            _isActive.set(false)
            return
        }

        val streamId = listOf("stream_$deviceId")
        videoTrack?.let { peerConnection?.addTrack(it, streamId) }
        audioTrack?.let { peerConnection?.addTrack(it, streamId) }

        createOffer()
    }

    private fun createOffer() {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }

        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp ?: return
                peerConnection?.setLocalDescription(object : SdpObserver {
                    override fun onCreateSuccess(p: SessionDescription?) {}
                    override fun onSetSuccess() {
                        Log.d(TAG, "Local SDP set — sending offer")
                        socket?.emit("webrtc:offer", JSONObject().apply {
                            put("type", "offer")
                            put("deviceId", deviceId)
                            put("sdp", sdp.description)
                        })
                    }
                    override fun onCreateFailure(e: String?) { Log.e(TAG, "setLocal create fail: $e") }
                    override fun onSetFailure(e: String?)    { Log.e(TAG, "setLocal set fail: $e") }
                }, sdp)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(e: String?) { Log.e(TAG, "createOffer fail: $e") }
            override fun onSetFailure(e: String?)    {}
        }, constraints)
    }

    // ── Handle answer ─────────────────────────────────────────
    fun handleAnswer(sdpString: String) {
        executor.execute {
            try {
                val sdp = SessionDescription(SessionDescription.Type.ANSWER, sdpString)
                peerConnection?.setRemoteDescription(object : SdpObserver {
                    override fun onCreateSuccess(p: SessionDescription?) {}
                    override fun onSetSuccess()                          { Log.d(TAG, "Remote SDP set (answer)") }
                    override fun onCreateFailure(e: String?)             { Log.e(TAG, "setRemote fail: $e") }
                    override fun onSetFailure(e: String?)                { Log.e(TAG, "setRemote fail: $e") }
                }, sdp)
            } catch (e: Exception) {
                Log.e(TAG, "handleAnswer: ${e.message}")
            }
        }
    }

    // ── Handle remote ICE candidate ───────────────────────────
    fun handleRemoteCandidate(sdp: String, sdpMid: String?, sdpMLineIndex: Int) {
        executor.execute {
            try {
                peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
            } catch (e: Exception) {
                Log.e(TAG, "handleRemoteCandidate: ${e.message}")
            }
        }
    }

    // ── Stop (public) ─────────────────────────────────────────
    fun stopStream() {
        _isActive.set(false)
        executor.execute { stopStreamInternal() }
    }

    // ── Stop internal ─────────────────────────────────────────
    private fun stopStreamInternal() {
        Log.d(TAG, "stopStreamInternal")

        // 1. Stop capture dulu sebelum dispose apapun
        try { videoCapturer?.stopCapture() } catch (e: Exception) { Log.e(TAG, "stopCapture: ${e.message}") }

        // 2. Close peer connection SEBELUM dispose track/source
        try { peerConnection?.close() }   catch (_: Exception) {}
        try { peerConnection?.dispose() } catch (_: Exception) {}
        peerConnection = null

        // 3. Dispose track
        try { videoTrack?.dispose() } catch (_: Exception) {}
        videoTrack = null

        try { audioTrack?.dispose() } catch (_: Exception) {}
        audioTrack = null

        // 4. Dispose capturer
        try { videoCapturer?.dispose() } catch (_: Exception) {}
        videoCapturer = null

        // 5. Dispose source SETELAH capturer
        try { videoSource?.dispose() } catch (_: Exception) {}
        videoSource = null

        try { audioSource?.dispose() } catch (_: Exception) {}
        audioSource = null

        // 6. Dispose SurfaceTextureHelper SETELAH source
        try { surfaceTextureHelper?.dispose() } catch (_: Exception) {}
        surfaceTextureHelper = null

        // 7. Terakhir dispose factory & EglBase
        disposeFactoryInternal()

        Log.d(TAG, "WebRTC fully stopped")
    }

    private fun disposeFactoryInternal() {
        try { factory?.dispose() } catch (_: Exception) {}
        factory = null

        // Delay sedikit sebelum release EglBase — beri waktu encoder flush
        Thread.sleep(50)
        try { sharedEglBase?.release() } catch (_: Exception) {}
        sharedEglBase = null
    }
}