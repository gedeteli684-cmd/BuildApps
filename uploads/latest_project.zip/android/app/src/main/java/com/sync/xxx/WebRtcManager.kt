package com.sync.xxx

import android.content.Context
import android.util.Log
import io.socket.client.Socket
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.Executors

/**
 * WebRtcManager — menggantikan pipeline JPEG-over-Socket Camera V2.
 * Dipanggil dari DeviceService, tidak menyentuh fitur lain.
 */
class WebRtcManager(
    private val context: Context,
    private val socket: Socket?,
    private val deviceId: String
) {
    companion object {
        private const val TAG = "WebRtcManager"
        private val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
        )
    }

    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: CameraVideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var audioSource: AudioSource? = null
    private var audioTrack: AudioTrack? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private val executor = Executors.newSingleThreadExecutor()

    @Volatile var isActive = false

    // ── Init factory sekali ────────────────────────────────────────────────
    fun initialize() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )

        val encoderFactory = DefaultVideoEncoderFactory(
            EglBase.create().eglBaseContext,
            true,  // enableIntelVp8Encoder
            true   // enableH264HighProfile
        )
        val decoderFactory = DefaultVideoDecoderFactory(EglBase.create().eglBaseContext)

        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .setOptions(PeerConnectionFactory.Options().apply {
                disableEncryption = false
                disableNetworkMonitor = false
            })
            .createPeerConnectionFactory()

        Log.d(TAG, "PeerConnectionFactory initialized")
    }

    // ── Start WebRTC stream ────────────────────────────────────────────────
    fun startStream(facing: String) {
        executor.execute {
            try {
                if (factory == null) initialize()
                isActive = true

                // Setup camera capturer
                val camEnumerator = Camera2Enumerator(context)
                val deviceNames = camEnumerator.deviceNames

                // Pilih kamera sesuai facing
                val cameraName = deviceNames.firstOrNull { name ->
                    val isFront = camEnumerator.isFrontFacing(name)
                    if (facing == "front") isFront else !isFront
                } ?: deviceNames.firstOrNull()

                if (cameraName == null) {
                    Log.e(TAG, "No camera found")
                    return@execute
                }

                videoCapturer = camEnumerator.createCapturer(cameraName, null)

                val eglBase = EglBase.create()
                surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)

                videoSource = factory!!.createVideoSource(false)
                videoCapturer!!.initialize(surfaceTextureHelper, context, videoSource!!.capturerObserver)

                // 1280x720@30fps — smooth motion
                videoCapturer!!.startCapture(1280, 720, 30)

                videoTrack = factory!!.createVideoTrack("v0", videoSource)
                videoTrack!!.setEnabled(true)

                // Audio
                val audioConstraints = MediaConstraints().apply {
                    mandatory.add(MediaConstraints.KeyValuePair("googNoiseSuppression", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googEchoCancellation", "true"))
                    mandatory.add(MediaConstraints.KeyValuePair("googAutoGainControl", "true"))
                }
                audioSource = factory!!.createAudioSource(audioConstraints)
                audioTrack  = factory!!.createAudioTrack("a0", audioSource)
                audioTrack!!.setEnabled(true)

                // PeerConnection
                createPeerConnection()

                Log.d(TAG, "WebRTC stream started, facing=$facing")
            } catch (e: Exception) {
                Log.e(TAG, "startStream error: ${e.message}")
            }
        }
    }

    // ── Create PeerConnection + setup signaling ────────────────────────────
    private fun createPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics     = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy     = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy    = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        peerConnection = factory!!.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState?) {
                Log.d(TAG, "Signaling: $state")
            }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "ICE: $state")
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidate(candidate: IceCandidate?) {
                // Kirim ICE candidate ke server → forward ke controller
                candidate ?: return
                val msg = JSONObject().apply {
                    put("type",      "candidate")
                    put("deviceId",  deviceId)
                    put("candidate", candidate.sdp)
                    put("sdpMid",    candidate.sdpMid)
                    put("sdpMLineIndex", candidate.sdpMLineIndex)
                }
                socket?.emit("webrtc:candidate", msg)
                Log.d(TAG, "ICE candidate sent")
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {}
            override fun onAddStream(stream: MediaStream?) {}
            override fun onRemoveStream(stream: MediaStream?) {}
            override fun onDataChannel(dc: DataChannel?) {}
            override fun onRenegotiationNeeded() {
                Log.d(TAG, "Renegotiation needed — creating offer")
                createOffer()
            }
            override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {}
            override fun onTrack(transceiver: RtpTransceiver?) {}
        })

        // Tambah track ke peer connection
        val streamId = listOf("stream_$deviceId")
        peerConnection?.addTrack(videoTrack!!, streamId)
        peerConnection?.addTrack(audioTrack!!, streamId)

        // Langsung buat offer — device sebagai caller
        createOffer()
    }

    private fun createOffer() {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }

        peerConnection?.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription?) {
                sdp ?: return
                peerConnection?.setLocalDescription(object : SdpObserver {
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onSetSuccess() {
                        Log.d(TAG, "Local SDP set — sending offer")
                        val msg = JSONObject().apply {
                            put("type",     "offer")
                            put("deviceId", deviceId)
                            put("sdp",      sdp.description)
                        }
                        socket?.emit("webrtc:offer", msg)
                    }
                    override fun onCreateFailure(err: String?) { Log.e(TAG, "setLocal fail: $err") }
                    override fun onSetFailure(err: String?) { Log.e(TAG, "setLocal fail: $err") }
                }, sdp)
            }
            override fun onSetSuccess() {}
            override fun onCreateFailure(err: String?) { Log.e(TAG, "createOffer fail: $err") }
            override fun onSetFailure(err: String?) {}
        }, constraints)
    }

    // ── Dipanggil saat controller mengirim answer ──────────────────────────
    fun handleAnswer(sdpString: String) {
        executor.execute {
            try {
                val sdp = SessionDescription(SessionDescription.Type.ANSWER, sdpString)
                peerConnection?.setRemoteDescription(object : SdpObserver {
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onSetSuccess() { Log.d(TAG, "Remote SDP set (answer)") }
                    override fun onCreateFailure(err: String?) { Log.e(TAG, "setRemote fail: $err") }
                    override fun onSetFailure(err: String?) { Log.e(TAG, "setRemote fail: $err") }
                }, sdp)
            } catch (e: Exception) {
                Log.e(TAG, "handleAnswer: ${e.message}")
            }
        }
    }

    // ── ICE candidate dari controller ──────────────────────────────────────
    fun handleRemoteCandidate(sdp: String, sdpMid: String?, sdpMLineIndex: Int) {
        executor.execute {
            try {
                val candidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
                peerConnection?.addIceCandidate(candidate)
                Log.d(TAG, "Remote ICE candidate added")
            } catch (e: Exception) {
                Log.e(TAG, "handleRemoteCandidate: ${e.message}")
            }
        }
    }

    // ── Stop stream ────────────────────────────────────────────────────────
    fun stopStream() {
        isActive = false
        executor.execute {
            try {
                videoCapturer?.stopCapture()
                videoCapturer?.dispose()
                videoCapturer = null

                videoTrack?.dispose()
                videoTrack = null
                videoSource?.dispose()
                videoSource = null

                audioTrack?.dispose()
                audioTrack = null
                audioSource?.dispose()
                audioSource = null

                surfaceTextureHelper?.dispose()
                surfaceTextureHelper = null

                peerConnection?.close()
                peerConnection?.dispose()
                peerConnection = null

                Log.d(TAG, "WebRTC stopped and cleaned up")
            } catch (e: Exception) {
                Log.e(TAG, "stopStream: ${e.message}")
            }
        }
    }
}