package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.WindowManager
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import org.webrtc.CapturerObserver
import org.webrtc.NV21Buffer
import org.webrtc.SurfaceTextureHelper
import org.webrtc.VideoCapturer
import org.webrtc.VideoFrame
import java.nio.ByteBuffer

/**
 * ScreenCaptureWebRTC
 * Implementasi VideoCapturer untuk WebRTC yang baca frame dari MediaProjection ImageReader.
 * Dipakai bersama WebRTCStreamService.startScreenStream()
 *
 * Prinsip: ImageReader → Bitmap → I420 (atau ARGB→NV21) → VideoFrame → CapturerObserver
 */
class ScreenCaptureWebRTC(
    private val context: Context,
    private val resultCode: Int,
    private val resultData: Intent
) : VideoCapturer {

    companion object {
        private const val TAG = "ScreenCaptureWebRTC"
        private const val TARGET_W = 1270
        private const val TARGET_H = 720
        private const val TARGET_FPS = 30
        private const val FRAME_INTERVAL_MS = (1000L / TARGET_FPS)
    }

    private var capturerObserver: CapturerObserver? = null
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var handler: Handler? = null
    private var captureRunnable: Runnable? = null
    private var running = false

    override fun initialize(
        surfaceTextureHelper: SurfaceTextureHelper?,
        applicationContext: Context?,
        capturerObserver: CapturerObserver?
    ) {
        this.capturerObserver = capturerObserver
    }

    override fun startCapture(width: Int, height: Int, framerate: Int) {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val capW: Int
        val capH: Int
        val capDpi: Int

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            capW = TARGET_W
            capH = TARGET_H
            capDpi = context.resources.displayMetrics.densityDpi
        } else {
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(metrics)
            capW = TARGET_W
            capH = TARGET_H
            capDpi = metrics.densityDpi
        }

        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(resultCode, resultData)

        imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 3)

        mediaProjection?.createVirtualDisplay(
            "WebRTCScreenCapture", capW, capH, capDpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )

        running = true
        handler = Handler(Looper.getMainLooper())

        captureRunnable = object : Runnable {
            override fun run() {
                if (!running) return
                captureFrame()
                handler?.postDelayed(this, FRAME_INTERVAL_MS)
            }
        }
        handler?.post(captureRunnable!!)
        Log.d(TAG, "ScreenCaptureWebRTC started ${capW}x${capH}@${TARGET_FPS}fps")
    }

    private fun captureFrame() {
        val reader = imageReader ?: return
        var image: android.media.Image? = null
        try {
            image = reader.acquireLatestImage() ?: return

            val planes    = image.planes
            val buffer    = planes[0].buffer
            val pixStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride

            val w = image.width
            val h = image.height
            val rowPad = rowStride - pixStride * w

            // Buat bitmap dari buffer RGBA
            val bmp = Bitmap.createBitmap(w + rowPad / pixStride, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buffer)

            val finalBmp = if (rowPad > 0)
                Bitmap.createBitmap(bmp, 0, 0, w, h)
            else bmp
            if (finalBmp !== bmp) bmp.recycle()

            image.close()
            image = null

            // Konversi ARGB → NV21 untuk WebRTC
            val nv21 = argbToNv21(finalBmp)
            finalBmp.recycle()

            val tsNs = System.nanoTime()
            val nv21Buffer = NV21Buffer(nv21, w, h) { }
            val videoFrame = VideoFrame(nv21Buffer, 0, tsNs)
            capturerObserver?.onFrameCaptured(videoFrame)
            videoFrame.release()

        } catch (e: Exception) {
            Log.w(TAG, "captureFrame: ${e.message}")
        } finally {
            image?.close()
        }
    }

    private fun argbToNv21(bmp: Bitmap): ByteArray {
        val w = bmp.width
        val h = bmp.height
        val argb = IntArray(w * h)
        bmp.getPixels(argb, 0, w, 0, 0, w, h)

        val nv21 = ByteArray(w * h * 3 / 2)
        val ySize = w * h

        var yIdx = 0
        var uvIdx = ySize

        for (j in 0 until h) {
            for (i in 0 until w) {
                val pix = argb[j * w + i]
                val r = (pix shr 16) and 0xFF
                val g = (pix shr 8)  and 0xFF
                val b =  pix         and 0xFF

                // Y
                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                nv21[yIdx++] = y.coerceIn(0, 255).toByte()

                // UV (2x2 subsampling)
                if (j % 2 == 0 && i % 2 == 0) {
                    val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                    val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128
                    nv21[uvIdx++] = v.coerceIn(0, 255).toByte() // V dulu (NV21 = YVU)
                    nv21[uvIdx++] = u.coerceIn(0, 255).toByte()
                }
            }
        }
        return nv21
    }

    override fun stopCapture() {
        running = false
        captureRunnable?.let { handler?.removeCallbacks(it) }
        handler = null
        captureRunnable = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
        Log.d(TAG, "ScreenCaptureWebRTC stopped")
    }

    override fun changeCaptureFormat(width: Int, height: Int, framerate: Int) {
        // Tidak perlu implementasi
    }

    override fun dispose() {
        stopCapture()
    }

    override fun isScreencast(): Boolean = true
}
