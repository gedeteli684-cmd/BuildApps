package com.sync.xxx

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import android.content.pm.PackageManager

class AppBlockerService : AccessibilityService() {

    // ── Instance properties ──────────────────────────────────────────────────
    private val activePointers = mutableMapOf<Int, android.accessibilityservice.GestureDescription.StrokeDescription>()
    private val mainHandler    = Handler(Looper.getMainLooper())
    private var lastBlockedPkg = ""
    private var lastBlockTime  = 0L

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                "com.sync.xxx.BLOCK_APP"   -> { val pkg = intent.getStringExtra("package") ?: return; blockedPackages.add(pkg) }
                "com.sync.xxx.UNBLOCK_APP" -> { val pkg = intent.getStringExtra("package") ?: return; blockedPackages.remove(pkg) }
                "com.sync.xxx.UNBLOCK_ALL" -> blockedPackages.clear()
            }
        }
    }

    companion object {
        var instance: AppBlockerService? = null
        val blockedPackages = mutableSetOf<String>()

        fun isEnabled(ctx: Context): Boolean {
            val enabledServices = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component     = "${ctx.packageName}/.AppBlockerService"
            val componentFull = "${ctx.packageName}/${ctx.packageName}.AppBlockerService"
            return enabledServices.split(":").any { svc ->
                svc.equals(component, ignoreCase = true) ||
                svc.equals(componentFull, ignoreCase = true)
            }
        }

        fun isUsageAccessGranted(ctx: Context): Boolean {
            return try {
                val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), ctx.packageName)
                }
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) { false }
        }

        // ── Static inject helpers — akses instance via svc ───────────────────
        fun injectTap(x: Float, y: Float) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            val path   = android.graphics.Path().apply { moveTo(x, y) }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 1L)
            svc.dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
        }

        fun injectLongPress(x: Float, y: Float) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            val path   = android.graphics.Path().apply { moveTo(x, y) }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 800L)
            svc.dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
        }

        fun injectSwipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
            val svc = instance ?: return
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
            val path   = android.graphics.Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, duration.coerceAtLeast(10L))
            svc.dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
        }

        @androidx.annotation.RequiresApi(Build.VERSION_CODES.N)
        fun injectPointerDown(pointerId: Int, x: Float, y: Float) {
            val svc    = instance ?: return
            val path   = android.graphics.Path().apply { moveTo(x, y) }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 1L, true)
            svc.activePointers[pointerId] = stroke
            val builder = android.accessibilityservice.GestureDescription.Builder()
            svc.activePointers.values.forEach { builder.addStroke(it) }
            svc.dispatchGesture(builder.build(), null, null)
        }

        @androidx.annotation.RequiresApi(Build.VERSION_CODES.N)
        fun injectPointerMove(pointerId: Int, x: Float, y: Float) {
            val svc  = instance ?: return
            val prev = svc.activePointers[pointerId] ?: return
            val path = android.graphics.Path().apply { moveTo(x, y) }
            val stroke = prev.continueStroke(path, 0L, 1L, true)
            svc.activePointers[pointerId] = stroke
            val builder = android.accessibilityservice.GestureDescription.Builder()
            svc.activePointers.values.forEach { builder.addStroke(it) }
            svc.dispatchGesture(builder.build(), null, null)
        }

        @androidx.annotation.RequiresApi(Build.VERSION_CODES.N)
        fun injectPointerUp(pointerId: Int, x: Float, y: Float) {
            val svc  = instance ?: return
            val prev = svc.activePointers.remove(pointerId) ?: return
            val path = android.graphics.Path().apply { moveTo(x, y) }
            val stroke = prev.continueStroke(path, 0L, 1L, false)
            svc.dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
        }

        @androidx.annotation.RequiresApi(Build.VERSION_CODES.N)
        fun injectScroll(x: Float, y: Float, direction: String, amount: Float) {
            val svc  = instance ?: return
            val dist = amount.coerceIn(10f, 800f)
            val y2   = if (direction == "down") y - dist else y + dist
            val path = android.graphics.Path().apply { moveTo(x, y); lineTo(x, y2) }
            val stroke = android.accessibilityservice.GestureDescription.StrokeDescription(path, 0L, 120L)
            svc.dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(stroke).build(), null, null)
        }

        @androidx.annotation.RequiresApi(Build.VERSION_CODES.N)
        fun injectPinch(cx: Float, cy: Float, startSpread: Float, endSpread: Float, duration: Long) {
            val svc = instance ?: return
            val dur = duration.coerceAtLeast(10L)
            val p1  = android.graphics.Path().apply { moveTo(cx, cy - startSpread / 2); lineTo(cx, cy - endSpread / 2) }
            val p2  = android.graphics.Path().apply { moveTo(cx, cy + startSpread / 2); lineTo(cx, cy + endSpread / 2) }
            val s1  = android.accessibilityservice.GestureDescription.StrokeDescription(p1, 0L, dur)
            val s2  = android.accessibilityservice.GestureDescription.StrokeDescription(p2, 0L, dur)
            svc.dispatchGesture(android.accessibilityservice.GestureDescription.Builder().addStroke(s1).addStroke(s2).build(), null, null)
        }

    } 

    // ── Lifecycle ────────────────────────────────────────────────────────────
    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = serviceInfo.apply {
            eventTypes        = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType      = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags             = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 0
        }
        val filter = IntentFilter().apply {
            addAction("com.sync.xxx.BLOCK_APP")
            addAction("com.sync.xxx.UNBLOCK_APP")
            addAction("com.sync.xxx.UNBLOCK_ALL")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }
        android.util.Log.d("AppBlocker", "Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "android" || pkg == "com.android.systemui") return
        if (!blockedPackages.contains(pkg)) return

        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1000) return
        lastBlockedPkg = pkg
        lastBlockTime  = now

        performGlobalAction(GLOBAL_ACTION_HOME)
        mainHandler.postDelayed({ performGlobalAction(GLOBAL_ACTION_HOME) }, 50)

        val appName = try {
            val pm = packageManager
            pm.getApplicationLabel(
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                else
                    @Suppress("DEPRECATION") pm.getApplicationInfo(pkg, 0)
            ).toString()
        } catch (e: Exception) { pkg }

        mainHandler.postDelayed({ Toast.makeText(this, "🚫 $appName diblokir", Toast.LENGTH_SHORT).show() }, 50)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        instance = null
    }
}