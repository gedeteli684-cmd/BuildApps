package com.sync.xxx

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val validActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            "android.intent.action.MY_PACKAGE_REPLACED"
        )
        if (intent?.action !in validActions) return

        // Start service dulu — restore lock state jalan di sini
        val serviceIntent = Intent(context, DeviceService::class.java)
        ContextCompat.startForegroundService(context, serviceIntent)

        // Launch MainActivity agar aplikasi tampil kembali setelah restart
        val mainIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            )
        }
        context.startActivity(mainIntent)
    }
}
