package com.sync.xxx

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject

/**
 * RemoteControlService
 * Menerima broadcast "com.sync.xxx.REMOTE_GESTURE" dari DeviceService
 * dan mengeksekusi gesture nyata via performGesture() / performGlobalAction()
 *
 * Payload JSON di broadcast extra "payload":
 * { type: "tap"|"swipe"|"longPress"|"scroll"|"back"|"home"|"recents"|"power" ,
 *   x: Float, y: Float,          -- koordinat layar asli
 *   x2: Float, y2: Float,        -- end point (swipe)
 *   duration: Long (ms)          -- optional
 * }
 */
class RemoteControlService : AccessibilityService() {

    companion object {
        var instance: RemoteControlService? = null

        const val ACTION_GESTURE = "com.sync.xxx.REMOTE_GESTURE"
        const val EXTRA_PAYLOAD  = "payload"

        fun isEnabled(ctx: Context): Boolean {
            val enabled = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val comp  = "${ctx.packageName}/.RemoteControlService"
            val compF = "${ctx.packageName}/${ctx.packageName}.RemoteControlService"
            return enabled.split(":").any {
                it.equals(comp, ignoreCase = true) || it.equals(compF, ignoreCase = true)
            }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private val gestureReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != ACTION_GESTURE) return
            val raw = intent.getStringExtra(EXTRA_PAYLOAD) ?: return
            try {
                handlePayload(JSONObject(raw))
            } catch (e: Exception) {
                android.util.Log.e("RemoteControl", "payload parse error: ${e.message}")
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        serviceInfo = serviceInfo?.apply {
            eventTypes              = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                                      AccessibilityEvent.TYPE_VIEW_CLICKED
            feedbackType            = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags                   = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                                      AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE
            notificationTimeout     = 0
        }

        val filter = IntentFilter(ACTION_GESTURE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(gestureReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(gestureReceiver, filter)
        }
        android.util.Log.d("RemoteControl", "Service connected — gesture control ready")
    }

    private fun handlePayload(p: JSONObject) {
        val type     = p.optString("type", "tap")
        val x        = p.optDouble("x", 0.0).toFloat()
        val y        = p.optDouble("y", 0.0).toFloat()
        val x2       = p.optDouble("x2", x.toDouble()).toFloat()
        val y2       = p.optDouble("y2", y.toDouble()).toFloat()
        val duration = p.optLong("duration", 100L)

        when (type) {
            "tap"       -> doTap(x, y)
            "longPress" -> doLongPress(x, y)
            "swipe"     -> doSwipe(x, y, x2, y2, duration)
            "scroll"    -> doSwipe(x, y, x2, y2, duration.coerceAtLeast(300L))
            "back"      -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home"      -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents"   -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "power"     -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            "notif"     -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "qsettings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            else        -> doTap(x, y)
        }
    }

    // ── Gesture builders ───────────────────────────────────────────────

    private fun doTap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun doLongPress(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 750L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun doSwipe(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, dur)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    // ── Accessibility boilerplate ───────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* unused */ }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(gestureReceiver) } catch (_: Exception) {}
        instance = null
    }
}
