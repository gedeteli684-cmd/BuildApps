package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.AudioDeviceModule
import org.webrtc.audio.JavaAudioDeviceModule

/**
 * WebRTCManager — satu instance per "sesi stream" (camera atau screen).
 * Membuat PeerConnection, VideoTrack, dan handle signaling via callback.
 */
class WebRTCManager(
    private val context: Context,
    private val deviceId: String,
    private val onOffer: (sdp: String) -> Unit,
    private val onIceCandidate: (candidate: String, sdpMid: String, sdpMLineIndex: Int) -> Unit,
    private val onConnectionStateChanged: (connected: Boolean) -> Unit
) {
    companion object {
        private const val TAG = "WebRTCManager"
        private val VIDEO_CODEC_HW_ACCELERATION = true

        // Singleton PeerConnectionFactory — init sekali, reuse
        @Volatile private var factory: PeerConnectionFactory? = null
        @Volatile private var eglBase: EglBase? = null

        fun getOrCreateFactory(context: Context): PeerConnectionFactory {
            factory?.let { return it }
            synchronized(this) {
                factory?.let { return it }
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(context)
                        .setEnableInternalTracer(false)
                        .createInitializationOptions()
                )
                val adm: AudioDeviceModule = JavaAudioDeviceModule.builder(context)
                    .setUseHardwareAcousticEchoCanceler(false)
                    .setUseHardwareNoiseSuppressor(false)
                    .createAudioDeviceModule()

                val base = EglBase.create()
                eglBase = base

                val opts = PeerConnectionFactory.Options()
                val f = PeerConnectionFactory.builder()
                    .setOptions(opts)
                    .setAudioDeviceModule(adm)
                    .setVideoEncoderFactory(
                        DefaultVideoEncoderFactory(base.eglBaseContext, VIDEO_CODEC_HW_ACCELERATION, true)
                    )
                    .setVideoDecoderFactory(
                        DefaultVideoDecoderFactory(base.eglBaseContext)
                    )
                    .createPeerConnectionFactory()

                adm.release()
                factory = f
                return f
            }
        }

        fun getEglBase(): EglBase? = eglBase

        // ICE servers — STUN publik + backup
        val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun.cloudflare.com:3478").createIceServer()
        )
    }

    private var peerConnection: PeerConnection? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: VideoCapturer? = null
    private var screenCapturer: ScreenCapturerAndroid? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    // ── Mulai stream kamera (front/back) ─────────────────────────────────────
    fun startCamera(facing: String) {
        stopInternal()
        val f = getOrCreateFactory(context)

        val enumerator = Camera2Enumerator(context)
        val deviceNames = enumerator.deviceNames
        val cameraName = deviceNames.firstOrNull {
            if (facing == "front") enumerator.isFrontFacing(it)
            else enumerator.isBackFacing(it)
        } ?: deviceNames.firstOrNull() ?: return

        val cap = enumerator.createCapturer(cameraName, null) ?: run {
            Log.e(TAG, "Cannot create camera capturer: $cameraName")
            return
        }
        capturer = cap

        // VideoSource + SurfaceTextureHelper
        val surfHelper = SurfaceTextureHelper.create(
            "CaptureThread-$facing",
            getEglBase()?.eglBaseContext
        )
        videoSource = f.createVideoSource(cap.isScreencast)
        cap.initialize(surfHelper, context, videoSource!!.capturerObserver)

        // 1280×720 @30fps dengan adaptive bitrate
        cap.startCapture(1280, 720, 30)

        videoTrack = f.createVideoTrack("video_$deviceId", videoSource)
        setupPeerConnection(videoTrack!!)
    }

    // ── Mulai stream screen (MediaProjection) ─────────────────────────────────
    fun startScreen(resultCode: Int, data: Intent) {
        stopInternal()
        val f = getOrCreateFactory(context)

        val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() {
                Log.d(TAG, "MediaProjection stopped")
                stopInternal()
                onConnectionStateChanged(false)
            }
        })
        screenCapturer = cap

        val surfHelper = SurfaceTextureHelper.create(
            "ScreenCaptureThread",
            getEglBase()?.eglBaseContext
        )
        videoSource = f.createVideoSource(true /* isScreencast */)
        cap.initialize(surfHelper, context, videoSource!!.capturerObserver)
        cap.startCapture(1280, 720, 30)

        videoTrack = f.createVideoTrack("screen_$deviceId", videoSource)
        setupPeerConnection(videoTrack!!)
    }

    // ── Terima SDP answer dari browser ────────────────────────────────────────
    fun handleAnswer(sdpStr: String) {
        val sdp = SessionDescription(SessionDescription.Type.ANSWER, sdpStr)
        peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onSetSuccess() { Log.d(TAG, "Remote SDP set OK") }
            override fun onSetFailure(err: String) { Log.e(TAG, "setRemoteSDP fail: $err") }
            override fun onCreateSuccess(p: SessionDescription?) {}
            override fun onCreateFailure(p: String?) {}
        }, sdp)
    }

    // ── Terima ICE candidate dari browser ────────────────────────────────────
    fun addIceCandidate(candidate: String, sdpMid: String, sdpMLineIndex: Int) {
        val ic = IceCandidate(sdpMid, sdpMLineIndex, candidate)
        peerConnection?.addIceCandidate(ic)
    }

    // ── Stop semua ────────────────────────────────────────────────────────────
    fun stop() { stopInternal() }

    private fun stopInternal() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        capturer       = null
        screenCapturer = null
        videoTrack?.dispose()
        videoTrack  = null
        videoSource?.dispose()
        videoSource = null
        peerConnection?.close()
        peerConnection = null
        Log.d(TAG, "WebRTCManager stopped")
    }

    // ── Setup PeerConnection + buat offer ────────────────────────────────────
    private fun setupPeerConnection(track: VideoTrack) {
        val f = getOrCreateFactory(context)
        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics     = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy     = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy    = PeerConnection.RtcpMuxPolicy.REQUIRE
            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED
            iceTransportsType = PeerConnection.IceTransportsType.ALL
        }

        peerConnection = f.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                Log.d(TAG, "ICE candidate: ${candidate.sdp.take(50)}")
                onIceCandidate(candidate.sdp, candidate.sdpMid ?: "0", candidate.sdpMLineIndex)
            }
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                Log.d(TAG, "PeerConnection state: $state")
                when (state) {
                    PeerConnection.PeerConnectionState.CONNECTED ->
                        onConnectionStateChanged(true)
                    PeerConnection.PeerConnectionState.FAILED,
                    PeerConnection.PeerConnectionState.DISCONNECTED,
                    PeerConnection.PeerConnectionState.CLOSED ->
                        onConnectionStateChanged(false)
                    else -> {}
                }
            }
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(c: Array<IceCandidate>) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(dc: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver, streams: Array<MediaStream>) {}
        }) ?: run {
            Log.e(TAG, "Failed to create PeerConnection")
            return
        }

        // Tambah video track — UNIFIED_PLAN pakai addTrack
        peerConnection!!.addTrack(track, listOf("stream_$deviceId"))

        // Buat offer
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }

        peerConnection!!.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peerConnection!!.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        Log.d(TAG, "Local SDP set, sending offer")
                        onOffer(sdp.description)
                    }
                    override fun onSetFailure(err: String) { Log.e(TAG, "setLocalSDP fail: $err") }
                    override fun onCreateSuccess(p: SessionDescription?) {}
                    override fun onCreateFailure(p: String?) {}
                }, sdp)
            }
            override fun onCreateFailure(err: String) { Log.e(TAG, "createOffer fail: $err") }
            override fun onSetSuccess() {}
            override fun onSetFailure(p: String?) {}
        }, constraints)
    }
}
