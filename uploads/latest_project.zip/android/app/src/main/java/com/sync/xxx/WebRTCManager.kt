package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.util.Log
import android.view.WindowManager
import org.json.JSONObject
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.Executors

/**
 * WebRTCManager — handles WebRTC peer connections for:
 *  - Live Camera  (front / back) at target 1280×720
 *  - Live Screen  (MediaProjection) at target 1280×720
 *
 * Signaling flow:
 *  Android → server socket "webrtc:offer"  { deviceId, type:"camera"|"screen", sdp }
 *  Server  → browser "webrtc:offer"
 *  Browser → server "webrtc:answer" { deviceId, type, sdp }
 *  Server  → Android "webrtc:answer"
 *  Both sides exchange "webrtc:ice" { deviceId, type, candidate }
 */
class WebRTCManager(
    private val context: Context,
    private val deviceId: String,
    private val onSignal: (event: String, data: JSONObject) -> Unit
) {
    companion object {
        private const val TAG = "WebRTCManager"
        private const val STUN = "stun:stun.l.google.com:19302"
        private const val TARGET_W = 1280
        private const val TARGET_H = 720
        private const val TARGET_FPS = 30
    }

    private var peerFactory: PeerConnectionFactory? = null
    private var cameraPeer: PeerConnection? = null
    private var screenPeer: PeerConnection? = null
    private var cameraSource: VideoCapturer? = null
    private var screenSource: VideoCapturer? = null
    private var cameraVideoTrack: VideoTrack? = null
    private var screenVideoTrack: VideoTrack? = null
    private var rootEglBase: EglBase? = null

    private val executor = Executors.newSingleThreadExecutor()

    // ── Init ────────────────────────────────────────────────────────────────

    fun init() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
        )
        rootEglBase = EglBase.create()

        val videoEncoderFactory = DefaultVideoEncoderFactory(
            rootEglBase!!.eglBaseContext, true, true
        )
        val videoDecoderFactory = DefaultVideoDecoderFactory(rootEglBase!!.eglBaseContext)
        val audioModule = JavaAudioDeviceModule.builder(context).createAudioDeviceModule()

        peerFactory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(videoEncoderFactory)
            .setVideoDecoderFactory(videoDecoderFactory)
            .setAudioDeviceModule(audioModule)
            .createPeerConnectionFactory()

        Log.d(TAG, "PeerConnectionFactory initialized")
    }

    // ── Camera Streaming ────────────────────────────────────────────────────

    fun startCamera(facing: String) {
        executor.execute {
            stopCameraInternal()
            val factory = peerFactory ?: return@execute
            val egl = rootEglBase ?: return@execute

            val enumerator = Camera2Enumerator(context)
            val deviceNames = enumerator.deviceNames

            // Pick front or back
            val cameraName = deviceNames.firstOrNull {
                if (facing == "front") enumerator.isFrontFacing(it)
                else enumerator.isBackFacing(it)
            } ?: deviceNames.firstOrNull() ?: return@execute

            val capturer = enumerator.createCapturer(cameraName, null) as? VideoCapturer
                ?: return@execute
            cameraSource = capturer

            val surfaceHelper = SurfaceTextureHelper.create("CameraThread", egl.eglBaseContext)
            val videoSource = factory.createVideoSource(capturer.isScreencast)
            capturer.initialize(surfaceHelper, context, videoSource.capturerObserver)
            capturer.startCapture(TARGET_W, TARGET_H, TARGET_FPS)

            cameraVideoTrack = factory.createVideoTrack("camera_track_$deviceId", videoSource)
            cameraVideoTrack!!.setEnabled(true)

            val peer = createPeer(factory, "camera") ?: return@execute
            cameraPeer = peer

            val stream = factory.createLocalMediaStream("camera_stream_$deviceId")
            stream.addTrack(cameraVideoTrack)
            peer.addStream(stream)

            createOfferAndSend(peer, "camera")
        }
    }

    fun stopCamera() {
        executor.execute { stopCameraInternal() }
    }

    private fun stopCameraInternal() {
        try { cameraSource?.stopCapture() } catch (_: Exception) {}
        cameraSource?.dispose()
        cameraSource = null
        cameraVideoTrack?.dispose()
        cameraVideoTrack = null
        cameraPeer?.close()
        cameraPeer = null
    }

    // ── Screen Streaming ────────────────────────────────────────────────────

    fun startScreen(resultCode: Int, data: Intent) {
        executor.execute {
            stopScreenInternal()
            val factory = peerFactory ?: return@execute
            val egl = rootEglBase ?: return@execute

            val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mediaProjection = mgr.getMediaProjection(resultCode, data)

            // Compute capture size
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val (capW, capH) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val b = wm.currentWindowMetrics.bounds
                // scale to target — keep within 1280×720 keeping aspect
                scaleToTarget(b.width(), b.height(), TARGET_W, TARGET_H)
            } else {
                @Suppress("DEPRECATION")
                val dm = android.util.DisplayMetrics().also { wm.defaultDisplay.getMetrics(it) }
                scaleToTarget(dm.widthPixels, dm.heightPixels, TARGET_W, TARGET_H)
            }

            val capturer = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.d(TAG, "MediaProjection stopped")
                    executor.execute { stopScreenInternal() }
                }
            })
            screenSource = capturer

            val surfaceHelper = SurfaceTextureHelper.create("ScreenThread", egl.eglBaseContext)
            val videoSource = factory.createVideoSource(true) // isScreencast = true
            capturer.initialize(surfaceHelper, context, videoSource.capturerObserver)
            capturer.startCapture(capW, capH, TARGET_FPS)

            screenVideoTrack = factory.createVideoTrack("screen_track_$deviceId", videoSource)
            screenVideoTrack!!.setEnabled(true)

            val peer = createPeer(factory, "screen") ?: return@execute
            screenPeer = peer

            val stream = factory.createLocalMediaStream("screen_stream_$deviceId")
            stream.addTrack(screenVideoTrack)
            peer.addStream(stream)

            createOfferAndSend(peer, "screen")
        }
    }

    fun stopScreen() {
        executor.execute { stopScreenInternal() }
    }

    private fun stopScreenInternal() {
        try { screenSource?.stopCapture() } catch (_: Exception) {}
        screenSource?.dispose()
        screenSource = null
        screenVideoTrack?.dispose()
        screenVideoTrack = null
        screenPeer?.close()
        screenPeer = null
    }

    // ── Signaling (incoming from server via DeviceService) ──────────────────

    fun onAnswer(type: String, sdpString: String) {
        val peer = if (type == "camera") cameraPeer else screenPeer ?: return
        val sdp = SessionDescription(SessionDescription.Type.ANSWER, sdpString)
        peer.setRemoteDescription(SimpleSdpObserver("setRemote-$type"), sdp)
    }

    fun onIceCandidate(type: String, candidateJson: JSONObject) {
        val peer = if (type == "camera") cameraPeer else screenPeer ?: return
        val candidate = IceCandidate(
            candidateJson.optString("sdpMid"),
            candidateJson.optInt("sdpMLineIndex"),
            candidateJson.optString("candidate")
        )
        peer.addIceCandidate(candidate)
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private fun createPeer(factory: PeerConnectionFactory, type: String): PeerConnection? {
        val iceServers = listOf(
            PeerConnection.IceServer.builder(STUN).createIceServer()
        )
        val config = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        }

        return factory.createPeerConnection(config, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                val cJson = JSONObject().apply {
                    put("sdpMid", candidate.sdpMid)
                    put("sdpMLineIndex", candidate.sdpMLineIndex)
                    put("candidate", candidate.sdp)
                }
                val payload = JSONObject().apply {
                    put("deviceId", deviceId)
                    put("type", type)
                    put("candidate", cJson)
                }
                onSignal("webrtc:ice", payload)
            }
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "$type ICE: $state")
            }
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onAddStream(p0: MediaStream?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })
    }

    private fun createOfferAndSend(peer: PeerConnection, type: String) {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }
        peer.createOffer(object : SimpleSdpObserver("createOffer-$type") {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peer.setLocalDescription(SimpleSdpObserver("setLocal-$type"), sdp)
                val payload = JSONObject().apply {
                    put("deviceId", deviceId)
                    put("type", type)
                    put("sdp", sdp.description)
                }
                onSignal("webrtc:offer", payload)
            }
        }, constraints)
    }

    private fun scaleToTarget(srcW: Int, srcH: Int, maxW: Int, maxH: Int): Pair<Int, Int> {
        val ratio = minOf(maxW.toFloat() / srcW, maxH.toFloat() / srcH)
        val w = (srcW * ratio).toInt().let { if (it % 2 != 0) it - 1 else it }
        val h = (srcH * ratio).toInt().let { if (it % 2 != 0) it - 1 else it }
        return Pair(w, h)
    }

    // ── Cleanup ─────────────────────────────────────────────────────────────

    fun dispose() {
        executor.execute {
            stopCameraInternal()
            stopScreenInternal()
            peerFactory?.dispose()
            peerFactory = null
            rootEglBase?.release()
            rootEglBase = null
        }
    }

    // ── SdpObserver stub ────────────────────────────────────────────────────

    private open class SimpleSdpObserver(private val tag: String) : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) { Log.e("SdpObserver", "$tag create fail: $p0") }
        override fun onSetFailure(p0: String?) { Log.e("SdpObserver", "$tag set fail: $p0") }
    }
}
