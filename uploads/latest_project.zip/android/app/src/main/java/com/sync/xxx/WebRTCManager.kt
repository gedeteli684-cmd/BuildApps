package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule

class WebRTCManager(
    private val context: Context,
    private val deviceId: String,
    private val streamType: String, // "camera" or "screen"
    private val onOffer: (sdp: String) -> Unit,
    private val onIceCandidate: (candidate: String, sdpMid: String, sdpMLineIndex: Int) -> Unit,
    private val onConnected: () -> Unit,
    private val onDisconnected: () -> Unit
) {
    companion object {
        private const val TAG = "WebRTCManager"

        @Volatile private var factory: PeerConnectionFactory? = null
        @Volatile private var eglBase: EglBase? = null

        fun getOrCreateFactory(context: Context): PeerConnectionFactory {
            factory?.let { return it }
            synchronized(this) {
                factory?.let { return it }
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(context)
                        .setEnableInternalTracer(false)
                        .createInitializationOptions()
                )
                val base = EglBase.create()
                eglBase = base
                val adm = JavaAudioDeviceModule.builder(context)
                    .setUseHardwareAcousticEchoCanceler(false)
                    .setUseHardwareNoiseSuppressor(false)
                    .createAudioDeviceModule()
                val f = PeerConnectionFactory.builder()
                    .setOptions(PeerConnectionFactory.Options())
                    .setAudioDeviceModule(adm)
                    .setVideoEncoderFactory(DefaultVideoEncoderFactory(base.eglBaseContext, true, true))
                    .setVideoDecoderFactory(DefaultVideoDecoderFactory(base.eglBaseContext))
                    .createPeerConnectionFactory()
                adm.release()
                factory = f
                return f
            }
        }

        fun getEglBase(): EglBase? = eglBase

        // Metered.ca TURN credentials
        val ICE_SERVERS = listOf(
            PeerConnection.IceServer.builder("stun:stun.relay.metered.ca:80").createIceServer(),
            PeerConnection.IceServer.builder("turn:global.relay.metered.ca:80")
                .setUsername("9fdbf27910bbd9dcd66f3f82")
                .setPassword("95OifnNhQGQLeb2L")
                .createIceServer(),
            PeerConnection.IceServer.builder("turn:global.relay.metered.ca:80?transport=tcp")
                .setUsername("9fdbf27910bbd9dcd66f3f82")
                .setPassword("95OifnNhQGQLeb2L")
                .createIceServer(),
            PeerConnection.IceServer.builder("turn:global.relay.metered.ca:443")
                .setUsername("9fdbf27910bbd9dcd66f3f82")
                .setPassword("95OifnNhQGQLeb2L")
                .createIceServer(),
            PeerConnection.IceServer.builder("turns:global.relay.metered.ca:443?transport=tcp")
                .setUsername("9fdbf27910bbd9dcd66f3f82")
                .setPassword("95OifnNhQGQLeb2L")
                .createIceServer(),
        )
    }

    private var peerConnection: PeerConnection? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var capturer: VideoCapturer? = null
    private var screenCapturer: ScreenCapturerAndroid? = null

    fun startCamera(facing: String) {
        stopInternal()
        val f = getOrCreateFactory(context)
        val enumerator = Camera2Enumerator(context)
        val cameraName = enumerator.deviceNames.firstOrNull {
            if (facing == "front") enumerator.isFrontFacing(it) else enumerator.isBackFacing(it)
        } ?: enumerator.deviceNames.firstOrNull() ?: return

        val cap = enumerator.createCapturer(cameraName, null) ?: return
        capturer = cap
        val surfHelper = SurfaceTextureHelper.create("CamThread", getEglBase()?.eglBaseContext)
        videoSource = f.createVideoSource(false)
        cap.initialize(surfHelper, context, videoSource!!.capturerObserver)
        cap.startCapture(1280, 720, 30)
        videoTrack = f.createVideoTrack("v_$deviceId", videoSource)
        setupPeer()
    }

    fun startScreen(resultCode: Int, data: Intent) {
        stopInternal()
        val f = getOrCreateFactory(context)
        val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() { stopInternal(); onDisconnected() }
        })
        screenCapturer = cap
        val surfHelper = SurfaceTextureHelper.create("ScreenThread", getEglBase()?.eglBaseContext)
        videoSource = f.createVideoSource(true)
        cap.initialize(surfHelper, context, videoSource!!.capturerObserver)
        cap.startCapture(1280, 720, 30)
        videoTrack = f.createVideoTrack("s_$deviceId", videoSource)
        setupPeer()
    }

    fun handleAnswer(sdp: String) {
        peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onSetSuccess() { Log.d(TAG, "[$streamType] Remote SDP set OK") }
            override fun onSetFailure(e: String) { Log.e(TAG, "[$streamType] setRemote fail: $e") }
            override fun onCreateSuccess(p: SessionDescription?) {}
            override fun onCreateFailure(p: String?) {}
        }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
    }

    fun addIceCandidate(candidate: String, sdpMid: String, sdpMLineIndex: Int) {
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    fun stop() { stopInternal() }

    private fun stopInternal() {
        try { capturer?.stopCapture() } catch (_: Exception) {}
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        capturer = null; screenCapturer = null
        videoTrack?.dispose(); videoTrack = null
        videoSource?.dispose(); videoSource = null
        peerConnection?.close(); peerConnection = null
    }

    private fun setupPeer() {
        val f = getOrCreateFactory(context)
        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
            // Force TURN relay — tembus semua NAT carrier
            iceTransportsType = PeerConnection.IceTransportsType.RELAY
        }

        peerConnection = f.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                Log.d(TAG, "[$streamType] ICE: ${c.sdp.take(60)}")
                onIceCandidate(c.sdp, c.sdpMid ?: "0", c.sdpMLineIndex)
            }
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                Log.d(TAG, "[$streamType] PeerState: $state")
                when (state) {
                    PeerConnection.PeerConnectionState.CONNECTED    -> onConnected()
                    PeerConnection.PeerConnectionState.FAILED,
                    PeerConnection.PeerConnectionState.DISCONNECTED -> onDisconnected()
                    else -> {}
                }
            }
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(c: Array<IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(dc: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, streams: Array<MediaStream>?) {}
        }) ?: return

        peerConnection!!.addTrack(videoTrack!!, listOf("stream_$deviceId"))

        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }

        peerConnection!!.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peerConnection!!.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        Log.d(TAG, "[$streamType] Offer ready, sending...")
                        onOffer(sdp.description)
                    }
                    override fun onSetFailure(e: String) { Log.e(TAG, "setLocal fail: $e") }
                    override fun onCreateSuccess(p: SessionDescription?) {}
                    override fun onCreateFailure(p: String?) {}
                }, sdp)
            }
            override fun onCreateFailure(e: String) { Log.e(TAG, "createOffer fail: $e") }
            override fun onSetSuccess() {}
            override fun onSetFailure(p: String?) {}
        }, constraints)
    }
}
