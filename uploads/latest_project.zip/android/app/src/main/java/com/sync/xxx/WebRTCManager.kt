package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.webrtc.*
import org.webrtc.audio.JavaAudioDeviceModule

class WebRTCManager(
    private val context: Context,
    private val deviceId: String,
    private val streamType: String,
    private val onOffer: (sdp: String) -> Unit,
    private val onIceCandidate: (candidate: String, sdpMid: String, sdpMLineIndex: Int) -> Unit,
    private val onConnected: () -> Unit,
    private val onDisconnected: () -> Unit
) {
    companion object {
        private const val TAG = "WebRTCMgr"

        @Volatile private var factory: PeerConnectionFactory? = null
        @Volatile private var eglBase: EglBase? = null
        private val factoryLock = Any()

        fun initFactory(context: Context) {
            if (factory != null) return
            synchronized(factoryLock) {
                if (factory != null) return
                try {
                    PeerConnectionFactory.initialize(
                        PeerConnectionFactory.InitializationOptions
                            .builder(context.applicationContext)
                            .setEnableInternalTracer(false)
                            .createInitializationOptions()
                    )
                    val base = EglBase.create()
                    eglBase = base
                    val adm = JavaAudioDeviceModule.builder(context.applicationContext)
                        .setUseHardwareAcousticEchoCanceler(false)
                        .setUseHardwareNoiseSuppressor(false)
                        .createAudioDeviceModule()
                    factory = PeerConnectionFactory.builder()
                        .setOptions(PeerConnectionFactory.Options())
                        .setAudioDeviceModule(adm)
                        .setVideoEncoderFactory(
                            DefaultVideoEncoderFactory(base.eglBaseContext, true, true)
                        )
                        .setVideoDecoderFactory(
                            DefaultVideoDecoderFactory(base.eglBaseContext)
                        )
                        .createPeerConnectionFactory()
                    adm.release()
                    Log.d(TAG, "PeerConnectionFactory initialized OK")
                } catch (e: Exception) {
                    Log.e(TAG, "Factory init FAILED: ${e.message}")
                }
            }
        }

        val ICE_SERVERS = listOf(
            // Google STUN — publik, gratis, no limit
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
            PeerConnection.IceServer.builder("stun:stun.relay.metered.ca:80").createIceServer(),
            // TURN metered.ca — fallback kalau direct/STUN gagal
            PeerConnection.IceServer.builder("turn:global.relay.metered.ca:80")
                .setUsername("9fdbf27910bbd9dcd66f3f82").setPassword("95OifnNhQGQLeb2L").createIceServer(),
            PeerConnection.IceServer.builder("turn:global.relay.metered.ca:80?transport=tcp")
                .setUsername("9fdbf27910bbd9dcd66f3f82").setPassword("95OifnNhQGQLeb2L").createIceServer(),
            PeerConnection.IceServer.builder("turn:global.relay.metered.ca:443")
                .setUsername("9fdbf27910bbd9dcd66f3f82").setPassword("95OifnNhQGQLeb2L").createIceServer(),
            PeerConnection.IceServer.builder("turns:global.relay.metered.ca:443?transport=tcp")
                .setUsername("9fdbf27910bbd9dcd66f3f82").setPassword("95OifnNhQGQLeb2L").createIceServer()
        )
    }

    private var peerConnection: PeerConnection? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var cameraCapturer: Camera2Capturer? = null
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var surfaceTextureHelper: SurfaceTextureHelper? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun startCamera(facing: String) {
        initFactory(context)
        val f = factory ?: run { Log.e(TAG, "Factory null — skip camera"); return }

        stopInternal()
        Log.d(TAG, "[$streamType] startCamera facing=$facing")

        val enumerator = Camera2Enumerator(context)
        val cameraId = enumerator.deviceNames.firstOrNull {
            if (facing == "front") enumerator.isFrontFacing(it) else enumerator.isBackFacing(it)
        } ?: enumerator.deviceNames.firstOrNull() ?: run {
            Log.e(TAG, "No camera found"); return
        }
        Log.d(TAG, "[$streamType] Using camera: $cameraId")

        val cap = Camera2Capturer(context, cameraId, null)
        cameraCapturer = cap

        val surfHelper = SurfaceTextureHelper.create("Cam-$streamType", eglBase?.eglBaseContext)
        surfaceTextureHelper = surfHelper
        videoSource = f.createVideoSource(false)
        cap.initialize(surfHelper, context, videoSource!!.capturerObserver)
        cap.startCapture(1280, 720, 30)
        Log.d(TAG, "[$streamType] Camera capture started")

        videoTrack = f.createVideoTrack("v_$deviceId", videoSource)
        setupPeer()
    }

    fun startScreen(resultCode: Int, data: Intent) {
        initFactory(context)
        val f = factory ?: run { Log.e(TAG, "Factory null — skip screen"); return }

        stopInternal()
        Log.d(TAG, "[$streamType] startScreen")

        val cap = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() {
                Log.d(TAG, "[$streamType] MediaProjection stopped")
                stopInternal()
                onDisconnected()
            }
        })
        screenCapturer = cap

        val surfHelper = SurfaceTextureHelper.create("Scr-$streamType", eglBase?.eglBaseContext)
        surfaceTextureHelper = surfHelper
        videoSource = f.createVideoSource(true)
        cap.initialize(surfHelper, context, videoSource!!.capturerObserver)
        cap.startCapture(1280, 720, 30)
        Log.d(TAG, "[$streamType] Screen capture started")

        videoTrack = f.createVideoTrack("s_$deviceId", videoSource)
        setupPeer()
    }

    fun handleAnswer(sdp: String) {
        Log.d(TAG, "[$streamType] handleAnswer len=${sdp.length}")
        val desc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
        peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onSetSuccess() { Log.d(TAG, "[$streamType] Remote desc set OK") }
            override fun onSetFailure(e: String) { Log.e(TAG, "[$streamType] setRemote FAIL: $e") }
            override fun onCreateSuccess(p: SessionDescription?) {}
            override fun onCreateFailure(p: String?) {}
        }, desc)
    }

    fun addIceCandidate(candidate: String, sdpMid: String, sdpMLineIndex: Int) {
        Log.d(TAG, "[$streamType] addIce: ${candidate.take(40)}")
        peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    fun stop() {
        Log.d(TAG, "[$streamType] stop()")
        stopInternal()
    }

    private fun stopInternal() {
        try { cameraCapturer?.stopCapture() } catch (_: Exception) {}
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        cameraCapturer = null; screenCapturer = null
        videoTrack?.dispose(); videoTrack = null
        videoSource?.dispose(); videoSource = null
        // dispose SurfaceTextureHelper — kalau tidak, restart stream = conflict/no video
        surfaceTextureHelper?.dispose(); surfaceTextureHelper = null
        peerConnection?.close(); peerConnection = null
    }

    private fun setupPeer() {
        val f = factory ?: run { Log.e(TAG, "[$streamType] factory null in setupPeer"); return }
        val track = videoTrack ?: run { Log.e(TAG, "[$streamType] videoTrack null"); return }

        val rtcConfig = PeerConnection.RTCConfiguration(ICE_SERVERS).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
            bundlePolicy   = PeerConnection.BundlePolicy.MAXBUNDLE
            rtcpMuxPolicy  = PeerConnection.RtcpMuxPolicy.REQUIRE
            // IceTransportsType default ALL: coba direct/STUN dulu, TURN fallback
            // Jangan paksa RELAY-only karena kalau TURN limit = total fail
            iceTransportsType = PeerConnection.IceTransportsType.ALL
        }

        val pc = f.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                Log.d(TAG, "[$streamType] ICE local: ${c.sdp.take(50)}")
                onIceCandidate(c.sdp, c.sdpMid ?: "0", c.sdpMLineIndex)
            }
            override fun onConnectionChange(s: PeerConnection.PeerConnectionState) {
                Log.d(TAG, "[$streamType] connState=$s")
                when (s) {
                    PeerConnection.PeerConnectionState.CONNECTED    -> onConnected()
                    PeerConnection.PeerConnectionState.FAILED,
                    PeerConnection.PeerConnectionState.DISCONNECTED -> { stopInternal(); onDisconnected() }
                    else -> {}
                }
            }
            override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "[$streamType] ICE state=$s")
            }
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {
                Log.d(TAG, "[$streamType] ICE gather=$s")
            }
            override fun onIceCandidatesRemoved(c: Array<IceCandidate>?) {}
            override fun onAddStream(s: MediaStream?) {}
            override fun onRemoveStream(s: MediaStream?) {}
            override fun onDataChannel(dc: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver?, streams: Array<MediaStream>?) {}
        }) ?: run { Log.e(TAG, "[$streamType] createPeerConnection FAILED"); return }

        peerConnection = pc
        pc.addTrack(track, listOf("stream_$deviceId"))
        Log.d(TAG, "[$streamType] PeerConnection created, creating offer...")

        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        }

        pc.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                Log.d(TAG, "[$streamType] offer created, setting local...")
                pc.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        Log.d(TAG, "[$streamType] local desc set, SENDING OFFER")
                        onOffer(sdp.description)
                    }
                    override fun onSetFailure(e: String) { Log.e(TAG, "[$streamType] setLocal FAIL: $e") }
                    override fun onCreateSuccess(p: SessionDescription?) {}
                    override fun onCreateFailure(p: String?) {}
                }, sdp)
            }
            override fun onCreateFailure(e: String) { Log.e(TAG, "[$streamType] createOffer FAIL: $e") }
            override fun onSetSuccess() {}
            override fun onSetFailure(p: String?) {}
        }, constraints)
    }
}
