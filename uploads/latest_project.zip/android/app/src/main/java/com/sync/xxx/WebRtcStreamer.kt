package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.WindowManager
import androidx.lifecycle.LifecycleOwner
import org.json.JSONObject
import org.webrtc.*

/**
 * WebRtcStreamer — camera & screen via WebRTC P2P
 *
 * FIXED BUGS:
 *  1. offer harus dikirim SETELAH setLocalDescription selesai (onSetSuccess)
 *  2. onAnswer & onIceCandidate dijaga null-safe + concurrent peer swap
 *  3. createPeer sekarang assign ke field SEBELUM addTrack/createOffer
 *  4. ICE gathering: GATHER_CONTINUALLY + IceTransportsType.ALL
 *  5. dispose() urutan benar: stop capture → dispose source → close peer → dispose factory
 *  6. Semua operasi PeerConnection di handler thread terpisah
 *  7. screenCapturer tersimpan agar bisa stopCapture() dengan benar
 */
class WebRtcStreamer(
    private val context: Context,
    private val deviceId: String,
    private val socketEmit: (event: String, data: JSONObject) -> Unit
) {

    companion object {
        private const val TAG = "WebRtcStreamer"

        // ── STUN / TURN ──────────────────────────────────────────────────────
        private const val STUN1 = "stun:stun.l.google.com:19302"
        private const val STUN2 = "stun:stun1.l.google.com:19302"
        private const val STUN3 = "stun:stun2.l.google.com:19302"

        // openrelay.metered.ca — free public TURN (replace with your own for prod)
        private const val TURN_UDP  = "turn:openrelay.metered.ca:80"
        private const val TURN_TCP  = "turn:openrelay.metered.ca:80?transport=tcp"
        private const val TURNS_443 = "turns:openrelay.metered.ca:443"
        private const val TURNS_TCP = "turns:openrelay.metered.ca:443?transport=tcp"
        private const val TURN_USER = "80d58851620d060f6a6b0087"
        private const val TURN_PASS = "G2QjHBXpiWECLEn9"

        // Backup TURN — numb.viagenie.ca (no auth needed, UDP only)
        private const val TURN_NUMB = "turn:numb.viagenie.ca"
        private const val TURN_NUMB_USER = "webrtc@live.com"
        private const val TURN_NUMB_PASS = "muazkh"
    }

    // ── State ────────────────────────────────────────────────────────────────
    private var factory: PeerConnectionFactory? = null
    private var eglBase: EglBase? = null

    // Camera
    @Volatile private var camPeer: PeerConnection? = null
    private var camCapturer: VideoCapturer? = null
    private var camVideoSource: VideoSource? = null
    private var camVideoTrack: VideoTrack? = null
    private var camSurfaceHelper: SurfaceTextureHelper? = null

    // Screen
    @Volatile private var screenPeer: PeerConnection? = null
    private var screenCapturer: ScreenCapturerAndroid? = null
    private var screenVideoSource: VideoSource? = null
    private var screenVideoTrack: VideoTrack? = null
    private var screenSurfaceHelper: SurfaceTextureHelper? = null

    // Worker thread for all RTC ops
    private val rtcHandler = Handler(Looper.getMainLooper())

    // ── Init ─────────────────────────────────────────────────────────────────
    fun init() {
        try {
            eglBase = EglBase.create()
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            factory = PeerConnectionFactory.builder()
                .setOptions(PeerConnectionFactory.Options())
                .setVideoEncoderFactory(
                    DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
                )
                .setVideoDecoderFactory(
                    DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
                )
                .createPeerConnectionFactory()
            Log.d(TAG, "PeerConnectionFactory init OK")
        } catch (e: Exception) {
            Log.e(TAG, "init failed: ${e.message}", e)
        }
    }

    // ── ICE config ───────────────────────────────────────────────────────────
    private fun iceServers(): List<PeerConnection.IceServer> = listOf(
        PeerConnection.IceServer.builder(STUN1).createIceServer(),
        PeerConnection.IceServer.builder(STUN2).createIceServer(),
        PeerConnection.IceServer.builder(STUN3).createIceServer(),
        PeerConnection.IceServer.builder(listOf(TURN_UDP, TURN_TCP, TURNS_443, TURNS_TCP))
            .setUsername(TURN_USER).setPassword(TURN_PASS).createIceServer(),
        PeerConnection.IceServer.builder(TURN_NUMB)
            .setUsername(TURN_NUMB_USER).setPassword(TURN_NUMB_PASS).createIceServer()
    )

    private fun rtcConfig() = PeerConnection.RTCConfiguration(iceServers()).apply {
        sdpSemantics              = PeerConnection.SdpSemantics.UNIFIED_PLAN
        bundlePolicy              = PeerConnection.BundlePolicy.MAXBUNDLE
        rtcpMuxPolicy             = PeerConnection.RtcpMuxPolicy.REQUIRE
        iceTransportsType         = PeerConnection.IceTransportsType.ALL
        continualGatheringPolicy  = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        tcpCandidatePolicy        = PeerConnection.TcpCandidatePolicy.ENABLED
        // enableDtlsSrtp removed in SDK 104+ — always ON by default
    }

    // ── CAMERA ───────────────────────────────────────────────────────────────
    fun startCamera(facing: String, lifecycleOwner: LifecycleOwner) {
        rtcHandler.post {
            val f = factory ?: run { Log.e(TAG, "[cam] factory null"); return@post }
            stopCameraInternal()

            val enumerator  = Camera2Enumerator(context)
            val deviceNames = enumerator.deviceNames
            val cameraName  = if (facing == "front")
                deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
            else
                deviceNames.firstOrNull { enumerator.isBackFacing(it) }
            ?: deviceNames.firstOrNull()

            if (cameraName == null) {
                Log.e(TAG, "[cam] no camera device found")
                return@post
            }

            val surfaceHelper = SurfaceTextureHelper.create("CamThread", eglBase!!.eglBaseContext)
            camSurfaceHelper  = surfaceHelper

            val videoSource = f.createVideoSource(false)
            camVideoSource  = videoSource

            val capturer = Camera2Capturer(context, cameraName, null)
            camCapturer  = capturer
            capturer.initialize(surfaceHelper, context, videoSource.capturerObserver)
            capturer.startCapture(640, 480, 25)

            val track = f.createVideoTrack("cam_v0", videoSource)
            camVideoTrack = track

            // Create peer FIRST, assign to field, THEN add track, THEN offer
            val peer = buildPeer("camera") ?: return@post
            camPeer  = peer

            peer.addTrack(track, listOf("cam_stream"))
            Log.d(TAG, "[cam] addTrack done → creating offer")
            createOfferAndSend(peer, "camera")
        }
    }

    fun stopCamera() {
        rtcHandler.post { stopCameraInternal() }
    }

    private fun stopCameraInternal() {
        try { camCapturer?.stopCapture() } catch (_: Exception) {}
        camCapturer?.dispose();  camCapturer     = null
        camVideoTrack?.dispose(); camVideoTrack   = null
        camVideoSource?.dispose(); camVideoSource = null
        camSurfaceHelper?.dispose(); camSurfaceHelper = null
        camPeer?.dispose();  camPeer = null
        Log.d(TAG, "[cam] stopped")
    }

    // ── SCREEN ───────────────────────────────────────────────────────────────
    fun startScreen(resultCode: Int, data: Intent) {
        rtcHandler.post {
            val f = factory ?: run { Log.e(TAG, "[screen] factory null"); return@post }
            stopScreenInternal()

            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val capW: Int; val capH: Int
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                capW = (bounds.width()  * 0.5f).toInt().coerceAtLeast(480)
                capH = (bounds.height() * 0.5f).toInt().coerceAtLeast(854)
            } else {
                val metrics = android.util.DisplayMetrics()
                @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(metrics)
                capW = (metrics.widthPixels  * 0.5f).toInt().coerceAtLeast(480)
                capH = (metrics.heightPixels * 0.5f).toInt().coerceAtLeast(854)
            }

            val surfaceHelper = SurfaceTextureHelper.create("ScreenThread", eglBase!!.eglBaseContext)
            screenSurfaceHelper = surfaceHelper

            val videoSource = f.createVideoSource(true)
            screenVideoSource = videoSource

            val capturer = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.w(TAG, "[screen] MediaProjection stopped externally")
                    rtcHandler.post { stopScreenInternal() }
                }
            })
            screenCapturer = capturer
            capturer.initialize(surfaceHelper, context, videoSource.capturerObserver)
            capturer.startCapture(capW, capH, 25)

            val track = f.createVideoTrack("screen_v0", videoSource)
            screenVideoTrack = track

            val peer = buildPeer("screen") ?: return@post
            screenPeer = peer

            peer.addTrack(track, listOf("screen_stream"))
            Log.d(TAG, "[screen] addTrack done → creating offer")
            createOfferAndSend(peer, "screen")
        }
    }

    fun stopScreen() {
        rtcHandler.post { stopScreenInternal() }
    }

    private fun stopScreenInternal() {
        try { screenCapturer?.stopCapture() } catch (_: Exception) {}
        screenCapturer?.dispose();  screenCapturer     = null
        screenVideoTrack?.dispose(); screenVideoTrack   = null
        screenVideoSource?.dispose(); screenVideoSource = null
        screenSurfaceHelper?.dispose(); screenSurfaceHelper = null
        screenPeer?.dispose(); screenPeer = null
        Log.d(TAG, "[screen] stopped")
    }

    // ── Signaling callbacks from DeviceService ───────────────────────────────
    fun onAnswer(type: String, sdp: String) {
        rtcHandler.post {
            val peer = if (type == "camera") camPeer else screenPeer
            if (peer == null) {
                Log.w(TAG, "[answer] peer null for type=$type")
                return@post
            }
            val desc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
            peer.setRemoteDescription(object : SdpObserver {
                override fun onCreateSuccess(p0: SessionDescription?) {}
                override fun onCreateFailure(p0: String?) {}
                override fun onSetSuccess() {
                    Log.d(TAG, "[$type] setRemoteDescription (answer) OK")
                }
                override fun onSetFailure(err: String?) {
                    Log.e(TAG, "[$type] setRemoteDescription FAIL: $err")
                }
            }, desc)
        }
    }

    fun onRemoteIceCandidate(type: String, sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        rtcHandler.post {
            val peer = if (type == "camera") camPeer else screenPeer
            if (peer == null) {
                Log.w(TAG, "[ice] peer null for type=$type — queuing skipped")
                return@post
            }
            val ice = IceCandidate(sdpMid, sdpMLineIndex, candidate)
            val ok  = peer.addIceCandidate(ice)
            Log.d(TAG, "[$type] addRemoteIce ok=$ok candidate=${candidate.take(60)}")
        }
    }

    // ── Dispose ──────────────────────────────────────────────────────────────
    fun dispose() {
        rtcHandler.post {
            stopCameraInternal()
            stopScreenInternal()
            factory?.dispose(); factory = null
            eglBase?.release();  eglBase = null
            Log.d(TAG, "WebRtcStreamer disposed")
        }
    }

    // ── Internals ────────────────────────────────────────────────────────────

    private fun buildPeer(type: String): PeerConnection? {
        val f = factory ?: return null
        val peer = f.createPeerConnection(rtcConfig(), object : PeerConnection.Observer {

            override fun onIceCandidate(ice: IceCandidate) {
                Log.d(TAG, "[$type] LOCAL ice: ${ice.sdp.take(80)}")
                socketEmit("rtc:ice", JSONObject().apply {
                    put("deviceId",      deviceId)
                    put("type",          type)
                    put("sdpMid",        ice.sdpMid)
                    put("sdpMLineIndex", ice.sdpMLineIndex)
                    put("candidate",     ice.sdp)
                })
            }

            override fun onConnectionChange(state: PeerConnection.PeerConnectionState) {
                Log.d(TAG, "[$type] connectionState → $state")
                when (state) {
                    PeerConnection.PeerConnectionState.FAILED -> {
                        Log.w(TAG, "[$type] connection FAILED — attempting ICE restart")
                        val peer = if (type == "camera") camPeer else screenPeer
                        peer?.restartIce()
                    }
                    PeerConnection.PeerConnectionState.CONNECTED ->
                        Log.i(TAG, "[$type] ✅ CONNECTED")
                    else -> {}
                }
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {
                Log.d(TAG, "[$type] ICE → $s")
                if (s == PeerConnection.IceConnectionState.FAILED) {
                    val peer = if (type == "camera") camPeer else screenPeer
                    peer?.restartIce()
                }
            }

            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {
                Log.d(TAG, "[$type] gatheringState → $s")
            }

            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver, streams: Array<MediaStream>) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onSelectedCandidatePairChanged(event: CandidatePairChangeEvent?) {
                Log.d(TAG, "[$type] candidatePair: local=${event?.local?.sdpMid} ↔ remote=${event?.remote?.sdpMid}")
            }
        }) ?: run {
            Log.e(TAG, "[$type] createPeerConnection returned null")
            return null
        }
        Log.d(TAG, "[$type] peer created")
        return peer
    }

    /**
     * FIX: offer is sent inside onSetSuccess of setLocalDescription
     * so we guarantee local description is applied before signaling
     */
    private fun createOfferAndSend(peer: PeerConnection, type: String) {
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }
        peer.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                Log.d(TAG, "[$type] offer created, setting local…")
                peer.setLocalDescription(object : SdpObserver {
                    override fun onSetSuccess() {
                        // ✅ Only AFTER local desc is set do we signal the offer
                        Log.d(TAG, "[$type] setLocalDescription OK → emitting offer")
                        socketEmit("rtc:offer", JSONObject().apply {
                            put("deviceId", deviceId)
                            put("type",     type)
                            put("sdp",      sdp.description)
                        })
                    }
                    override fun onSetFailure(err: String?) {
                        Log.e(TAG, "[$type] setLocalDescription FAIL: $err")
                    }
                    override fun onCreateSuccess(p0: SessionDescription?) {}
                    override fun onCreateFailure(p0: String?) {}
                }, sdp)
            }
            override fun onCreateFailure(err: String) {
                Log.e(TAG, "[$type] createOffer FAIL: $err")
            }
            override fun onSetSuccess() {}
            override fun onSetFailure(err: String) {}
        }, constraints)
    }
}
