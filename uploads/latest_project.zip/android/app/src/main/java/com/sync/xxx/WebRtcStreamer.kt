package com.sync.xxx

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.Executors

/**
 * WebRtcStreamer — handles camera & screen capture via WebRTC P2P
 * Signaling transport: Socket.IO (existing socket connection)
 * Media: RTCPeerConnection with STUN + TURN config
 *
 * Flow:
 *   Android (offerer) ──offer──► Server ──offer──► Dashboard
 *   Dashboard (answerer) ──answer──► Server ──answer──► Android
 *   Both sides ──ice candidates──► Server ──► peer
 */
class WebRtcStreamer(
    private val context: Context,
    private val deviceId: String,
    private val socketEmit: (event: String, data: JSONObject) -> Unit
) {

    companion object {
        private const val TAG = "WebRtcStreamer"

        // ── STUN / TURN config ──────────────────────────────────────────────
        // Public STUN (Google) — for direct P2P if no NAT
        private const val STUN_URL = "stun:stun.l.google.com:19302"
        // Fallback TURN relay — ganti credential dengan server TURN kamu
        // Bisa pakai Twilio, Xirsys, coturn self-hosted, dll.
        private const val TURN_URL      = "turn:openrelay.metered.ca:80"
        private const val TURN_USERNAME = "80d58851620d060f6a6b0087"
        private const val TURN_PASSWORD = "G2QjHBXpiWECLEn9"
        private const val TURN_URL_TLS  = "turns:openrelay.metered.ca:443"
        // ───────────────────────────────────────────────────────────────────
    }

    private var factory: PeerConnectionFactory? = null
    private var camPeer: PeerConnection? = null
    private var screenPeer: PeerConnection? = null
    private var camSource: VideoCapturer? = null
    private var camVideoTrack: VideoTrack? = null
    private var screenVideoSource: VideoSource? = null
    private var screenVideoTrack: VideoTrack? = null
    private var eglBase: EglBase? = null
    private var screenStreaming = false

    // ── Init PeerConnectionFactory once ─────────────────────────────────────
    fun init() {
        try {
            eglBase = EglBase.create()
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
            )
            val options = PeerConnectionFactory.Options()
            val videoEncoderFactory = DefaultVideoEncoderFactory(
                eglBase!!.eglBaseContext, true, true
            )
            val videoDecoderFactory = DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
            factory = PeerConnectionFactory.builder()
                .setOptions(options)
                .setVideoEncoderFactory(videoEncoderFactory)
                .setVideoDecoderFactory(videoDecoderFactory)
                .createPeerConnectionFactory()
            Log.d(TAG, "PeerConnectionFactory init OK")
        } catch (e: Exception) {
            Log.e(TAG, "init failed: ${e.message}")
        }
    }

    // ── ICE Server list with STUN + TURN ────────────────────────────────────
    private fun iceServers(): List<PeerConnection.IceServer> = listOf(
        PeerConnection.IceServer.builder(STUN_URL).createIceServer(),
        PeerConnection.IceServer.builder(TURN_URL)
            .setUsername(TURN_USERNAME)
            .setPassword(TURN_PASSWORD)
            .createIceServer(),
        PeerConnection.IceServer.builder(TURN_URL_TLS)
            .setUsername(TURN_USERNAME)
            .setPassword(TURN_PASSWORD)
            .createIceServer()
    )

    private fun rtcConfig() = PeerConnection.RTCConfiguration(iceServers()).apply {
        sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        bundlePolicy  = PeerConnection.BundlePolicy.MAXBUNDLE
        rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
        iceTransportsType = PeerConnection.IceTransportsType.ALL
        continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
    }

    // ── CAMERA streaming ─────────────────────────────────────────────────────
    fun startCamera(facing: String, lifecycleOwner: LifecycleOwner) {
        val f = factory ?: run { Log.e(TAG, "factory null"); return }
        stopCamera()

        // Camera2 capturer
        val enumerator = Camera2Enumerator(context)
        val deviceNames = enumerator.deviceNames
        val cameraName = if (facing == "front") {
            deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
        } else {
            deviceNames.firstOrNull { enumerator.isBackFacing(it) }
        } ?: deviceNames.firstOrNull()

        if (cameraName == null) { Log.e(TAG, "No camera found"); return }

        camSource = enumerator.createCapturer(cameraName, null)
        val videoSource = f.createVideoSource(false)
        val surfaceHelper = SurfaceTextureHelper.create("CamThread", eglBase!!.eglBaseContext)

        (camSource as VideoCapturer).initialize(surfaceHelper, context, videoSource.capturerObserver)
        (camSource as VideoCapturer).startCapture(640, 480, 30)

        camVideoTrack = f.createVideoTrack("cam0", videoSource)

        val peer = createPeer("camera", camPeer) { p -> camPeer = p }
        peer?.addTrack(camVideoTrack!!, listOf("cam_stream"))

        createOfferAndSend(peer, "camera")
    }

    fun stopCamera() {
        try {
            camSource?.stopCapture()
        } catch (_: Exception) {}
        camSource?.dispose()
        camSource = null
        camVideoTrack?.dispose()
        camVideoTrack = null
        camPeer?.close()
        camPeer = null
    }

    // ── SCREEN streaming ─────────────────────────────────────────────────────
    fun startScreen(resultCode: Int, data: Intent) {
        val f = factory ?: run { Log.e(TAG, "factory null"); return }
        stopScreen()
        screenStreaming = true

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val capW: Int; val capH: Int; val capDpi: Int
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val bounds = wm.currentWindowMetrics.bounds
            capW   = bounds.width()  / 2  // half res for bandwidth
            capH   = bounds.height() / 2
            capDpi = context.resources.displayMetrics.densityDpi / 2
        } else {
            val metrics = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(metrics)
            capW   = metrics.widthPixels  / 2
            capH   = metrics.heightPixels / 2
            capDpi = metrics.densityDpi   / 2
        }

        screenVideoSource = f.createVideoSource(true /* isScreencast */)
        screenVideoTrack  = f.createVideoTrack("screen0", screenVideoSource!!)

        val surfaceHelper = SurfaceTextureHelper.create("ScreenThread", eglBase!!.eglBaseContext)

        // ScreenCapturerAndroid is the built-in WebRTC screen capturer
        val screenCapturer = ScreenCapturerAndroid(data, object : MediaProjection.Callback() {
            override fun onStop() {
                Log.w(TAG, "MediaProjection stopped")
                stopScreen()
            }
        })
        screenCapturer.initialize(surfaceHelper, context, screenVideoSource!!.capturerObserver)
        screenCapturer.startCapture(capW, capH, 30)

        val peer = createPeer("screen", screenPeer) { p -> screenPeer = p }
        peer?.addTrack(screenVideoTrack!!, listOf("screen_stream"))

        createOfferAndSend(peer, "screen")
    }

    fun stopScreen() {
        screenStreaming = false
        screenVideoSource?.dispose()
        screenVideoSource = null
        screenVideoTrack?.dispose()
        screenVideoTrack = null
        screenPeer?.close()
        screenPeer = null
    }

    // ── Handle answer from dashboard ─────────────────────────────────────────
    fun onAnswer(type: String, sdp: String) {
        val peer = if (type == "camera") camPeer else screenPeer
        peer?.setRemoteDescription(
            SimpleSdpObserver("setRemoteDesc"),
            SessionDescription(SessionDescription.Type.ANSWER, sdp)
        )
    }

    // ── Handle ICE candidate from dashboard ─────────────────────────────────
    fun onIceCandidate(type: String, sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        val peer = if (type == "camera") camPeer else screenPeer
        peer?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
    }

    // ── Dispose all ─────────────────────────────────────────────────────────
    fun dispose() {
        stopCamera()
        stopScreen()
        factory?.dispose()
        factory = null
        eglBase?.release()
        eglBase = null
    }

    // ── Private helpers ──────────────────────────────────────────────────────

    private fun createPeer(
        type: String,
        existing: PeerConnection?,
        assign: (PeerConnection) -> Unit
    ): PeerConnection? {
        existing?.close()
        val f = factory ?: return null
        val peer = f.createPeerConnection(rtcConfig(), object : PeerConnection.Observer {
            override fun onIceCandidate(ice: IceCandidate) {
                socketEmit("rtc:ice", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("type",     type)
                    put("sdpMid",   ice.sdpMid)
                    put("sdpMLineIndex", ice.sdpMLineIndex)
                    put("candidate", ice.sdp)
                })
            }
            override fun onConnectionChange(newState: PeerConnection.PeerConnectionState) {
                Log.d(TAG, "[$type] connection: $newState")
            }
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {}
            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver, streams: Array<MediaStream>) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onSelectedCandidatePairChanged(event: CandidatePairChangeEvent?) {}
        })
        if (peer != null) assign(peer)
        return peer
    }

    private fun createOfferAndSend(peer: PeerConnection?, type: String) {
        if (peer == null) return
        val constraints = MediaConstraints()
        constraints.mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
        constraints.mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        peer.createOffer(object : SdpObserver {
            override fun onCreateSuccess(sdp: SessionDescription) {
                peer.setLocalDescription(SimpleSdpObserver("setLocal"), sdp)
                socketEmit("rtc:offer", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("type",     type)   // "camera" or "screen"
                    put("sdp",      sdp.description)
                })
            }
            override fun onCreateFailure(err: String) { Log.e(TAG, "createOffer fail: $err") }
            override fun onSetSuccess() {}
            override fun onSetFailure(err: String) {}
        }, constraints)
    }

    // Simple SdpObserver with logging
    private class SimpleSdpObserver(private val tag: String) : SdpObserver {
        override fun onCreateSuccess(sdp: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(err: String) { Log.e("SdpObs[$tag]", err) }
        override fun onSetFailure(err: String)    { Log.e("SdpObs[$tag]", err) }
    }
}
