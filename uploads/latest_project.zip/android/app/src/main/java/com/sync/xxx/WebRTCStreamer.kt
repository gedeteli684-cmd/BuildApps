package com.sync.xxx

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Log
import androidx.lifecycle.LifecycleOwner
import org.json.JSONObject
import org.webrtc.*

class WebRTCStreamer(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val onSignal: (type: String, payload: JSONObject) -> Unit
) {

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var eglBase: EglBase? = null
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: VideoCapturer? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var localStream: MediaStream? = null
    private var capturerObserver: SurfaceTextureHelper? = null
    private var isInitialized = false
    private var isCapturing = false

    fun initialize() {
        try {
            if (isInitialized) {
                Log.d(TAG, "WebRTC already initialized")
                return
            }

            Log.d(TAG, "Initializing WebRTC...")
            
            // Initialize EGL context
            eglBase = EglBase.create()
            Log.d(TAG, "EglBase created")
            
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(true)
                    .createInitializationOptions()
            )
            Log.d(TAG, "PeerConnectionFactory initialized")

            // Create PeerConnectionFactory
            val options = PeerConnectionFactory.Options()
peerConnectionFactory = PeerConnectionFactory.builder()
                .setOptions(options)
                .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase?.eglBaseContext, true, true))
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase?.eglBaseContext))
                .createPeerConnectionFactory()

            if (peerConnectionFactory == null) {
                Log.e(TAG, "Failed to create PeerConnectionFactory")
                return
            }

            isInitialized = true
            Log.d(TAG, "✓ WebRTC initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Initialize error: ${e.message}", e)
        }
    }

    fun startCamera(facing: String, deviceId: String = "") {
        try {
            Log.d(TAG, "startCamera called: facing=$facing")
            
            if (!isInitialized) {
                Log.w(TAG, "WebRTC not initialized, initializing now...")
                initialize()
            }

            // Stop previous session
            stopCapturer()

            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraEnumerator = Camera2Enumerator(context)

            Log.d(TAG, "Available cameras: ${cameraManager.cameraIdList.joinToString()}")

            // Select camera
            val selectedCameraId = selectCamera(cameraManager, cameraEnumerator, facing, deviceId)
            if (selectedCameraId.isEmpty()) {
                Log.e(TAG, "No suitable camera found for facing: $facing")
                return
            }

            Log.d(TAG, "Selected camera: $selectedCameraId")

            // Create video capturer
            videoCapturer = cameraEnumerator.createCapturer(selectedCameraId, null)
            if (videoCapturer == null) {
                Log.e(TAG, "Failed to create capturer for camera: $selectedCameraId")
                return
            }
            Log.d(TAG, "Video capturer created")

            // Create media stream
            localStream = peerConnectionFactory?.createLocalMediaStream("local_stream")
            if (localStream == null) {
                Log.e(TAG, "Failed to create media stream")
                return
            }
            Log.d(TAG, "Media stream created")

            // Create video source and track
            videoSource = peerConnectionFactory?.createVideoSource(false)
            if (videoSource == null) {
                Log.e(TAG, "Failed to create video source")
                return
            }

            videoTrack = peerConnectionFactory?.createVideoTrack("video_track", videoSource)
            if (videoTrack == null) {
                Log.e(TAG, "Failed to create video track")
                return
            }

            localStream?.addTrack(videoTrack)
            Log.d(TAG, "Video track added to stream")

            // Create PeerConnection
            if (!createPeerConnection()) {
                Log.e(TAG, "Failed to create peer connection")
                return
            }

            // Start capturing
            capturerObserver = SurfaceTextureHelper.create("CaptureThread", eglBase?.eglBaseContext)
            capturerObserver?.let { helper ->
                videoCapturer?.initialize(helper, context, videoSource?.capturerObserver)
                videoCapturer?.startCapture(640, 480, 30)
                isCapturing = true
                Log.d(TAG, "✓ Camera capture started: 640x480@30fps")
            }

            Log.d(TAG, "✓ Camera started successfully: $selectedCameraId, facing: $facing")
        } catch (e: Exception) {
            Log.e(TAG, "startCamera error: ${e.message}", e)
        }
    }

    private fun selectCamera(
        cameraManager: CameraManager,
        enumerator: Camera2Enumerator,
        facing: String,
        preferredDeviceId: String
    ): String {
        return try {
            // Jika preferredDeviceId diberikan, gunakan itu
            if (preferredDeviceId.isNotEmpty()) {
                return preferredDeviceId
            }

            val facingValue = if (facing == "front") CameraCharacteristics.LENS_FACING_FRONT
            else CameraCharacteristics.LENS_FACING_BACK

            for (cameraId in cameraManager.cameraIdList) {
                val chars = cameraManager.getCameraCharacteristics(cameraId)
                val lensFacing = chars.get(CameraCharacteristics.LENS_FACING)
                if (lensFacing == facingValue) {
                    Log.d(TAG, "Found $facing camera: $cameraId")
                    return cameraId
                }
            }

            // Fallback: use first available camera
            Log.w(TAG, "No $facing camera found, using first available")
            cameraManager.cameraIdList.firstOrNull() ?: ""
        } catch (e: Exception) {
            Log.e(TAG, "selectCamera error: ${e.message}")
            ""
        }
    }

    private fun createPeerConnection(): Boolean {
        return try {
            Log.d(TAG, "Creating PeerConnection...")
            
            val iceServers = listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
            )

            val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
            rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

            peerConnection = peerConnectionFactory?.createPeerConnection(
                rtcConfig,
                SimplePeerConnectionObserver(this, onSignal)
            )

            if (peerConnection == null) {
                Log.e(TAG, "Failed to create PeerConnection")
                return false
            }

            Log.d(TAG, "PeerConnection created")

            // Add local stream
            videoTrack?.let { track ->
    peerConnection?.addTrack(track, listOf("local_stream"))
}

            // Create and send offer
            val offerConstraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
            }

            peerConnection?.createOffer(
                SimpleCreateSessionDescriptionObserver(this, onSignal),
                offerConstraints
            )
            Log.d(TAG, "Offer creation initiated")

            true
        } catch (e: Exception) {
            Log.e(TAG, "createPeerConnection error: ${e.message}", e)
            false
        }
    }

    fun onRemoteSignal(type: String, payload: JSONObject) {
        try {
            when (type) {
                "answer" -> {
                    val sdp = payload.optString("sdp", "")
                    if (sdp.isEmpty()) {
                        Log.w(TAG, "Empty SDP in answer")
                        return
                    }
                    val description = SessionDescription(SessionDescription.Type.ANSWER, sdp)
                    peerConnection?.setRemoteDescription(
                        SimpleSetSessionDescriptionObserver("answer"),
                        description
                    )
                    Log.d(TAG, "✓ Remote answer set")
                }
                "ice" -> {
                    val candidate = payload.optString("candidate", "")
                    val sdpMLineIndex = payload.optInt("sdpMLineIndex", 0)
                    val sdpMid = payload.optString("sdpMid", "")
                    
                    if (candidate.isEmpty()) {
                        Log.w(TAG, "Empty ICE candidate")
                        return
                    }
                    
                    val iceCandidate = IceCandidate(sdpMid, sdpMLineIndex, candidate)
                    peerConnection?.addIceCandidate(iceCandidate)
                    Log.d(TAG, "✓ ICE candidate added")
                }
                else -> {
                    Log.w(TAG, "Unknown signal type: $type")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "onRemoteSignal error: ${e.message}", e)
        }
    }

    private fun stopCapturer() {
        try {
            if (isCapturing) {
                videoCapturer?.stopCapture()
                isCapturing = false
                Log.d(TAG, "Video capture stopped")
            }
            videoCapturer?.dispose()
            videoCapturer = null
            
            capturerObserver?.dispose()
            capturerObserver = null
            
            Log.d(TAG, "Capturer disposed")
        } catch (e: Exception) {
            Log.e(TAG, "stopCapturer error: ${e.message}")
        }
    }

    fun stop() {
        try {
            Log.d(TAG, "Stopping camera...")
            
            stopCapturer()

            videoTrack?.dispose()
            videoTrack = null

            videoSource?.dispose()
            videoSource = null

            localStream?.dispose()
            localStream = null

            peerConnection?.close()
            peerConnection = null

            Log.d(TAG, "✓ Camera stopped and resources disposed")
        } catch (e: Exception) {
            Log.e(TAG, "stop error: ${e.message}", e)
        }
    }

    fun dispose() {
        try {
            Log.d(TAG, "Disposing WebRTC...")
            
            stop()
            
            peerConnectionFactory?.dispose()
            peerConnectionFactory = null
            
            eglBase?.release()
            eglBase = null
            
            isInitialized = false
            
            Log.d(TAG, "✓ WebRTC disposed")
        } catch (e: Exception) {
            Log.e(TAG, "dispose error: ${e.message}", e)
        }
    }

    private class SimplePeerConnectionObserver(
        private val parent: WebRTCStreamer,
        private val onSignal: (type: String, payload: JSONObject) -> Unit
    ) : PeerConnection.Observer {

        override fun onSignalingChange(state: PeerConnection.SignalingState?) {
            Log.d(TAG, "Signaling state changed: $state")
        }

        override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
            Log.d(TAG, "ICE connection state: $state")
        }

        override fun onIceConnectionReceivingChange(receiving: Boolean) {
            Log.d(TAG, "ICE receiving: $receiving")
        }

        override fun onConnectionChange(state: PeerConnection.PeerConnectionState?) {
            Log.d(TAG, "Peer connection state: $state")
        }

        override fun onIceGatheringChange(state: PeerConnection.IceGatheringState?) {
            Log.d(TAG, "ICE gathering state: $state")
        }
       
        override fun onIceCandidate(p0: IceCandidate?) {
    try {
        val iceCandidate = p0 ?: return
        val payload = JSONObject().apply {
            put("candidate", iceCandidate.sdp)
            put("sdpMLineIndex", iceCandidate.sdpMLineIndex)
            put("sdpMid", iceCandidate.sdpMid ?: "")
        }
        onSignal("ice", payload)
        Log.d(TAG, "ICE candidate emitted")
    } catch (e: Exception) {
        Log.e(TAG, "onIceCandidate error: ${e.message}")
    }
}

        override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>?) {
            Log.d(TAG, "ICE candidates removed")
        }

        override fun onAddStream(stream: MediaStream?) {
            Log.d(TAG, "Remote stream added, video tracks: ${stream?.videoTracks?.size ?: 0}")
        }

        override fun onRemoveStream(stream: MediaStream?) {
            Log.d(TAG, "Remote stream removed")
        }

        override fun onDataChannel(channel: DataChannel?) {
            Log.d(TAG, "Data channel created")
        }

        override fun onRenegotiationNeeded() {
            Log.d(TAG, "Renegotiation needed")
        }

        override fun onAddTrack(receiver: RtpReceiver?, streams: Array<out MediaStream>?) {
            Log.d(TAG, "Track added: ${receiver?.track()?.kind()}")
        }
    }

    private class SimpleCreateSessionDescriptionObserver(
        private val parent: WebRTCStreamer,
        private val onSignal: (type: String, payload: JSONObject) -> Unit
    ) : SdpObserver {

        override fun onCreateSuccess(sessionDescription: SessionDescription?) {
            try {
                if (sessionDescription != null) {
                    parent.peerConnection?.setLocalDescription(
                        SimpleSetSessionDescriptionObserver("offer"),
                        sessionDescription
                    )
                    val payload = JSONObject().apply {
                        put("type", "offer")
                        put("sdp", sessionDescription.description)
                    }
                    onSignal("offer", payload)
                    Log.d(TAG, "✓ Offer created and emitted")
                }
            } catch (e: Exception) {
                Log.e(TAG, "onCreateSuccess error: ${e.message}", e)
            }
        }

        override fun onCreateFailure(error: String?) {
            Log.e(TAG, "Create offer failed: $error")
        }

        override fun onSetSuccess() {
            Log.d(TAG, "Local description set successfully")
        }

        override fun onSetFailure(error: String?) {
            Log.e(TAG, "Set description failed: $error")
        }
    }

    private class SimpleSetSessionDescriptionObserver(
        private val type: String
    ) : SdpObserver {

        override fun onCreateSuccess(p0: SessionDescription?) {}

        override fun onCreateFailure(p0: String?) {}

        override fun onSetSuccess() {
            Log.d(TAG, "Remote $type description set successfully")
        }

        override fun onSetFailure(error: String?) {
            Log.e(TAG, "Set remote $type description failed: $error")
        }
    }

    companion object {
        private const val TAG = "WebRTCStreamer"
    }
}
