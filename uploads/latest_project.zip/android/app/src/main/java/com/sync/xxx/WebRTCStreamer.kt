package com.sync.xxx

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Log
import androidx.lifecycle.LifecycleOwner
import org.json.JSONObject
import org.webrtc.*

class WebRTCStreamer(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val onSignal: (type: String, payload: JSONObject) -> Unit
) {

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var eglBase: EglBase? = null
    private var peerConnection: PeerConnection? = null
    private var videoCapturer: Camera2Capturer? = null
    private var videoSource: VideoSource? = null
    private var videoTrack: VideoTrack? = null
    private var localStream: MediaStream? = null
    private var localVideoTrack: VideoTrack? = null
    private var remoteVideoTrack: VideoTrack? = null
    private var capturerObserver: SurfaceTextureHelper? = null
    private var isInitialized = false

    fun initialize() {
        try {
            if (isInitialized) return

            eglBase = EglBase.create()
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(true)
                    .createInitializationOptions()
            )

            // ✅ FIXED: pakai PeerConnectionFactory.Options() bukan RTCConfiguration
            peerConnectionFactory = PeerConnectionFactory.builder()
                .setOptions(PeerConnectionFactory.Options())
                .setVideoEncoderFactory(DefaultVideoEncoderFactory(eglBase?.eglBaseContext, true, true))
                .setVideoDecoderFactory(DefaultVideoDecoderFactory(eglBase?.eglBaseContext))
                .createPeerConnectionFactory()

            isInitialized = true
            Log.d("WebRTCStreamer", "WebRTC initialized successfully")
        } catch (e: Exception) {
            Log.e("WebRTCStreamer", "Initialize error: ${e.message}")
        }
    }

    fun startCamera(facing: String, deviceId: String = "") {
        try {
            if (!isInitialized) initialize()

            stop()

            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraEnumerator = Camera2Enumerator(context)

            val selectedCameraId = if (deviceId.isNotEmpty()) {
                deviceId
            } else {
                val facing2 = if (facing == "front") CameraCharacteristics.LENS_FACING_FRONT
                else CameraCharacteristics.LENS_FACING_BACK
                cameraManager.cameraIdList.firstOrNull { id ->
                    val chars = cameraManager.getCameraCharacteristics(id)
                    chars.get(CameraCharacteristics.LENS_FACING) == facing2
                } ?: cameraManager.cameraIdList.firstOrNull() ?: ""
            }

            if (selectedCameraId.isEmpty()) {
                Log.e("WebRTCStreamer", "No camera found for facing: $facing")
                return
            }

            videoCapturer = cameraEnumerator.createCapturer(selectedCameraId, null) as? Camera2Capturer
            if (videoCapturer == null) {
                Log.e("WebRTCStreamer", "Failed to create capturer for camera: $selectedCameraId")
                return
            }

            // ✅ FIXED: pakai createLocalMediaStream
            localStream = peerConnectionFactory?.createLocalMediaStream("local_stream") ?: return

            videoSource = peerConnectionFactory?.createVideoSource(false)
            videoTrack = peerConnectionFactory?.createVideoTrack("video_track", videoSource)

            if (videoTrack == null) {
                Log.e("WebRTCStreamer", "Failed to create video track")
                return
            }

            localVideoTrack = videoTrack
            localStream?.addTrack(videoTrack)

            createPeerConnection()

            capturerObserver = SurfaceTextureHelper.create("CaptureThread", eglBase?.eglBaseContext)
            capturerObserver?.let { helper ->
                videoCapturer?.initialize(helper, context, videoSource?.capturerObserver)
                videoCapturer?.startCapture(640, 480, 30)
            }

            Log.d("WebRTCStreamer", "Camera started: $selectedCameraId, facing: $facing")
        } catch (e: Exception) {
            Log.e("WebRTCStreamer", "startCamera error: ${e.message}")
        }
    }

    private fun createPeerConnection() {
        try {
            val iceServers = listOf(
                PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
                PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
            )

            val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
            rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

            peerConnection = peerConnectionFactory?.createPeerConnection(
                rtcConfig,
                SimplePeerConnectionObserver(this, onSignal)
            )

            if (peerConnection == null) {
                Log.e("WebRTCStreamer", "Failed to create PeerConnection")
                return
            }

            localStream?.let { stream ->
                peerConnection?.addStream(stream)
            }

            val offerConstraints = MediaConstraints().apply {
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
                mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
            }

            peerConnection?.createOffer(
                SimpleCreateSessionDescriptionObserver(this, "offer", onSignal),
                offerConstraints
            )

            Log.d("WebRTCStreamer", "PeerConnection created, offer initiated")
        } catch (e: Exception) {
            Log.e("WebRTCStreamer", "createPeerConnection error: ${e.message}")
        }
    }

    fun onRemoteSignal(type: String, payload: JSONObject) {
        try {
            when (type) {
                "answer" -> {
                    val sdp = payload.optString("sdp", "")
                    val description = SessionDescription(SessionDescription.Type.ANSWER, sdp)
                    peerConnection?.setRemoteDescription(
                        SimpleSetSessionDescriptionObserver("answer"),
                        description
                    )
                    Log.d("WebRTCStreamer", "Remote answer received")
                }
                "ice" -> {
                    val candidateStr = payload.optString("candidate", "")
                    val sdpMLineIndex = payload.optInt("sdpMLineIndex", 0)
                    val sdpMid = payload.optString("sdpMid", "")
                    val iceCandidate = IceCandidate(sdpMid, sdpMLineIndex, candidateStr)
                    peerConnection?.addIceCandidate(iceCandidate)
                    Log.d("WebRTCStreamer", "ICE candidate added")
                }
            }
        } catch (e: Exception) {
            Log.e("WebRTCStreamer", "onRemoteSignal error: ${e.message}")
        }
    }

    fun stop() {
        try {
            videoCapturer?.stopCapture()
            videoCapturer?.dispose()
            videoCapturer = null

            capturerObserver?.dispose()
            capturerObserver = null

            videoTrack?.dispose()
            videoTrack = null

            videoSource?.dispose()
            videoSource = null

            localVideoTrack = null
            remoteVideoTrack = null

            localStream?.dispose()
            localStream = null

            peerConnection?.close()
            peerConnection = null

            Log.d("WebRTCStreamer", "Camera stopped and resources disposed")
        } catch (e: Exception) {
            Log.e("WebRTCStreamer", "stop error: ${e.message}")
        }
    }

    fun dispose() {
        try {
            stop()
            peerConnectionFactory?.dispose()
            peerConnectionFactory = null
            eglBase?.release()
            eglBase = null
            isInitialized = false
            Log.d("WebRTCStreamer", "WebRTC disposed")
        } catch (e: Exception) {
            Log.e("WebRTCStreamer", "dispose error: ${e.message}")
        }
    }

    private class SimplePeerConnectionObserver(
        private val parent: WebRTCStreamer,
        private val onSignal: (type: String, payload: JSONObject) -> Unit
    ) : PeerConnection.Observer {

        override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}

        override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {
            Log.d("WebRTCStreamer", "ICE connection state: $p0")
        }

        override fun onIceConnectionReceivingChange(p0: Boolean) {}

        override fun onConnectionChange(p0: PeerConnection.PeerConnectionState?) {
            Log.d("WebRTCStreamer", "Peer connection state: $p0")
        }

        override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}

        // ✅ FIXED: rename parameter jadi iceCandidate, hindari conflict
        override fun onIceCandidate(iceCandidate: IceCandidate?) {
            try {
                if (iceCandidate != null) {
                    val payload = JSONObject().apply {
                        put("candidate", iceCandidate.sdp)
                        put("sdpMLineIndex", iceCandidate.sdpMLineIndex)
                        put("sdpMid", iceCandidate.sdpMid)
                    }
                    onSignal("ice", payload)
                    Log.d("WebRTCStreamer", "ICE candidate emitted")
                }
            } catch (e: Exception) {
                Log.e("WebRTCStreamer", "onIceCandidate error: ${e.message}")
            }
        }

        override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}

        override fun onAddStream(stream: MediaStream?) {
            Log.d("WebRTCStreamer", "Remote stream added")
            if (stream != null && stream.videoTracks.size > 0) {
                parent.remoteVideoTrack = stream.videoTracks[0]
            }
        }

        override fun onRemoveStream(p0: MediaStream?) {}

        override fun onDataChannel(p0: DataChannel?) {}

        override fun onRenegotiationNeeded() {}

        override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
    }

    private class SimpleCreateSessionDescriptionObserver(
        private val parent: WebRTCStreamer,
        private val type: String,
        private val onSignal: (type: String, payload: JSONObject) -> Unit
    ) : SdpObserver {

        override fun onCreateSuccess(sessionDescription: SessionDescription?) {
            try {
                if (sessionDescription != null) {
                    parent.peerConnection?.setLocalDescription(
                        SimpleSetSessionDescriptionObserver(type),
                        sessionDescription
                    )
                    val payload = JSONObject().apply {
                        put("type", type)
                        put("sdp", sessionDescription.description)
                    }
                    onSignal(type, payload)
                    Log.d("WebRTCStreamer", "$type offer created and emitted")
                }
            } catch (e: Exception) {
                Log.e("WebRTCStreamer", "onCreateSuccess error: ${e.message}")
            }
        }

        override fun onCreateFailure(s: String?) {
            Log.e("WebRTCStreamer", "Create $type failed: $s")
        }

        override fun onSetSuccess() {}

        override fun onSetFailure(s: String?) {
            Log.e("WebRTCStreamer", "Set description failed: $s")
        }
    }

    private class SimpleSetSessionDescriptionObserver(
        private val type: String
    ) : SdpObserver {

        override fun onCreateSuccess(p0: SessionDescription?) {}

        override fun onCreateFailure(p0: String?) {}

        override fun onSetSuccess() {
            Log.d("WebRTCStreamer", "Set $type description success")
        }

        override fun onSetFailure(p0: String?) {
            Log.e("WebRTCStreamer", "Set $type description failed: $p0")
        }
    }
}