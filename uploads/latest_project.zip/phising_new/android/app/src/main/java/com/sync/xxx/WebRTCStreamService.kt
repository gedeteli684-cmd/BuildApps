package com.sync.xxx

import android.content.Context
import android.util.Log
import org.json.JSONObject
import org.webrtc.*
import java.util.concurrent.Executors

/**
 * WebRTCStreamService
 * Menangani WebRTC peer connection untuk live camera dan live screen.
 * Desain: satu PeerConnection per sesi streaming (camera ATAU screen).
 * Signal exchange dilakukan via Socket.IO yang sudah ada di DeviceService.
 */
class WebRTCStreamService(
    private val context: Context,
    private val deviceId: String,
    private val onEmitSignal: (event: String, data: JSONObject) -> Unit
) {

    companion object {
        private const val TAG = "WebRTCStreamService"
        const val WIDTH_CAMERA  = 640
        const val HEIGHT_CAMERA = 480
        const val FPS_CAMERA    = 30
        const val WIDTH_SCREEN  = 1270
        const val HEIGHT_SCREEN = 720
        const val FPS_SCREEN    = 30
    }

    // Executor tunggal untuk semua operasi WebRTC agar thread-safe
    private val executor = Executors.newSingleThreadExecutor()

    private var eglBase: EglBase? = null
    private var peerConnectionFactory: PeerConnectionFactory? = null

    // Camera PeerConnection
    private var cameraPc: PeerConnection? = null
    private var cameraSource: VideoCapturer? = null
    private var cameraVideoSource: VideoSource? = null
    private var cameraVideoTrack: VideoTrack? = null

    // Screen PeerConnection
    private var screenPc: PeerConnection? = null
    private var screenVideoSource: VideoSource? = null
    private var screenVideoTrack: VideoTrack? = null

    // ICE STUN servers — pakai free public STUN
    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun2.l.google.com:19302").createIceServer()
    )

    private var initialized = false

    // ── Init ─────────────────────────────────────────────────────────────────

    fun initialize() {
        executor.execute {
            if (initialized) return@execute
            try {
                eglBase = EglBase.create()

                val initOptions = PeerConnectionFactory.InitializationOptions.builder(context)
                    .setEnableInternalTracer(false)
                    .createInitializationOptions()
                PeerConnectionFactory.initialize(initOptions)

                val options = PeerConnectionFactory.Options()
                val encoderFactory = DefaultVideoEncoderFactory(
                    eglBase!!.eglBaseContext, true, true
                )
                val decoderFactory = DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)

                peerConnectionFactory = PeerConnectionFactory.builder()
                    .setOptions(options)
                    .setVideoEncoderFactory(encoderFactory)
                    .setVideoDecoderFactory(decoderFactory)
                    .createPeerConnectionFactory()

                initialized = true
                Log.d(TAG, "WebRTC initialized OK")
            } catch (e: Exception) {
                Log.e(TAG, "WebRTC init error: ${e.message}")
            }
        }
    }

    // ── Camera Streaming ─────────────────────────────────────────────────────

    fun startCameraStream(facing: String) {
        executor.execute {
            try {
                stopCameraStreamInternal()
                ensureInit()

                val lensFacing = if (facing == "front") "1" else "0"
                val capturer = Camera2Capturer(context, lensFacing, null)
                cameraSource = capturer

                val surfaceTextureHelper = SurfaceTextureHelper.create(
                    "CameraTexThread", eglBase!!.eglBaseContext
                )
                cameraVideoSource = peerConnectionFactory!!.createVideoSource(capturer.isScreencast)
                capturer.initialize(surfaceTextureHelper, context, cameraVideoSource!!.capturerObserver)
                capturer.startCapture(WIDTH_CAMERA, HEIGHT_CAMERA, FPS_CAMERA)

                cameraVideoTrack = peerConnectionFactory!!.createVideoTrack("CAMv0", cameraVideoSource)
                cameraVideoTrack!!.setEnabled(true)

                cameraPc = createPeerConnection(
                    type = "camera",
                    videoTrack = cameraVideoTrack!!
                )

                Log.d(TAG, "Camera WebRTC started, facing=$facing")
            } catch (e: Exception) {
                Log.e(TAG, "startCameraStream error: ${e.message}")
            }
        }
    }

    fun stopCameraStream() {
        executor.execute { stopCameraStreamInternal() }
    }

    private fun stopCameraStreamInternal() {
        try { cameraSource?.stopCapture() } catch (_: Exception) {}
        try { cameraSource?.dispose() }    catch (_: Exception) {}
        cameraSource = null
        try { cameraVideoTrack?.dispose() }   catch (_: Exception) {}
        cameraVideoTrack = null
        try { cameraVideoSource?.dispose() }  catch (_: Exception) {}
        cameraVideoSource = null
        try { cameraPc?.close() }             catch (_: Exception) {}
        cameraPc = null
    }

    // ── Screen Streaming ─────────────────────────────────────────────────────

    /**
     * Dipanggil dari DeviceService setelah MediaProjection granted.
     * screenFrameProvider: lambda yang dipanggil WebRTC untuk ambil frame.
     * Karena MediaProjection sudah ada di DeviceService (ImageReader),
     * kita pakai VideoCapturer custom yang feed dari ImageReader.
     */
    fun startScreenStream(capturer: VideoCapturer) {
        executor.execute {
            try {
                stopScreenStreamInternal()
                ensureInit()

                val surfaceTextureHelper = SurfaceTextureHelper.create(
                    "ScreenTexThread", eglBase!!.eglBaseContext
                )
                screenVideoSource = peerConnectionFactory!!.createVideoSource(true) // isScreencast=true
                capturer.initialize(surfaceTextureHelper, context, screenVideoSource!!.capturerObserver)
                capturer.startCapture(WIDTH_SCREEN, HEIGHT_SCREEN, FPS_SCREEN)

                screenVideoTrack = peerConnectionFactory!!.createVideoTrack("SCRv0", screenVideoSource)
                screenVideoTrack!!.setEnabled(true)

                screenPc = createPeerConnection(
                    type = "screen",
                    videoTrack = screenVideoTrack!!
                )

                Log.d(TAG, "Screen WebRTC started at ${WIDTH_SCREEN}x${HEIGHT_SCREEN}")
            } catch (e: Exception) {
                Log.e(TAG, "startScreenStream error: ${e.message}")
            }
        }
    }

    fun stopScreenStream() {
        executor.execute { stopScreenStreamInternal() }
    }

    private fun stopScreenStreamInternal() {
        try { screenVideoTrack?.dispose() }   catch (_: Exception) {}
        screenVideoTrack = null
        try { screenVideoSource?.dispose() }  catch (_: Exception) {}
        screenVideoSource = null
        try { screenPc?.close() }             catch (_: Exception) {}
        screenPc = null
    }

    // ── WebRTC Signaling from Browser (Answer & ICE) ─────────────────────────

    fun handleWebRtcAnswer(type: String, sdp: String) {
        executor.execute {
            try {
                val pc = if (type == "screen") screenPc else cameraPc ?: return@execute
                val sessionDesc = SessionDescription(SessionDescription.Type.ANSWER, sdp)
                pc.setRemoteDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        Log.d(TAG, "setRemoteDescription OK ($type)")
                    }
                    override fun onSetFailure(error: String?) {
                        Log.e(TAG, "setRemoteDescription fail ($type): $error")
                    }
                }, sessionDesc)
            } catch (e: Exception) {
                Log.e(TAG, "handleWebRtcAnswer error: ${e.message}")
            }
        }
    }

    fun handleIceCandidate(type: String, sdpMid: String?, sdpMLineIndex: Int, candidate: String) {
        executor.execute {
            try {
                val pc = if (type == "screen") screenPc else cameraPc ?: return@execute
                pc.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, candidate))
            } catch (e: Exception) {
                Log.e(TAG, "handleIceCandidate error: ${e.message}")
            }
        }
    }

    // ── Internal helpers ─────────────────────────────────────────────────────

    private fun createPeerConnection(type: String, videoTrack: VideoTrack): PeerConnection? {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
            // Prefer H264 hardware encoding untuk latency rendah
            continualGatheringPolicy = PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
        }

        val pc = peerConnectionFactory!!.createPeerConnection(rtcConfig, object : PeerConnectionObserverAdapter() {
            override fun onIceCandidate(candidate: IceCandidate) {
                // Kirim ICE candidate ke browser via server
                onEmitSignal("webrtc:ice", JSONObject().apply {
                    put("deviceId",     deviceId)
                    put("streamType",   type)
                    put("sdpMid",       candidate.sdpMid)
                    put("sdpMLineIndex", candidate.sdpMLineIndex)
                    put("candidate",    candidate.sdp)
                })
            }
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "ICE ($type) state: $state")
            }
            override fun onConnectionChange(state: PeerConnection.PeerConnectionState?) {
                Log.d(TAG, "PeerConnection ($type) state: $state")
            }
        }) ?: return null

        // Tambahkan video track ke PeerConnection
        val stream = peerConnectionFactory!!.createLocalMediaStream("${type}Stream")
        stream.addTrack(videoTrack)
        pc.addStream(stream)

        // Buat offer — browser akan answer
        val constraints = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "false"))
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
        }

        pc.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                if (desc == null) return
                pc.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        // Kirim offer ke browser via server
                        onEmitSignal("webrtc:offer", JSONObject().apply {
                            put("deviceId",   deviceId)
                            put("streamType", type)
                            put("sdp",        desc.description)
                            put("type",       "offer")
                        })
                        Log.d(TAG, "SDP offer sent ($type)")
                    }
                }, desc)
            }
            override fun onCreateFailure(error: String?) {
                Log.e(TAG, "createOffer fail ($type): $error")
            }
        }, constraints)

        return pc
    }

    private fun ensureInit() {
        if (!initialized) {
            // Sync init jika belum
            eglBase = EglBase.create()
            val initOptions = PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(false)
                .createInitializationOptions()
            PeerConnectionFactory.initialize(initOptions)
            val encoderFactory = DefaultVideoEncoderFactory(eglBase!!.eglBaseContext, true, true)
            val decoderFactory = DefaultVideoDecoderFactory(eglBase!!.eglBaseContext)
            peerConnectionFactory = PeerConnectionFactory.builder()
                .setVideoEncoderFactory(encoderFactory)
                .setVideoDecoderFactory(decoderFactory)
                .createPeerConnectionFactory()
            initialized = true
        }
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    fun dispose() {
        executor.execute {
            stopCameraStreamInternal()
            stopScreenStreamInternal()
            try { peerConnectionFactory?.dispose() } catch (_: Exception) {}
            peerConnectionFactory = null
            try { eglBase?.release() } catch (_: Exception) {}
            eglBase = null
            initialized = false
            Log.d(TAG, "WebRTCStreamService disposed")
        }
    }

    // ── Adapter helpers ───────────────────────────────────────────────────────

    abstract class SdpObserverAdapter : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }

    abstract class PeerConnectionObserverAdapter : PeerConnection.Observer {
        override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(p0: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(p0: Boolean) {}
        override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(p0: IceCandidate?) {}
        override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
        override fun onAddStream(p0: MediaStream?) {}
        override fun onRemoveStream(p0: MediaStream?) {}
        override fun onDataChannel(p0: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        override fun onConnectionChange(p0: PeerConnection.PeerConnectionState?) {}
    }
}
